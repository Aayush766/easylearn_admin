# Prime Easy Learn — Client Flow Integration Copy/Paste Code

UI/CSS was not redesigned. Replace the corresponding files with the complete contents below.

## `src/services/api.js`

```js
import axios from "axios";

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "http://localhost:5000").replace(/\/$/, "");

export const api = axios.create({
  baseURL: `${API_BASE_URL}/api`,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

let accessToken = sessionStorage.getItem("pel_access_token") || null;
let refreshing = null;

export function setAccessToken(token) {
  accessToken = token || null;
  if (accessToken) sessionStorage.setItem("pel_access_token", accessToken);
  else sessionStorage.removeItem("pel_access_token");
}

export function clearAccessToken() {
  setAccessToken(null);
}

api.interceptors.request.use((config) => {
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`;
  return config;
});

async function refreshAccessToken() {
  if (!refreshing) {
    refreshing = api.post("/auth/refresh").then((response) => {
      const token = response.data?.data?.accessToken || response.data?.accessToken;
      if (token) setAccessToken(token);
      return token || null;
    }).finally(() => {
      refreshing = null;
    });
  }
  return refreshing;
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && original && !original._retry && !original.url?.includes("/auth/")) {
      original._retry = true;
      const token = await refreshAccessToken();
      if (token) {
        original.headers.Authorization = `Bearer ${token}`;
        return api(original);
      }
    }
    return Promise.reject(error);
  },
);

export function unwrap(response) {
  return response?.data?.data ?? response?.data ?? null;
}

export function normalizeList(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.items)) return payload.items;
  if (Array.isArray(payload?.results)) return payload.results;
  return [];
}

export function apiError(error) {
  return error?.response?.data?.message || error?.response?.data?.error?.message || error?.message || "Something went wrong";
}

export const authApi = {
  async login({ email, password, role }) {
    const response = await api.post("/auth/login", { email, password, role });
    const data = unwrap(response) || {};
    const token = data.accessToken || data.token;
    if (token) setAccessToken(token);
    return data.user || data;
  },
  async me() {
    const response = await api.get("/auth/me");
    return unwrap(response);
  },
  async logout() {
    try { await api.post("/auth/logout"); } finally { clearAccessToken(); }
  },
};

export const courseApi = {
  list: (params = {}) => api.get("/courses", { params }).then(unwrap),
  trainerCourses: (params = {}) => api.get("/trainer/courses", { params }).then(unwrap),
  get: (id) => api.get(`/courses/${id}`).then(unwrap),
};

export const enrollmentApi = {
  list: (params = {}) => api.get("/enrollments", { params }).then(unwrap),
  get: (id) => api.get(`/enrollments/${id}`).then(unwrap),
};

export const moduleApi = {
  list: (courseId) => api.get("/modules", { params: { courseId } }).then(unwrap),
};

export const contentApi = {
  list: (params = {}) => api.get("/content", { params }).then(unwrap),
  create: (payload) => api.post("/content", payload, payload instanceof FormData ? { headers: { "Content-Type": "multipart/form-data" } } : undefined).then(unwrap),
  upload: (file, type) => { const form = new FormData(); form.append("file", file); form.append("type", type); return api.post("/uploads", form, { headers: { "Content-Type": "multipart/form-data" } }).then(unwrap); },
};

export const assessmentApi = {
  list: (params = {}) => api.get("/assessments", { params }).then(unwrap),
  get: (id) => api.get(`/assessments/${id}`).then(unwrap),
  create: (payload) => api.post("/assessments", payload).then(unwrap),
};

export const attemptApi = {
  start: (assessmentId) => api.post("/attempts", { assessmentId }).then(unwrap),
  submit: (attemptId, answers) => api.post(`/attempts/${attemptId}/submit`, { answers }).then(unwrap),
};

export const progressApi = {
  list: (params = {}) => api.get("/progress", { params }).then(unwrap),
  update: (payload) => api.post("/progress", payload).then(unwrap),
};

export const resultApi = {
  list: (params = {}) => api.get("/results", { params }).then(unwrap),
  trainerList: (params = {}) => api.get("/trainer/results", { params }).then(unwrap),
};

export const certificateApi = {
  list: (params = {}) => api.get("/certificates", { params }).then(unwrap),
};

export const notificationApi = {
  list: (params = {}) => api.get("/notifications", { params }).then(unwrap),
};

export const messageApi = {
  list: (params = {}) => api.get("/messages", { params }).then(unwrap),
};

export function toArray(payload) {
  return normalizeList(payload);
}

```

## `src/context/AuthContext.jsx`

```jsx
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { authApi, apiError } from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadUser = useCallback(async () => {
    setLoading(true);
    try {
      const current = await authApi.me();
      setUser(current?.user || current || null);
    } catch (err) {
      setUser(null);
      if (err?.response?.status !== 401) setError(apiError(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadUser(); }, [loadUser]);

  const login = useCallback(async (credentials) => {
    setError("");
    const loggedIn = await authApi.login(credentials);
    setUser(loggedIn?.user || loggedIn || null);
    return loggedIn;
  }, []);

  const logout = useCallback(async () => {
    await authApi.logout();
    setUser(null);
  }, []);

  const value = useMemo(() => ({ user, loading, error, login, logout, refreshUser: loadUser }), [user, loading, error, login, logout, loadUser]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}

```

## `src/routes/ProtectedRoute.jsx`

```jsx
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ roles, children }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return null;
  if (!user) return <Navigate replace to={`/login/${roles?.[0] === "TRAINER" ? "trainer" : "student"}`} state={{ from: location.pathname }} />;

  const role = String(user.role || "").toUpperCase();
  if (roles?.length && !roles.includes(role)) {
    return <Navigate replace to={role === "TRAINER" ? "/trainer" : "/student"} />;
  }

  return children;
}

```

## `src/main.jsx`

```jsx
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import { AuthProvider } from "./context/AuthContext";
import "./styles/global.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <AuthProvider>
      <App />
    </AuthProvider>
  </StrictMode>,
);

```

## `src/App.jsx`

```jsx
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import { LandingPage, LoginPage, NotFoundPage } from "./pages";
import ProtectedRoute from "./routes/ProtectedRoute";
import StudentDashboard from "./student/StudentDashboard";
import StudentCourses from "./student/StudentCourses";
import StudentFeaturePage from "./student/StudentFeaturePage";
import StudentAssessments from "./student/StudentAssessments";
import StudentAssessmentTest from "./student/StudentAssessmentTest";
import StudentAssessmentResult from "./student/StudentAssessmentResult";
import StudentCertificates from "./student/StudentCertificates";
import StudentProgress from "./student/StudentProgress";
import StudentMessages from "./student/StudentMessages";
import StudentSupport from "./student/StudentSupport";
import TrainerDashboard from "./trainer/TrainerDashboard";
import { Assessments, Courses, Profile, Results, Support, UploadPage } from "./trainer/TrainerPages";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login/:portal" element={<LoginPage />} />

        <Route path="/student" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentDashboard /></ProtectedRoute>} />
        <Route path="/student/assessments" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentAssessments /></ProtectedRoute>} />
        <Route path="/student/assessments/:assessmentId/result" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentAssessmentResult /></ProtectedRoute>} />
        <Route path="/student/assessments/:assessmentId" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentAssessmentTest /></ProtectedRoute>} />
        <Route path="/student/courses" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentCourses /></ProtectedRoute>} />
        <Route path="/student/certificates" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentCertificates /></ProtectedRoute>} />
        <Route path="/student/progress" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentProgress /></ProtectedRoute>} />
        <Route path="/student/messages" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentMessages /></ProtectedRoute>} />
        <Route path="/student/support" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentSupport /></ProtectedRoute>} />
        <Route path="/student/courses/:id" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentFeaturePage /></ProtectedRoute>} />
        <Route path="/student/:page" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentFeaturePage /></ProtectedRoute>} />

        <Route path="/trainer" element={<ProtectedRoute roles={["TRAINER"]}><TrainerDashboard /></ProtectedRoute>} />
        <Route path="/trainer/courses" element={<ProtectedRoute roles={["TRAINER"]}><Courses /></ProtectedRoute>} />
        <Route path="/trainer/content" element={<ProtectedRoute roles={["TRAINER"]}><Courses /></ProtectedRoute>} />
        <Route path="/trainer/upload" element={<ProtectedRoute roles={["TRAINER"]}><UploadPage /></ProtectedRoute>} />
        <Route path="/trainer/assessments" element={<ProtectedRoute roles={["TRAINER"]}><Assessments /></ProtectedRoute>} />
        <Route path="/trainer/results" element={<ProtectedRoute roles={["TRAINER"]}><Results /></ProtectedRoute>} />
        <Route path="/trainer/profile" element={<ProtectedRoute roles={["TRAINER"]}><Profile /></ProtectedRoute>} />
        <Route path="/trainer/support" element={<ProtectedRoute roles={["TRAINER"]}><Support /></ProtectedRoute>} />

        <Route path="/login" element={<Navigate replace to="/" />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
}

```

## `src/pages/auth/LoginPage.jsx`

```jsx
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  GraduationCap,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { apiError } from "../../services/api";
import "./LoginPage.css";

function LoginPage() {
  const { portal = "student" } = useParams();

const isTrainer = portal === "trainer";
const role = isTrainer ? "trainer" : "student";
const label = isTrainer ? "Trainer" : "Student";
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  return (
    <main className="pel-auth">
      <div className="pel-auth__orb pel-auth__orb--one" />
      <div className="pel-auth__orb pel-auth__orb--two" />

      <section className="pel-auth__intro">
        <div className="pel-auth__intro-inner">
          <Link className="pel-auth-brand" to="/">
            <span className="pel-auth-brand__mark">
              <span />
            </span>
            <span className="pel-auth-brand__text">
              <strong>Prime</strong>
              <b>Easy Learn</b>
              <small>Training Institute</small>
            </span>
          </Link>

          <div className="pel-auth__hero-copy">
            <span className="pel-auth__eyebrow">
              <Sparkles size={13} /> Learn. Assess. Improve.
            </span>

            <h1>
              Your next
              <br />
              <span>achievement</span>
              <br />
              starts here.
            </h1>

            <p>
              {isTrainer
                ? "Manage your courses, guide learners, and make every training session count."
                : "Access practical courses, track your progress, and celebrate every milestone."}
            </p>

            <div className="pel-auth__benefits">
              <div>
                <CheckCircle2 />
                <span>
                  <b>Practical learning</b>
                  Real-world skills
                </span>
              </div>
              <div>
                <CheckCircle2 />
                <span>
                  <b>Expert support</b>
                  Learn with confidence
                </span>
              </div>
              <div>
                <CheckCircle2 />
                <span>
                  <b>Track progress</b>
                  See your growth
                </span>
              </div>
            </div>
          </div>

          <div className="pel-auth__floating-card">
            <span className="pel-auth__floating-icon">
              {isTrainer ? <Users size={19} /> : <GraduationCap size={19} />}
            </span>
            <div>
              <strong>{isTrainer ? "Train with impact" : "Keep learning"}</strong>
              <small>{isTrainer ? "Empower your learners" : "Build your future"}</small>
            </div>
            <span className="pel-auth__floating-check">✓</span>
          </div>

          <Link className="pel-auth__back" to="/">
            <ArrowLeft size={16} />
            Back to home
          </Link>
        </div>
      </section>

      <section className="pel-auth__form-area">
        <div className="pel-auth__card">
          <div className="pel-auth__card-top">
            <span className={`pel-auth__role-icon ${isTrainer ? "trainer" : ""}`}>
              {isTrainer ? <Users size={22} /> : <GraduationCap size={22} />}
            </span>
            <span className="pel-auth__secure">
              <ShieldCheck size={14} /> Secure Login
            </span>
          </div>

          <div className="pel-auth__heading">
            <span className="pel-auth__small-label">WELCOME BACK</span>
            <h2>Login as {label}</h2>
            <p>
              {isTrainer
                ? "Sign in to access your trainer dashboard."
                : "Enter your details to continue to your learning space."}
            </p>
          </div>

          <form
            onSubmit={async (event) => {
              event.preventDefault();
              if (submitting) return;
              setSubmitting(true);
              try {
                const loggedIn = await login({ email, password, role: isTrainer ? "TRAINER" : "LEARNER" });
                const serverRole = String(loggedIn?.role || loggedIn?.user?.role || (isTrainer ? "TRAINER" : "LEARNER")).toUpperCase();
                if (isTrainer && serverRole !== "TRAINER") throw new Error("This account is not a Trainer account.");
                if (!isTrainer && !["LEARNER", "STUDENT"].includes(serverRole)) throw new Error("This account is not a Learner account.");
                navigate(isTrainer ? "/trainer" : "/student", { replace: true });
              } catch (err) {
                window.alert(apiError(err));
              } finally {
                setSubmitting(false);
              }
            }}
            className="pel-auth__form"
          >
            <label className="pel-field">
              <span>Email address</span>
              <div className="pel-field__input">
                <Mail size={17} />
                <input
                  name="email"
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@example.com"
                  autoComplete="email"
                />
              </div>
            </label>

            <label className="pel-field">
              <span>Password</span>
              <div className="pel-field__input">
                <LockKeyhole size={17} />
                <input
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="pel-password-toggle"
                  onClick={() => setShowPassword((value) => !value)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </label>

            <div className="pel-auth__form-row">
              <label className="pel-remember">
                <input type="checkbox" />
                <span>Remember me</span>
              </label>
              <a href="#forgot">Forgot password?</a>
            </div>

            <a
              className="pel-auth__submit"
              href={`/${role}`}
              onClick={async (event) => {
                event.preventDefault();
                if (submitting) return;
                setSubmitting(true);
                try {
                  const loggedIn = await login({ email, password, role: isTrainer ? "TRAINER" : "LEARNER" });
                  const serverRole = String(loggedIn?.role || loggedIn?.user?.role || (isTrainer ? "TRAINER" : "LEARNER")).toUpperCase();
                  if (isTrainer && serverRole !== "TRAINER") throw new Error("This account is not a Trainer account.");
                  if (!isTrainer && !["LEARNER", "STUDENT"].includes(serverRole)) throw new Error("This account is not a Learner account.");
                  navigate(isTrainer ? "/trainer" : "/student", { replace: true });
                } catch (err) {
                  window.alert(apiError(err));
                } finally {
                  setSubmitting(false);
                }
              }}
            >
              <span>`Login to ${label} Portal`</span>
              <ArrowRight size={18} />
            </a>
          </form>

          <div className="pel-auth__divider">
            <span>or</span>
          </div>

          <p className="pel-auth__switch">
            Looking for a different portal?{" "}
            <Link to={`/login/${isTrainer ? "student" : "trainer"}`}>
  Login as {isTrainer ? "Student" : "Trainer"}
</Link>
          </p>

          <div className="pel-auth__privacy">
            <ShieldCheck size={13} />
            <span>Your account information is protected and securely handled.</span>
          </div>
        </div>

        <p className="pel-auth__copyright">
          © 2026 Prime Easy Learn Training Institute
        </p>
      </section>
    </main>
  );
}

export default LoginPage;

```

## `src/student/StudentLayout.jsx`

```jsx
import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { Link, NavLink } from "react-router-dom";
import {
  Bell,
  BookOpen,
  Bookmark,
  CircleHelp,
  FileBadge2,
  FileText,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Search,
  ChevronDown,
  GraduationCap,
  Sparkles,
} from "lucide-react";
import "./StudentLayout.css";
import logo from "../public/assets/student/logo.jpeg";

const STUDENT_NAVIGATION = [
  { label: "Dashboard", path: "/student", icon: LayoutDashboard, end: true },
  { label: "My Courses", path: "/student/courses", icon: BookOpen },
  { label: "Assessments", path: "/student/assessments", icon: FileText },
  { label: "Certificates", path: "/student/certificates", icon: FileBadge2 },
  { label: "My Progress", path: "/student/progress", icon: LayoutDashboard },
  { label: "Bookmarks", path: "/student/bookmarks", icon: Bookmark },
  { label: "Messages", path: "/student/messages", icon: MessageSquare },
  { label: "Help & Support", path: "/student/support", icon: CircleHelp },
];

function StudentBrand() {
  return (
    <Link className="student-layout__brand" to="/student">
      <div className="student-layout__logo-wrapper">
        <img src={logo} alt="Prime Easy Learn Training Institute" />
      </div>
    </Link>
  );
}

function StudentSidebar({ open, onClose }) {
  return (
    <aside className={`student-layout__sidebar${open ? " is-open" : ""}`}>
      <StudentBrand />

      <nav className="student-layout__navigation" aria-label="Student navigation">
        {STUDENT_NAVIGATION.map(({ label, path, icon: Icon, end }) => (
          <NavLink
            key={path}
            to={path}
            end={end}
            onClick={onClose}
            className={({ isActive }) =>
              `student-layout__nav-link${isActive ? " is-active" : ""}`
            }
          >
            <Icon size={19} strokeWidth={1.85} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="student-layout__sidebar-promo" aria-hidden="true">
        <div className="student-layout__promo-badge">
          <Sparkles size={13} />
          <span>Learning Hub</span>
        </div>
        <GraduationCap size={44} strokeWidth={1.5} className="student-layout__promo-icon" />
        <strong>
          Keep Learning
          <br />
          Keep Growing
        </strong>
        <i className="student-layout__promo-accent" />
        <span>
          “Better Skills
          <br />
          A Brighter You”
        </span>
      </div>
    </aside>
  );
}

function StudentHeader({ onMenu }) {
  const { user } = useAuth();
  const displayName = user?.name || user?.fullName || "Student";
  const displayRole = user?.role === "LEARNER" ? "Learner" : user?.role || "Student";
  return (
    <header className="student-layout__header">
      <button
        type="button"
        className="student-layout__mobile-menu"
        onClick={onMenu}
        aria-label="Open student navigation"
      >
        <Menu size={21} />
      </button>

      <label className="student-layout__search">
        <Search size={18} aria-hidden="true" />
        <input
          type="search"
          placeholder="Search for your courses, lessons, or topics..."
          aria-label="Search"
        />
        <kbd className="student-layout__search-shortcut">⌘K</kbd>
      </label>

      <div className="student-layout__account">
        <button
          type="button"
          className="student-layout__notification"
          aria-label="Notifications"
        >
          <Bell size={20} />
          <span className="student-layout__notification-badge" aria-hidden="true" />
        </button>

        <span className="student-layout__divider" aria-hidden="true" />

        <div className="student-layout__profile-trigger">
          <div className="student-layout__avatar-wrapper">
            <img
              src="/assets/student/avatar.png"
              alt={displayName}
              className="student-layout__avatar"
            />
            <span className="student-layout__status-dot" />
          </div>

          <div className="student-layout__identity">
            <strong>{displayName}</strong>
            <small>{displayRole}</small>
          </div>

          <ChevronDown size={16} className="student-layout__chevron" />
        </div>
      </div>
    </header>
  );
}

export default function StudentLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const closeSidebar = () => setSidebarOpen(false);

  return (
    <div className="student-layout">
      {sidebarOpen && (
        <button
          type="button"
          className="student-layout__backdrop"
          onClick={closeSidebar}
          aria-label="Close student navigation"
        />
      )}

      <StudentSidebar open={sidebarOpen} onClose={closeSidebar} />

      <div className="student-layout__content">
        <StudentHeader onMenu={() => setSidebarOpen(true)} />
        <main className="student-layout__page">{children}</main>
      </div>
    </div>
  );
}
```

## `src/student/StudentCourses.jsx`

```jsx
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import StudentLayout from "./StudentLayout";
import {
  Award,
  BookOpen,
  Calendar,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  Compass,
  FileBadge2,
  FileText,
  Grid2X2,
  List,
  RefreshCw,
  Search,
  Sparkles,
  Zap,
} from "lucide-react";
import "./StudentCourses.css";
import herostudent from "../public/assets/student/hero-student.png";
import { enrollmentApi, normalizeList } from "../services/api";

const COURSE_DATA = [
  {
    id: "full-stack",
    title: "Full Stack Web Development",
    category: "Web Development",
    status: "In Progress",
    statusTone: "progress",
    description:
      "Master modern frontend and backend tech stacks including React, Node.js, Express, and MongoDB.",
    progress: 65,
    startDate: "01 Mar 2025",
    dateLabel: "Valid Until",
    dateValue: "31 Aug 2025",
    dateSubtext: "5 mos left",
    dateTone: "success",
    lessons: "28 / 42",
    assessments: "3 / 5",
    certificate: "In Progress",
    image: "/assets/student/course-fullstack.png",
    action: "Continue",
    actionTone: "primary",
  },
  {
    id: "ui-ux",
    title: "UI/UX Design Masterclass",
    category: "UI/UX Design",
    status: "Not Started",
    statusTone: "neutral",
    description:
      "Learn user interface and experience design with real industry projects and Figma design systems.",
    progress: 0,
    startDate: "10 Sep 2025",
    dateLabel: "Valid Until",
    dateValue: "10 Mar 2026",
    dateSubtext: "6 mos left",
    dateTone: "success",
    lessons: "0 / 28",
    assessments: "0 / 4",
    certificate: "Not Started",
    image: "/assets/student/course-uiux.png",
    action: "Start Learning",
    actionTone: "primary",
  },
  {
    id: "digital-marketing",
    title: "Digital Marketing Essentials",
    category: "Digital Marketing",
    status: "Completed",
    statusTone: "complete",
    description:
      "Master SEO algorithms, performance social campaigns, Google Ads, and content marketing strategy.",
    progress: 100,
    startDate: "15 Jan 2025",
    dateLabel: "Completed On",
    dateValue: "20 Apr 2025",
    dateTone: "default",
    lessons: "28 / 28",
    assessments: "5 / 5",
    certificate: "View Certificate",
    certificateLink: true,
    image: "/assets/student/course-marketing.png",
    action: "Revisit Course",
    actionTone: "secondary",
  },
  {
    id: "data-analytics",
    title: "Data Analytics with Python",
    category: "Data Science",
    status: "Expired",
    statusTone: "expired",
    description:
      "Perform real-world data analysis, statistical visualization, machine learning models, and automated reporting.",
    progress: 100,
    startDate: "01 Jan 2025",
    dateLabel: "Expired On",
    dateValue: "30 Jun 2025",
    dateTone: "danger",
    lessons: "42 / 42",
    assessments: "5 / 5",
    certificate: "View Certificate",
    certificateLink: true,
    finalScore: "88%",
    image: "/assets/student/course-data.png",
    action: "Renew",
    actionTone: "warning",
    expiredMessage: "Access expired on 30 Jun 2025. Renew to unlock updated modules.",
  },
];

const FILTERS = [
  { id: "all", label: "All Courses" },
  { id: "progress", label: "In Progress" },
  { id: "completed", label: "Completed" },
  { id: "expired", label: "Expired" },
];

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function daysLeft(value) {
  if (!value) return "";
  const diff = Math.ceil((new Date(value).getTime() - Date.now()) / 86400000);
  return diff > 0 ? `${diff} days left` : diff === 0 ? "Expires today" : "Expired";
}

function mapEnrollment(enrollment) {
  const course = enrollment.course || enrollment.courseId || {};
  const expiry = enrollment.expiryDate || enrollment.expiresAt;
  const status = String(enrollment.status || "ACTIVE").toUpperCase();
  const progress = Number(enrollment.progressPercent ?? enrollment.progress ?? 0);
  const completed = status === "COMPLETED" || progress >= 100;
  const expired = status === "EXPIRED" || (expiry && new Date(expiry) < new Date());
  const inProgress = !expired && !completed && progress > 0;
  const uiStatus = expired ? "Expired" : completed ? "Completed" : inProgress ? "In Progress" : "Not Started";
  return {
    id: course._id || course.id || enrollment.courseId,
    enrollmentId: enrollment._id || enrollment.id,
    title: course.title || course.name || "Course",
    category: course.category?.name || course.category || "Course",
    status: uiStatus,
    statusTone: expired ? "expired" : completed ? "complete" : inProgress ? "progress" : "neutral",
    description: course.description || "Access your enrolled course content, assessments and progress.",
    progress,
    startDate: formatDate(enrollment.startDate),
    dateLabel: expired ? "Expired On" : completed ? "Completed On" : "Valid Until",
    dateValue: formatDate(expiry),
    dateSubtext: daysLeft(expiry),
    dateTone: expired ? "danger" : "success",
    lessons: `${enrollment.completedLessons ?? 0} / ${enrollment.totalLessons ?? course.totalLessons ?? 0}`,
    assessments: `${enrollment.completedAssessments ?? 0} / ${enrollment.totalAssessments ?? course.totalAssessments ?? 0}`,
    certificate: enrollment.certificate ? "View Certificate" : completed ? "Eligible" : "In Progress",
    certificateLink: Boolean(enrollment.certificate),
    finalScore: enrollment.finalScore != null ? `${enrollment.finalScore}%` : undefined,
    image: course.thumbnail || course.thumbnailUrl || "/assets/student/course-fullstack.png",
    action: expired ? "Renew" : completed ? "Revisit Course" : progress > 0 ? "Continue" : "Start Learning",
    actionTone: expired ? "warning" : completed ? "secondary" : "primary",
    expiredMessage: expired ? `Access expired on ${formatDate(expiry)}. Renew to unlock the course.` : undefined,
  };
}

function getFilterStatus(filterId) {
  if (filterId === "progress") return "In Progress";
  if (filterId === "completed") return "Completed";
  if (filterId === "expired") return "Expired";
  return null;
}

function StatusBadge({ tone, children }) {
  return (
    <span className={`sc-badge sc-badge--${tone}`}>
      <span className="sc-badge__dot" />
      {children}
    </span>
  );
}

function CourseMetaRow({ icon: Icon, label, value, tone = "default", link, subtext }) {
  return (
    <div className={`sc-meta-item sc-meta-item--${tone}`}>
      <div className="sc-meta-item__header">
        <Icon size={12} className="sc-meta-item__icon" />
        <span className="sc-meta-item__label">{label}</span>
      </div>
      <div className="sc-meta-item__body">
        {link ? (
          <Link to={link} className="sc-meta-item__link">
            {value}
          </Link>
        ) : (
          <span className="sc-meta-item__value">{value}</span>
        )}
        {subtext && <span className="sc-meta-item__subtext">{subtext}</span>}
      </div>
    </div>
  );
}

function CourseCard({ course }) {
  const coursePath = `/student/courses/${course.id}`;

  return (
    <article className="sc-card">
      <div className="sc-card__media">
        <img src={course.image} alt={course.title} loading="lazy" />
        <div className="sc-card__overlay" />

        <div className="sc-card__badges">
          <StatusBadge tone={course.statusTone}>{course.status}</StatusBadge>
          <span className="sc-card__category">{course.category}</span>
        </div>
      </div>

      <div className="sc-card__body">
        <h3 className="sc-card__title" title={course.title}>
          {course.title}
        </h3>
        <p className="sc-card__desc">{course.description}</p>

        {/* Progress Bar */}
        <div className="sc-progress">
          <div className="sc-progress__header">
            <span className="sc-progress__label">Progress</span>
            <span className="sc-progress__val">{course.progress}%</span>
          </div>
          <div className="sc-progress__track">
            <div
              className={`sc-progress__fill sc-progress__fill--${course.statusTone}`}
              style={{ width: `${course.progress}%` }}
            />
          </div>
        </div>

        {/* Metadata Grid (2-Column Compact Layout) */}
        <div className="sc-card__meta-grid">
          <CourseMetaRow
            icon={Calendar}
            label="Enrolled"
            value={course.startDate}
          />
          <CourseMetaRow
            icon={Clock}
            label={course.dateLabel}
            value={course.dateValue}
            subtext={course.dateSubtext}
            tone={course.dateTone}
          />
          <CourseMetaRow
            icon={BookOpen}
            label="Modules"
            value={course.lessons}
          />
          <CourseMetaRow
            icon={FileText}
            label="Assessments"
            value={course.assessments}
          />
          <CourseMetaRow
            icon={Award}
            label="Certificate"
            value={course.certificate}
            link={course.certificateLink ? `${coursePath}/certificate` : undefined}
          />
          {course.finalScore && (
            <CourseMetaRow
              icon={FileBadge2}
              label="Final Score"
              value={course.finalScore}
              tone="success"
            />
          )}
        </div>

        {course.expiredMessage && (
          <div className="sc-card__expired-alert">
            <p>{course.expiredMessage}</p>
          </div>
        )}

        {/* Action Buttons (Side-by-Side) */}
        <div className="sc-card__actions">
          <Link
            to={coursePath}
            className={`sc-btn sc-btn--${course.actionTone}`}
          >
            {course.action}
            <ChevronRight size={14} />
          </Link>
          <Link to={coursePath} className="sc-btn sc-btn--ghost">
            Details
          </Link>
        </div>
      </div>
    </article>
  );
}

function CourseHero() {
  return (
    <section className="sc-hero">
      <div className="sc-hero__bg">
        <div className="sc-hero__glow-1" />
        <div className="sc-hero__glow-2" />
        <div className="sc-hero__grid-pattern" />
      </div>

      <div className="sc-hero__container">
        <div className="sc-hero__content">
          <div className="sc-hero__pill">
            <Sparkles size={13} />
            <span>Interactive Learning Dashboard</span>
          </div>
          <h1>
            My Learning <span className="sc-hero__gradient-text">Journey</span>
          </h1>
          <p>
            Track your ongoing courses, complete assessments, download certificates, and level up your skills.
          </p>

          <div className="sc-hero__stats">
            <div className="sc-hero__stat-item">
              <strong>4</strong>
              <span>Total Enrolled</span>
            </div>
            <div className="sc-hero__stat-divider" />
            <div className="sc-hero__stat-item">
              <strong>1</strong>
              <span>In Progress</span>
            </div>
            <div className="sc-hero__stat-divider" />
            <div className="sc-hero__stat-item">
              <strong>2</strong>
              <span>Completed</span>
            </div>
          </div>
        </div>

        <div className="sc-hero__banner">
          <div className="sc-hero__circle" />
          
          <div className="sc-hero__floating-chip sc-hero__floating-chip--left">
            <div className="sc-hero__chip-icon sc-hero__chip-icon--orange">
              <Zap size={14} />
            </div>
            <div>
              <small>Goal</small>
              <strong>Learn &amp; Grow</strong>
            </div>
          </div>

          <div className="sc-hero__floating-chip sc-hero__floating-chip--right">
            <div className="sc-hero__chip-icon sc-hero__chip-icon--green">
              <CheckCircle2 size={14} />
            </div>
            <div>
              <small>Status</small>
              <strong>On Track</strong>
            </div>
          </div>

          <img
            src={herostudent}
            alt="Student Learning"
            className="sc-hero__student-img"
          />
        </div>
      </div>
    </section>
  );
}

function CourseFilters({ activeFilter, onFilterChange, filters = FILTERS }) {
  return (
    <div className="sc-filters" role="tablist" aria-label="Course filters">
      {filters.map((filter) => (
        <button
          key={filter.id}
          type="button"
          role="tab"
          aria-selected={activeFilter === filter.id}
          className={`sc-filters__btn ${activeFilter === filter.id ? "is-active" : ""}`}
          onClick={() => onFilterChange(filter.id)}
        >
          <span>{filter.label}</span>
          <span className="sc-filters__count">{filter.count}</span>
        </button>
      ))}
    </div>
  );
}

function CourseToolbar({ searchQuery, onSearchChange, sort, onSortChange, view, onViewChange }) {
  return (
    <div className="sc-toolbar">
      <div className="sc-toolbar__search">
        <Search size={14} className="sc-toolbar__search-icon" />
        <input
          type="text"
          placeholder="Search courses..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>

      <div className="sc-toolbar__right">
        <div className="sc-toolbar__sort">
          <label htmlFor="course-sort">Sort by</label>
          <div className="sc-select">
            <select
              id="course-sort"
              value={sort}
              onChange={(e) => onSortChange(e.target.value)}
            >
              <option value="recent">Recently Enrolled</option>
              <option value="progress">Highest Progress</option>
              <option value="name">Course Name (A-Z)</option>
            </select>
            <ChevronDown size={12} className="sc-select__arrow" />
          </div>
        </div>

        <div className="sc-view-toggle" aria-label="View mode">
          <button
            type="button"
            className={view === "grid" ? "is-active" : ""}
            onClick={() => onViewChange("grid")}
            aria-label="Grid view"
          >
            <Grid2X2 size={14} />
          </button>
          <button
            type="button"
            className={view === "list" ? "is-active" : ""}
            onClick={() => onViewChange("list")}
            aria-label="List view"
          >
            <List size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

function ExploreCourses() {
  return (
    <section className="sc-explore">
      <div className="sc-explore__glow" />
      <div className="sc-explore__content">
        <div className="sc-explore__left">
          <div className="sc-explore__badge">
            <Compass size={13} />
            <span>Expand Your Knowledge</span>
          </div>
          <h2>Ready to learn something new?</h2>
          <p>
            Upgrade your skills with our latest industry-aligned certification programs and bootcamps.
          </p>
          <Link to="/student/courses/catalog" className="sc-btn sc-btn--primary">
            Browse All Courses
            <ChevronRight size={14} />
          </Link>
        </div>

        <div className="sc-explore__benefits">
          <div className="sc-explore__benefit-card">
            <div className="sc-explore__icon">
              <BookOpen size={16} />
            </div>
            <div>
              <strong>20+ Courses</strong>
              <small>Industry-focused curricula</small>
            </div>
          </div>

          <div className="sc-explore__benefit-card">
            <div className="sc-explore__icon">
              <RefreshCw size={16} />
            </div>
            <div>
              <strong>Self-Paced</strong>
              <small>Learn anytime, anywhere</small>
            </div>
          </div>

          <div className="sc-explore__benefit-card">
            <div className="sc-explore__icon">
              <Award size={16} />
            </div>
            <div>
              <strong>Certificates</strong>
              <small>Boost your resume</small>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="sc-footer">
      <div className="sc-footer__container">
        <span>© 2025 Prime Easy Learn Training Institute. All rights reserved.</span>

        <div className="sc-footer__links">
          <a href="#privacy">Privacy Policy</a>
          <span className="sc-footer__dot">•</span>
          <a href="#terms">Terms &amp; Conditions</a>
          <span className="sc-footer__dot">•</span>
          <a href="#help">Help Center</a>
        </div>
      </div>
    </footer>
  );
}

export default function StudentCourses() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sort, setSort] = useState("recent");
  const [view, setView] = useState("grid");
  const [courseData, setCourseData] = useState(COURSE_DATA);

  useEffect(() => {
    let active = true;
    enrollmentApi.list({ status: "ACTIVE", page: 1, pageSize: 50 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (active && rows.length) setCourseData(rows.map(mapEnrollment));
      })
      .catch(() => { /* preserve existing UI fallback when API is unavailable */ });
    return () => { active = false; };
  }, []);

  const visibleCourses = useMemo(() => {
    const status = getFilterStatus(activeFilter);
    return courseData.filter((course) => {
      const matchesFilter = status ? course.status === status : true;
      const matchesSearch =
        course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesFilter && matchesSearch;
    }).sort((a, b) => {
      if (sort === "progress") return b.progress - a.progress;
      if (sort === "name") return a.title.localeCompare(b.title);
      return 0;
    });
  }, [activeFilter, searchQuery, sort]);

  return (
    <StudentLayout>
      <div className="sc-page">
        <CourseHero />

        <div className="sc-controls">
          <CourseFilters
            activeFilter={activeFilter}
            onFilterChange={setActiveFilter}
            filters={filters.map((filter) => ({ ...filter, count: filter.id === "all" ? courseData.length : courseData.filter((c) => c.status === getFilterStatus(filter.id)).length }))}
          />

          <CourseToolbar
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            sort={sort}
            onSortChange={setSort}
            view={view}
            onViewChange={setView}
          />
        </div>

        <section
          className={`sc-grid sc-grid--${view}`}
          aria-label="Enrolled courses"
        >
          {visibleCourses.length > 0 ? (
            visibleCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))
          ) : (
            <div className="sc-empty">
              <p>No courses found matching your criteria.</p>
            </div>
          )}
        </section>

        <ExploreCourses />
      </div>

      <Footer />
    </StudentLayout>
  );
}
```

## `src/student/StudentAssessments.jsx`

```jsx
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  Clock3,
  FileCheck2,
  FileText,
  HelpCircle,
  LayoutGrid,
  List,
  Play,
  RotateCcw,
  Sparkles,
  Target,
  Trophy,
  XCircle,
} from "lucide-react";
import herostudent from "../public/assets/student/hero-student.png";

import StudentLayout from "./StudentLayout";
import "./StudentAssessments.css";
import { assessmentApi, enrollmentApi, normalizeList } from "../services/api";

const COURSES = [
  { id: "full-stack", name: "Full Stack Web Development", shortName: "Full Stack" },
  { id: "ui-ux", name: "UI/UX Design", shortName: "UI/UX" },
  { id: "digital-marketing", name: "Digital Marketing", shortName: "Marketing" },
];

const ASSESSMENTS = [
  {
    id: 1,
    title: "Pre Assessment",
    description: "Test your current knowledge before starting the course.",
    type: "Pre Assessment",
    typeClass: "pre",
    questions: 20,
    duration: "30 Mins",
    score: 45,
    status: "completed",
    icon: FileText,
    iconClass: "purple",
    action: "View Result",
  },
  {
    id: 2,
    title: "HTML & CSS Quiz",
    description: "Based on Modules 1–3",
    type: "Module Assessment",
    typeClass: "module",
    questions: 15,
    duration: "20 Mins",
    score: 80,
    status: "completed",
    icon: FileCheck2,
    iconClass: "green",
    action: "View Result",
  },
  {
    id: 3,
    title: "JavaScript Basics Quiz",
    description: "Based on Modules 4–6",
    type: "Module Assessment",
    typeClass: "module",
    questions: 20,
    duration: "30 Mins",
    score: 75,
    status: "completed",
    icon: FileCheck2,
    iconClass: "green",
    action: "View Result",
  },
  {
    id: 4,
    title: "React Fundamentals Quiz",
    description: "Based on Modules 7–9",
    type: "Module Assessment",
    typeClass: "module",
    questions: 20,
    duration: "30 Mins",
    score: null,
    status: "not-attempted",
    icon: FileCheck2,
    iconClass: "red",
    action: "Start Now",
  },
  {
    id: 5,
    title: "Post Assessment",
    description: "Test your knowledge after completing the course.",
    type: "Post Assessment",
    typeClass: "post",
    questions: 30,
    duration: "45 Mins",
    score: null,
    status: "pending",
    icon: Clock3,
    iconClass: "blue",
    action: "Attempt Later",
  },
];


function mapAssessment(item) {
  const type = String(item.type || "MODULE").toUpperCase();
  const latest = item.latestAttempt || item.lastAttempt || item.attempt;
  const score = latest?.percentage ?? item.score ?? null;
  const attempted = Boolean(latest || item.attempted || item.attemptCount > 0);
  const status = attempted ? "completed" : type === "POST" ? "pending" : "not-attempted";
  const typeClass = type === "PRE" ? "pre" : type === "POST" ? "post" : "module";
  return {
    id: item._id || item.id,
    title: item.title || "Assessment",
    description: item.description || item.instructions || "Complete this assessment to measure your understanding.",
    type: type === "PRE" ? "Pre Assessment" : type === "POST" ? "Post Assessment" : "Module Assessment",
    typeClass,
    questions: item.questionCount ?? item.questions?.length ?? 0,
    duration: item.duration ? `${item.duration} Mins` : "—",
    score,
    status,
    icon: type === "POST" ? Clock3 : type === "PRE" ? FileText : FileCheck2,
    iconClass: type === "POST" ? "blue" : type === "PRE" ? "purple" : "green",
    action: attempted ? "View Result" : type === "POST" ? "Attempt Later" : "Start Now",
  };
}

const TABS = [
  { id: "all", label: "All Assessments" },
  { id: "pre", label: "Pre Assessments" },
  { id: "post", label: "Post Assessments" },
  { id: "attempted", label: "Attempted" },
];

function getVisibleAssessments(tab, assessments) {
  switch (tab) {
    case "pre":
      return assessments.filter((item) => item.typeClass === "pre");
    case "post":
      return assessments.filter((item) => item.typeClass === "post");
    case "attempted":
      return assessments.filter((item) => item.status === "completed");
    default:
      return assessments;
  }
}

function AssessmentHero() {
  return (
    <section className="assessment-hero">
      <div className="assessment-hero__badge">
        <Sparkles size={14} />
        <span>Evaluate • Improve • Grow</span>
      </div>
      <div className="assessment-hero__content">
        <h1>Assessments</h1>
        <p>Test your knowledge, track progress, and continuously elevate your skill sets.</p>
      </div>
      <div className="assessment-hero__visual" aria-hidden="true">
        <img src={herostudent} alt="" className="assessment-hero__img" />
      </div>
    </section>
  );
}

function AssessmentTabs({ activeTab, onChange }) {
  return (
    <div className="assessment-tabs" role="tablist" aria-label="Assessment filters">
      {TABS.map((tab) => (
        <button
          key={tab.id}
          type="button"
          role="tab"
          aria-selected={activeTab === tab.id}
          className={`assessment-tab ${activeTab === tab.id ? "assessment-tab--active" : ""}`}
          onClick={() => onChange(tab.id)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}

function CourseSelector({ value, onChange }) {
  return (
    <div className="assessment-course-selector">
      <label htmlFor="assessment-course">Course Scope</label>
      <div className="assessment-select">
        <BookOpen size={16} className="assessment-select__icon" />
        <select
          id="assessment-course"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        >
          {courseOptions.map((course) => (
            <option key={course.id} value={course.id}>
              {course.name}
            </option>
          ))}
        </select>
        <ChevronDown size={16} className="assessment-select__chevron" />
      </div>
    </div>
  );
}

function SummaryCard({ icon: Icon, value, label, variant }) {
  return (
    <div className={`assessment-summary-card assessment-summary-card--${variant}`}>
      <div className="assessment-summary-card__icon">
        <Icon size={20} />
      </div>
      <div className="assessment-summary-card__content">
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}

function AssessmentItem({ assessment, viewMode }) {
  const Icon = assessment.icon;

  const renderStatus = () => {
    if (assessment.status === "completed") {
      return (
        <div className="assessment-status-badge assessment-status-badge--completed">
          <span>Score</span>
          <strong>{assessment.score}%</strong>
        </div>
      );
    }
    return (
      <div className="assessment-status-badge assessment-status-badge--neutral">
        <span>Status</span>
        <strong>{assessment.status === "pending" ? "Pending" : "Not Started"}</strong>
      </div>
    );
  };

  const renderAction = () => {
    if (assessment.status === "completed") {
      return (
        <Link
          to={`/student/assessments/${assessment.id}/result`}
          className="assessment-button assessment-button--outline"
        >
          {assessment.action}
        </Link>
      );
    }
    if (assessment.status === "not-attempted") {
      return (
        <Link
          to={`/student/assessments/${assessment.id}`}
          className="assessment-button assessment-button--primary"
        >
          <Play size={13} />
          {assessment.action}
        </Link>
      );
    }
    return (
      <button type="button" className="assessment-button assessment-button--outline">
        {assessment.action}
      </button>
    );
  };

  return (
    <article className={`assessment-card assessment-card--${viewMode}`}>
      <div className={`assessment-card__icon assessment-card__icon--${assessment.iconClass}`}>
        <Icon size={20} />
      </div>

      <div className="assessment-card__body">
        <div className="assessment-card__header">
          <h3>
            {assessment.id}. {assessment.title}
          </h3>
          <span className={`assessment-type assessment-type--${assessment.typeClass}`}>
            {assessment.type}
          </span>
        </div>
        <p className="assessment-card__description">{assessment.description}</p>
      </div>

      <div className="assessment-card__meta">
        <span>
          <FileText size={14} />
          {assessment.questions} Questions
        </span>
        <span>
          <Clock3 size={14} />
          {assessment.duration}
        </span>
      </div>

      <div className="assessment-card__result">{renderStatus()}</div>

      <div className="assessment-card__action">{renderAction()}</div>
    </article>
  );
}

function PerformanceCard() {
  return (
    <section className="performance-card">
      <div className="panel-heading">
        <h2>Performance Snapshot</h2>
        <button type="button" className="report-link">
          Detailed Report <ArrowRight size={14} />
        </button>
      </div>

      <div className="performance-chart">
        <div className="performance-bars">
          <div className="performance-bar">
            <span className="performance-bar__value">45%</span>
            <div className="performance-bar__track">
              <div
                className="performance-bar__fill performance-bar__fill--pre"
                style={{ height: "45%" }}
              />
            </div>
            <span className="performance-bar__label">Pre-Test</span>
          </div>

          <div className="performance-bar">
            <span className="performance-bar__value">82%</span>
            <div className="performance-bar__track">
              <div
                className="performance-bar__fill performance-bar__fill--post"
                style={{ height: "82%" }}
              />
            </div>
            <span className="performance-bar__label">Post-Test</span>
          </div>
        </div>

        <div className="performance-donut-wrapper">
          <div className="performance-donut">
            <div className="performance-donut__inner">
              <strong>75%</strong>
            </div>
          </div>
          <span className="performance-donut__label">Overall Progress</span>
        </div>
      </div>

      <div className="performance-success">
        <div className="performance-success__icon">
          <Trophy size={18} />
        </div>
        <div>
          <strong>Great Progress!</strong>
          <p>You&apos;ve demonstrated a 37% improvement across assessments.</p>
        </div>
      </div>
    </section>
  );
}

function AssessmentInstructions() {
  const instructions = [
    "Read each question carefully before submitting.",
    "Each assessment features an active countdown timer.",
    "Single submit attempt per assessment module.",
    "Scores are indexed automatically upon completion.",
  ];

  return (
    <section className="info-panel">
      <div className="info-panel__heading">
        <div className="info-panel__icon">
          <FileText size={18} />
        </div>
        <h2>Instructions</h2>
      </div>
      <ul>
        {instructions.map((inst, index) => (
          <li key={index}>
            <CheckCircle2 size={14} />
            <span>{inst}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function NeedHelp() {
  return (
    <section className="help-panel">
      <div className="help-panel__icon">
        <HelpCircle size={20} />
      </div>
      <div className="help-panel__content">
        <h2>Need Assistance?</h2>
        <p>Encountering issues with an assessment? Contact academic support.</p>
        <button type="button" className="help-panel__button">
          Get Support
        </button>
      </div>
    </section>
  );
}

function AssessmentBottomCTA() {
  return (
    <section className="assessment-bottom-cta">
      <div className="assessment-bottom-cta__target">
        <Target size={24} />
      </div>
      <div className="assessment-bottom-cta__copy">
        <h2>Consistent Practice Drives Excellence</h2>
        <p>Complete assessments on schedule to generate complete competency reports.</p>
      </div>
      <Link to="/student/courses" className="assessment-bottom-cta__button">
        Go to Courses <ArrowRight size={15} />
      </Link>
    </section>
  );
}

function AssessmentFooter() {
  return (
    <footer className="assessment-footer">
      <span>© 2026 Prime Easy Learn Training Institute. All rights reserved.</span>
      <div className="assessment-footer__links">
        <a href="#privacy">Privacy Policy</a>
        <span>•</span>
        <a href="#terms">Terms of Service</a>
        <span>•</span>
        <a href="#help">Support</a>
      </div>
    </footer>
  );
}

export default function StudentAssessments() {
  const [selectedCourse, setSelectedCourse] = useState("full-stack");
  const [activeTab, setActiveTab] = useState("all");
  const [viewMode, setViewMode] = useState("list");
  const [courseOptions, setCourseOptions] = useState(COURSES);
  const [assessmentData, setAssessmentData] = useState(ASSESSMENTS);

  useEffect(() => {
    let active = true;
    enrollmentApi.list({ status: "ACTIVE", page: 1, pageSize: 50 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (!active || !rows.length) return;
        const mapped = rows.map((row) => {
          const course = row.course || row.courseId || {};
          return { id: course._id || course.id || row.courseId, name: course.title || course.name || "Course", shortName: course.shortName || course.title || "Course" };
        });
        setCourseOptions(mapped);
        if (!mapped.some((course) => course.id === selectedCourse)) setSelectedCourse(mapped[0].id);
      })
      .catch(() => {});
    return () => { active = false; };
  }, [selectedCourse]);

  useEffect(() => {
    let active = true;
    assessmentApi.list({ courseId: selectedCourse, page: 1, pageSize: 50 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (active && rows.length) setAssessmentData(rows.map(mapAssessment));
      })
      .catch(() => {});
    return () => { active = false; };
  }, [selectedCourse]);

  const visibleAssessments = useMemo(
    () => getVisibleAssessments(activeTab, assessmentData),
    [activeTab, assessmentData]
  );

  const selectedCourseData = courseOptions.find((c) => c.id === selectedCourse);

  return (
    <StudentLayout>
      <div className="student-assessments">
        <AssessmentHero />

        <div className="assessment-container">
          <AssessmentTabs activeTab={activeTab} onChange={setActiveTab} />

          <div className="assessment-layout">
            <main className="assessment-main">
              <CourseSelector value={selectedCourse} onChange={setSelectedCourse} />

              <div className="assessment-summary">
                <SummaryCard icon={FileText} value={assessmentData.length} label="Total" variant="purple" />
                <SummaryCard icon={CheckCircle2} value={assessmentData.filter((item) => item.status === "completed").length} label="Completed" variant="green" />
                <SummaryCard icon={Clock3} value={assessmentData.filter((item) => item.status === "pending").length} label="Pending" variant="orange" />
                <SummaryCard icon={XCircle} value={assessmentData.filter((item) => item.status === "not-attempted").length} label="Unattempted" variant="red" />
              </div>

              <section className="assessment-list-section">
                <div className="assessment-list-heading">
                  <div>
                    <span className="assessment-subtitle">Module Evaluations</span>
                    <h2>{selectedCourseData?.name}</h2>
                  </div>

                  <div className="assessment-list-controls">
                    <span className="assessment-count">
                      {visibleAssessments.length} Available
                    </span>

                    <div className="view-mode-toggle" role="group" aria-label="View Mode">
                      <button
                        type="button"
                        className={`view-mode-btn ${viewMode === "list" ? "active" : ""}`}
                        onClick={() => setViewMode("list")}
                        title="List View"
                      >
                        <List size={16} />
                      </button>
                      <button
                        type="button"
                        className={`view-mode-btn ${viewMode === "block" ? "active" : ""}`}
                        onClick={() => setViewMode("block")}
                        title="Block Grid View"
                      >
                        <LayoutGrid size={16} />
                      </button>
                    </div>
                  </div>
                </div>

                <div className={`assessment-grid assessment-grid--${viewMode}`}>
                  {visibleAssessments.length > 0 ? (
                    visibleAssessments.map((assessment) => (
                      <AssessmentItem
                        key={assessment.id}
                        assessment={assessment}
                        viewMode={viewMode}
                      />
                    ))
                  ) : (
                    <div className="assessment-empty">
                      <div className="assessment-empty__icon">
                        <RotateCcw size={20} />
                      </div>
                      <h3>No Assessments Found</h3>
                      <p>There are no assessments matching the selected filters.</p>
                    </div>
                  )}
                </div>
              </section>
            </main>

            <aside className="assessment-sidebar">
              <PerformanceCard />
              <AssessmentInstructions />
              <NeedHelp />
            </aside>
          </div>

          <AssessmentBottomCTA />
        </div>

        <AssessmentFooter />
      </div>
    </StudentLayout>
  );
}
```

## `src/student/StudentAssessmentTest.jsx`

```jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  Bookmark,
  Check,
  CheckCircle2,
  ChevronLeft,
  Clock3,
  Database,
  FileText,
  HelpCircle,
  Menu,
  Timer,
  X,
} from "lucide-react";

import "./StudentAssessmentTest.css";
import { assessmentApi, attemptApi, } from "../services/api";

const QUESTIONS = [
  {
    id: 1,
    question: "Which of the following is used to style a web page?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "HTML" },
      { id: "B", text: "CSS" },
      { id: "C", text: "JavaScript" },
      { id: "D", text: "Python" },
    ],
    correctAnswer: "B",
    explanation:
      "CSS (Cascading Style Sheets) is used to style and design web pages, including layout, colors, fonts, and spacing.",
  },
  {
    id: 2,
    question: "Which HTML element is used to create a hyperlink?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "<link>" },
      { id: "B", text: "<a>" },
      { id: "C", text: "<href>" },
      { id: "D", text: "<url>" },
    ],
    correctAnswer: "B",
    explanation:
      "The <a> element is used to create hyperlinks in HTML.",
  },
  {
    id: 3,
    question: "Which language is primarily used to add interactivity to web pages?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "CSS" },
      { id: "B", text: "HTML" },
      { id: "C", text: "JavaScript" },
      { id: "D", text: "SQL" },
    ],
    correctAnswer: "C",
    explanation:
      "JavaScript is commonly used to add dynamic behavior and interactivity to web pages.",
  },
  {
    id: 4,
    question: "Which CSS property changes the text color?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "font-color" },
      { id: "B", text: "text-color" },
      { id: "C", text: "color" },
      { id: "D", text: "foreground" },
    ],
    correctAnswer: "C",
    explanation:
      "The CSS color property is used to define the foreground text color.",
  },
  {
    id: 5,
    question: "Which keyword declares a constant in modern JavaScript?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "constant" },
      { id: "B", text: "const" },
      { id: "C", text: "static" },
      { id: "D", text: "fixed" },
    ],
    correctAnswer: "B",
    explanation:
      "The const keyword declares a block-scoped variable whose binding cannot be reassigned.",
  },
  ...Array.from({ length: 15 }, (_, index) => ({
    id: index + 6,
    question: `Sample assessment question ${index + 6}: Which concept is important in modern web development?`,
    type: "Multiple Choice",
    options: [
      { id: "A", text: "Responsive Design" },
      { id: "B", text: "Accessibility" },
      { id: "C", text: "Performance" },
      { id: "D", text: "All of the above" },
    ],
    correctAnswer: "D",
    explanation:
      "Responsive design, accessibility, and performance are all important aspects of modern web development.",
  })),
];

const INITIAL_TIME = 30 * 60;

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;

  return `${String(minutes).padStart(2, "0")}:${String(
    remainingSeconds
  ).padStart(2, "0")}`;
}

function AssessmentLogo() {
  return (
    <div className="test-logo">
      <img
        src="/assets/student/logo.jpeg"
        alt="Prime Easy Learn Training Institute"
      />
    </div>
  );
}

function TestHeader({
  courseName,
  timeRemaining,
  onEndTest,
  onMobileMenu,
}) {
  return (
    <header className="test-header">
      <AssessmentLogo />

      <div className="test-header__course">
        <button
          type="button"
          className="test-header__back"
          onClick={onMobileMenu}
          aria-label="Back"
        >
          <ArrowLeft size={21} />
        </button>

        <div className="test-header__course-icon">
          <Database size={23} />
        </div>

        <div className="test-header__course-info">
          <strong>{courseName}</strong>
          <span>Assessment Test</span>
        </div>
      </div>

      <div className="test-header__actions">
        <div className="test-header__timer">
          <Clock3 size={19} />
          <span>{formatTime(timeRemaining)}</span>
        </div>

        <button
          type="button"
          className="test-header__end"
          onClick={onEndTest}
        >
          End Test
        </button>

        <button
          type="button"
          className="test-header__notification"
          aria-label="Notifications"
        >
          <Bell size={20} />
          <span />
        </button>

        <div className="test-header__profile">
          <img
            src="/assets/student/avatar.png"
            alt="Aayush Kumar"
          />

          <div>
            <strong>Aayush Kumar</strong>
            <span>Student</span>
          </div>

          <ChevronLeft size={18} className="test-header__profile-chevron" />
        </div>
      </div>
    </header>
  );
}

function TestInformation({ questionCount, timeMinutes }) {
  return (
    <div className="test-information">
      <div className="test-information__back">
        <ArrowLeft size={16} />
        <span>Back to Course</span>
      </div>

      <h1>Pre Assessment</h1>

      <p>
        Test your current knowledge before starting the course.
      </p>

      <div className="test-information__stats">
        <div>
          <FileText size={18} />
          <span>{questionCount} Questions</span>
        </div>

        <div>
          <Clock3 size={18} />
          <span>{timeMinutes} Minutes</span>
        </div>

        <div>
          <FileText size={18} />
          <span>Multiple Choice</span>
        </div>

        <div>
          <CheckCircle2 size={18} />
          <span>Auto Saved</span>
        </div>
      </div>
    </div>
  );
}

function QuestionPalette({
  questions,
  currentQuestion,
  answers,
  markedQuestions,
  onSelect,
}) {
  return (
    <section className="question-palette">
      <h2>Question Palette</h2>

      <div className="palette-legend">
        <div>
          <span className="legend-dot legend-dot--answered" />
          Answered
        </div>

        <div>
          <span className="legend-dot legend-dot--unanswered" />
          Not Answered
        </div>

        <div>
          <span className="legend-dot legend-dot--current" />
          Current
        </div>

        <div>
          <Bookmark size={16} />
          Marked
        </div>
      </div>

      <div className="question-grid">
        {questions.map((question) => {
          const isCurrent = question.id === currentQuestion;
          const isAnswered = Boolean(answers[question.id]);
          const isMarked = markedQuestions.includes(question.id);

          let stateClass = "";

          if (isCurrent) {
            stateClass = "question-number--current";
          } else if (isAnswered) {
            stateClass = "question-number--answered";
          } else {
            stateClass = "question-number--unanswered";
          }

          return (
            <button
              type="button"
              key={question.id}
              className={`question-number ${stateClass}`}
              onClick={() => onSelect(question.id)}
              aria-label={`Question ${question.id}`}
            >
              {question.id}

              {isMarked && (
                <Bookmark
                  size={9}
                  className="question-number__bookmark"
                  fill="currentColor"
                />
              )}
            </button>
          );
        })}
      </div>
    </section>
  );
}

function TimerCard({ timeRemaining }) {
  const progress = Math.max(
    0,
    Math.min(100, (timeRemaining / INITIAL_TIME) * 100)
  );

  return (
    <section className="timer-card">
      <div className="timer-card__header">
        <Timer size={29} />
        <h2>Time Remaining</h2>
      </div>

      <div className="timer-card__body">
        <div>
          <strong>{formatTime(timeRemaining)}</strong>

          <div className="timer-card__labels">
            <span>Minutes</span>
            <span>Seconds</span>
          </div>
        </div>

        <div
          className="timer-ring"
          style={{
            background: `conic-gradient(
              #0878ef ${progress}%,
              #d9e1ec ${progress}% 100%
            )`,
          }}
        >
          <div className="timer-ring__inner" />
        </div>
      </div>
    </section>
  );
}

function QuestionCard({
  question,
  selectedAnswer,
  marked,
  onAnswer,
  onToggleMark,
}) {
  const answered = Boolean(selectedAnswer);

  return (
    <section className="question-card">
      <div className="question-card__top">
        <span className="question-type">{question.type}</span>

        <button
          type="button"
          className={`mark-button ${
            marked ? "mark-button--active" : ""
          }`}
          onClick={onToggleMark}
        >
          <Bookmark
            size={18}
            fill={marked ? "currentColor" : "none"}
          />
          {marked ? "Marked" : "Mark for Review"}
        </button>
      </div>

      <h2>{question.question}</h2>

      <div className="answer-options">
        {question.options.map((option) => {
          const selected = selectedAnswer === option.id;

          return (
            <button
              type="button"
              key={option.id}
              className={`answer-option ${
                selected ? "answer-option--selected" : ""
              }`}
              onClick={() => onAnswer(option.id)}
            >
              <span className="answer-option__radio">
                {selected && <span />}
              </span>

              <span className="answer-option__letter">
                {option.id}
              </span>

              <span className="answer-option__text">
                {option.text}
              </span>
            </button>
          );
        })}
      </div>

      {answered && (
        <div className="answer-feedback">
          <div className="answer-feedback__icon">
            <Check size={20} />
          </div>

          <div>
            <strong>Answer Saved</strong>
            <p>
              Your answer has been automatically saved. You can change
              your answer before submitting the assessment.
            </p>
          </div>
        </div>
      )}
    </section>
  );
}

function HelpCard() {
  return (
    <section className="test-help">
      <div className="test-help__icon">
        <HelpCircle size={27} />
      </div>

      <div>
        <h2>Need Help?</h2>

        <p>
          If you face any issues during the test, contact our support
          team.
        </p>

        <button type="button">Contact Support</button>
      </div>
    </section>
  );
}

function TestFooter() {
  return (
    <footer className="test-footer">
      <span>
        © 2025 Prime Easy Learn Training Institute. All rights reserved.
      </span>

      <div>
        <a href="#privacy">Privacy Policy</a>
        <span>|</span>
        <a href="#terms">Terms &amp; Conditions</a>
        <span>|</span>
        <a href="#help">Help</a>
      </div>

      <div className="test-footer__quote">
        Learn Today
        <br />
        Lead Tomorrow
      </div>
    </footer>
  );
}

function EndTestModal({ onCancel, onConfirm }) {
  return (
    <div className="test-modal-backdrop">
      <div className="test-modal">
        <button
          type="button"
          className="test-modal__close"
          onClick={onCancel}
        >
          <X size={19} />
        </button>

        <div className="test-modal__icon">
          <Clock3 size={25} />
        </div>

        <h2>End Assessment?</h2>

        <p>
          Are you sure you want to end this assessment? Your current
          progress will be submitted.
        </p>

        <div className="test-modal__actions">
          <button type="button" onClick={onCancel}>
            Continue Test
          </button>

          <button
            type="button"
            className="test-modal__confirm"
            onClick={onConfirm}
          >
            End Test
          </button>
        </div>
      </div>
    </div>
  );
}

export default function StudentAssessmentTest() {
  const navigate = useNavigate();
  const { assessmentId } = useParams();

  const [currentQuestion, setCurrentQuestion] = useState(1);
  const [answers, setAnswers] = useState({});
  const [markedQuestions, setMarkedQuestions] = useState([]);
  const [timeRemaining, setTimeRemaining] = useState(INITIAL_TIME);
  const [showEndModal, setShowEndModal] = useState(false);
  const [questions, setQuestions] = useState(QUESTIONS);
  const [courseName, setCourseName] = useState("Full Stack Web Development");
  const [attemptId, setAttemptId] = useState(null);

  const question = useMemo(
    () =>
      questions.find((item) => item.id === currentQuestion) ||
      questions[0],
    [currentQuestion, questions]
  );

  useEffect(() => {
    let active = true;
    if (!assessmentId) return undefined;
    assessmentApi.get(assessmentId)
      .then(async (payload) => {
        const data = payload?.assessment || payload || {};
        const remoteQuestions = Array.isArray(data.questions) ? data.questions : [];
        if (!active) return;
        if (data.course?.title || data.course?.name) setCourseName(data.course.title || data.course.name);
        if (data.duration) setTimeRemaining(Number(data.duration) * 60);
        if (remoteQuestions.length) {
          setQuestions(remoteQuestions.map((item, index) => ({
            id: index + 1,
            question: item.question || item.text || "Question",
            type: item.type || "Multiple Choice",
            options: (item.options || []).map((option, optionIndex) => ({
              id: option.id || String.fromCharCode(65 + optionIndex),
              text: option.text || option.value || String(option),
            })),
            explanation: item.explanation || "",
          })));
        }
        try {
          const attempt = await attemptApi.start(assessmentId);
          if (active) setAttemptId(attempt?._id || attempt?.id || attempt?.attemptId || attempt?.data?._id || null);
        } catch (_) { /* fallback UI remains usable when attempt API is unavailable */ }
      })
      .catch(() => {});
    return () => { active = false; };
  }, [assessmentId]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setTimeRemaining((current) => {
        if (current <= 1) {
          window.clearInterval(timer);
          return 0;
        }

        return current - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!assessmentId) return;

    localStorage.setItem(
      `assessment-${assessmentId}-progress`,
      JSON.stringify({
        currentQuestion,
        answers,
        markedQuestions,
        timeRemaining,
      })
    );
  }, [
    assessmentId,
    currentQuestion,
    answers,
    markedQuestions,
    timeRemaining,
  ]);

  const answeredCount = Object.keys(answers).length;

  const selectAnswer = (answer) => {
    setAnswers((previous) => ({
      ...previous,
      [currentQuestion]: answer,
    }));
  };

  const toggleMark = () => {
    setMarkedQuestions((previous) =>
      previous.includes(currentQuestion)
        ? previous.filter((id) => id !== currentQuestion)
        : [...previous, currentQuestion]
    );
  };

  const goToQuestion = (id) => {
    setCurrentQuestion(id);
  };

  const nextQuestion = () => {
    setCurrentQuestion((current) =>
      Math.min(questions.length, current + 1)
    );
  };

  const previousQuestion = () => {
    setCurrentQuestion((current) => Math.max(1, current - 1));
  };

  const endTest = async () => {
    setShowEndModal(false);
    if (attemptId) {
      try {
        const submitted = await attemptApi.submit(attemptId, Object.entries(answers).map(([questionId, selectedOption]) => ({ questionId, selectedOption })));
        const resultId = submitted?._id || submitted?.id || submitted?.attemptId || attemptId;
        navigate(`/student/assessments/${resultId}/result`);
        return;
      } catch (_) {
        // Keep the existing navigation if the API is temporarily unavailable.
      }
    }
    navigate(`/student/assessments/${assessmentId}/result`);
  };

  const progressPercentage =
    (currentQuestion / questions.length) * 100;

  return (
    <div className="assessment-test-page">
      <TestHeader
        courseName={courseName}
        timeRemaining={timeRemaining}
        onEndTest={() => setShowEndModal(true)}
        onMobileMenu={() => navigate("/student/assessments")}
      />

      <div className="test-workspace">
        <aside className="test-left-sidebar">
          <TestInformation
            questionCount={questions.length}
            timeMinutes={30}
          />

          <QuestionPalette
            questions={questions}
            currentQuestion={currentQuestion}
            answers={answers}
            markedQuestions={markedQuestions}
            onSelect={goToQuestion}
          />

          <div className="test-status-legend">
            <div>
              <span className="status-dot status-dot--current" />
              Current Question
            </div>

            <div>
              <span className="status-dot status-dot--unanswered" />
              Not Answered
            </div>

            <div>
              <span className="status-dot status-dot--answered" />
              Answered
            </div>

            <div>
              <Bookmark size={18} />
              Marked for Review
            </div>
          </div>
        </aside>

        <main className="test-main">
          <div className="test-progress-header">
            <div>
              Question {currentQuestion} of {questions.length}
            </div>

            <div className="test-progress-value">
              {Math.round(progressPercentage)}% Completed
            </div>

            <div className="test-progress-track">
              <span
                style={{
                  width: `${progressPercentage}%`,
                }}
              />
            </div>
          </div>

          <QuestionCard
            question={question}
            selectedAnswer={answers[currentQuestion]}
            marked={markedQuestions.includes(currentQuestion)}
            onAnswer={selectAnswer}
            onToggleMark={toggleMark}
          />

          <div className="test-navigation">
            <button
              type="button"
              className="test-navigation__previous"
              disabled={currentQuestion === 1}
              onClick={previousQuestion}
            >
              <ChevronLeft size={19} />
              Previous
            </button>

            <div className="test-navigation__saved">
              <CheckCircle2 size={15} />
              {answeredCount} of {questions.length} Answered
            </div>

            <button
              type="button"
              className="test-navigation__next"
              disabled={currentQuestion === questions.length}
              onClick={nextQuestion}
            >
              Next Question
              <ArrowRight size={18} />
            </button>
          </div>
        </main>

        <aside className="test-right-sidebar">
          <TimerCard timeRemaining={timeRemaining} />

          <QuestionPalette
            questions={questions}
            currentQuestion={currentQuestion}
            answers={answers}
            markedQuestions={markedQuestions}
            onSelect={goToQuestion}
          />

          <HelpCard />
        </aside>
      </div>

      <TestFooter />

      {showEndModal && (
        <EndTestModal
          onCancel={() => setShowEndModal(false)}
          onConfirm={endTest}
        />
      )}
    </div>
  );
}
```

## `src/student/StudentAssessmentResult.jsx`

```jsx
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Circle,
  Clock3,
  Download,
  FileCheck2,
  HelpCircle,
  Lightbulb,
  Trophy,
  XCircle,
} from "lucide-react";

import StudentLayout from "./StudentLayout";
import "./StudentAssessmentResult.css";
import { resultApi, normalizeList } from "../services/api";

const RESULT_DATA = {
  1: {
    title: "Pre Assessment",
    course: "Full Stack Web Development",
    attemptedAt: "20 Sep 2025 at 10:30 AM",
    duration: "30 Minutes",
    questions: 20,

    score: 75,
    correct: 15,
    incorrect: 3,
    notAttempted: 2,

    timeTaken: "30 Mins",
    average: "82%",
    rank: "#5 / 42",
    percentile: "You are in the top 12%",

    difficulty: {
      easy: 90,
      medium: 70,
      hard: 50,
    },

    questionsData: [
      {
        id: 1,
        question:
          "Which of the following is used to style a web page?",
        yourAnswer: "CSS",
        correctAnswer: "CSS",
        status: "correct",
        time: "32 sec",
      },
      {
        id: 2,
        question:
          "Which tag is used to create a hyperlink?",
        yourAnswer: "<a>",
        correctAnswer: "<a>",
        status: "correct",
        time: "18 sec",
      },
      {
        id: 3,
        question:
          "Which of the following is a JavaScript framework?",
        yourAnswer: "React",
        correctAnswer: "React",
        status: "correct",
        time: "45 sec",
      },
      {
        id: 4,
        question:
          "Which method is used to add an element to an array?",
        yourAnswer: "push()",
        correctAnswer: "push()",
        status: "correct",
        time: "28 sec",
      },
      {
        id: 5,
        question:
          "Which of the following is a backend framework?",
        yourAnswer: "Django",
        correctAnswer: "Express.js",
        status: "incorrect",
        time: "56 sec",
      },
      {
        id: 6,
        question:
          "Which language is primarily used for styling web pages?",
        yourAnswer: "CSS",
        correctAnswer: "CSS",
        status: "correct",
        time: "22 sec",
      },
      {
        id: 7,
        question:
          "Which HTML element is used for the largest heading?",
        yourAnswer: "h1",
        correctAnswer: "h1",
        status: "correct",
        time: "16 sec",
      },
      {
        id: 8,
        question:
          "Which JavaScript keyword declares a constant?",
        yourAnswer: "const",
        correctAnswer: "const",
        status: "correct",
        time: "24 sec",
      },
      {
        id: 9,
        question:
          "Which protocol is commonly used for secure web traffic?",
        yourAnswer: "HTTPS",
        correctAnswer: "HTTPS",
        status: "correct",
        time: "31 sec",
      },
      {
        id: 10,
        question:
          "Which database is commonly used with MongoDB applications?",
        yourAnswer: "MongoDB",
        correctAnswer: "MongoDB",
        status: "correct",
        time: "39 sec",
      },
    ],
  },
};


function mapServerResult(item, fallback) {
  if (!item) return fallback;
  const score = Number(item.percentage ?? item.score ?? 0);
  const totalMarks = Number(item.totalMarks ?? item.total ?? 0);
  const correct = Number(item.correct ?? item.correctAnswers ?? 0);
  const answered = Number(item.answered ?? correct + Number(item.incorrect ?? 0));
  const questions = Number(item.questionCount ?? totalMarks ?? answered ?? fallback.questions);
  const incorrect = Number(item.incorrect ?? Math.max(0, answered - correct));
  const notAttempted = Number(item.notAttempted ?? Math.max(0, questions - answered));
  return {
    ...fallback,
    title: item.assessment?.title || item.title || fallback.title,
    course: item.course?.title || item.course?.name || fallback.course,
    attemptedAt: item.submittedAt || item.createdAt || fallback.attemptedAt,
    duration: item.duration ? `${item.duration} Minutes` : fallback.duration,
    questions,
    score,
    correct,
    incorrect,
    notAttempted,
    timeTaken: item.timeTaken ? `${item.timeTaken} Mins` : fallback.timeTaken,
    result: item.result || (score >= 40 ? "PASS" : "FAIL"),
    questionsData: Array.isArray(item.questionsData) ? item.questionsData : fallback.questionsData,
  };
}

function getResult(id) {
  return RESULT_DATA[id] || RESULT_DATA[1];
}

/* =========================================================
   RESULT HEADER
========================================================= */

function ResultHeading({ result }) {
  return (
    <div className="assessment-result-heading">
      <Link
        to="/student/assessments"
        className="assessment-result-back"
      >
        <ArrowLeft size={18} />
        Back to Assessments
      </Link>

      <div className="assessment-result-heading__row">
        <div>
          <h1>
            {result.title} - {result.course}
          </h1>

          <div className="assessment-result-meta">
            <span>
              Attempted {result.attemptedAt}
            </span>

            <i />

            <span>
              Duration: {result.duration}
            </span>

            <i />

            <span>
              {result.questions} Questions
            </span>
          </div>
        </div>

        <div className="assessment-completed-banner">
          <div className="assessment-completed-banner__icon">
            <Trophy size={25} />
          </div>

          <div>
            <strong>Assessment Completed!</strong>
            <span>
              Great effort! Keep learning and improving.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   SCORE CARD
========================================================= */

function ScoreCard({ result }) {
  const radius = 69;
  const circumference = 2 * Math.PI * radius;
  const progress =
    circumference - (result.score / 100) * circumference;

  return (
    <section className="result-card result-score-card">
      <div className="result-score-main">
        <div className="result-score-ring">
          <svg viewBox="0 0 160 160">
            <circle
              cx="80"
              cy="80"
              r={radius}
              className="result-score-ring__track"
            />

            <circle
              cx="80"
              cy="80"
              r={radius}
              className="result-score-ring__progress"
              style={{
                strokeDasharray: circumference,
                strokeDashoffset: progress,
              }}
            />
          </svg>

          <div className="result-score-ring__content">
            <strong>{result.score}%</strong>
            <span>Your Score</span>
          </div>
        </div>

        <div className="result-score-stats">
          <ResultMetric
            variant="green"
            icon={<BarChart3 size={21} />}
            value={`${result.correct} / ${result.questions}`}
            label="Correct Answers"
          />

          <ResultMetric
            variant="blue"
            icon={<Clock3 size={21} />}
            value={result.timeTaken}
            label="Time Taken"
          />

          <ResultMetric
            variant="orange"
            icon={<BarChart3 size={21} />}
            value={result.average}
            label="Class Average"
          />
        </div>
      </div>

      <div className="result-score-message">
        <div className="result-score-message__icon">
          <Trophy size={20} />
        </div>

        <div>
          <strong>Well Done!</strong>
          <span>
            You scored higher than the class average. Keep up the
            great work!
          </span>
        </div>
      </div>
    </section>
  );
}

function ResultMetric({
  variant,
  icon,
  value,
  label,
}) {
  return (
    <div className={`result-metric result-metric--${variant}`}>
      <div className="result-metric__icon">
        {icon}
      </div>

      <div>
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}

/* =========================================================
   PERFORMANCE SUMMARY
========================================================= */

function PerformanceSummary({ result }) {
  return (
    <section className="result-card result-performance-summary">
      <div className="result-card-title">
        <h2>Performance Summary</h2>
      </div>

      <div className="result-performance-grid">
        <PerformanceMetric
          variant="green"
          icon={<BarChart3 size={20} />}
          value={result.correct}
          label="Correct"
        />

        <PerformanceMetric
          variant="red"
          icon={<BarChart3 size={20} />}
          value={result.incorrect}
          label="Incorrect"
        />

        <PerformanceMetric
          variant="slate"
          icon={<BarChart3 size={20} />}
          value={result.notAttempted}
          label="Not Attempted"
        />
      </div>
    </section>
  );
}

function PerformanceMetric({
  variant,
  icon,
  value,
  label,
}) {
  return (
    <div className={`performance-metric performance-metric--${variant}`}>
      <div className="performance-metric__icon">
        {icon}
      </div>

      <div>
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}

/* =========================================================
   RANK
========================================================= */

function RankCard({ result }) {
  return (
    <section className="result-card result-rank-card">
      <div className="result-card-title">
        <h2>Your Rank</h2>
      </div>

      <div className="result-rank-content">
        <div className="result-rank-medal">
          <Trophy size={28} />
        </div>

        <div>
          <strong>{result.rank}</strong>
          <span>{result.percentile}</span>

          <em>Great Performance!</em>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   TIME ANALYSIS
========================================================= */

function TimeAnalysis({ result }) {
  return (
    <section className="result-card result-time-card">
      <div className="result-card-title result-card-title--icon">
        <div>
          <Clock3 size={18} />
        </div>

        <h2>Time Analysis</h2>
      </div>

      <div className="result-time-grid">
        <div>
          <strong>{result.timeTaken}</strong>
          <span>Total Time</span>
        </div>

        <div>
          <strong>1.5 Mins</strong>
          <span>Avg. per Question</span>
        </div>

        <div>
          <strong>0.8 Mins</strong>
          <span>Avg. for Correct</span>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   DIFFICULTY
========================================================= */

function DifficultyPerformance({ result }) {
  const rows = [
    {
      label: "Easy",
      value: result.difficulty.easy,
      className: "easy",
    },
    {
      label: "Medium",
      value: result.difficulty.medium,
      className: "medium",
    },
    {
      label: "Hard",
      value: result.difficulty.hard,
      className: "hard",
    },
  ];

  return (
    <section className="result-card result-difficulty-card">
      <div className="result-card-title">
        <h2>Difficulty Wise Performance</h2>
      </div>

      <div className="difficulty-list">
        {rows.map((row) => (
          <div className="difficulty-row" key={row.label}>
            <span>{row.label}</span>

            <div className="difficulty-track">
              <span
                className={`difficulty-fill difficulty-fill--${row.className}`}
                style={{ width: `${row.value}%` }}
              />
            </div>

            <strong>{row.value}%</strong>
          </div>
        ))}
      </div>
    </section>
  );
}

/* =========================================================
   ANALYSIS TABS
========================================================= */

function AnalysisTabs({ activeTab, setActiveTab }) {
  const tabs = [
    {
      id: "questions",
      label: "Question Analysis",
    },
    {
      id: "topics",
      label: "Topic Wise Analysis",
    },
    {
      id: "comparison",
      label: "Comparison",
    },
    {
      id: "feedback",
      label: "Feedback",
    },
  ];

  return (
    <div className="result-analysis-tabs">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          type="button"
          className={
            activeTab === tab.id
              ? "result-analysis-tab result-analysis-tab--active"
              : "result-analysis-tab"
          }
          onClick={() => setActiveTab(tab.id)}
        >
          {tab.label}
        </button>
      ))}

      <div className="result-analysis-actions">
        <button
          type="button"
          className="result-view-answers"
        >
          <FileCheck2 size={16} />
          View Answers
        </button>

        <button
          type="button"
          className="result-download-report"
          onClick={() => window.print()}
        >
          <Download size={17} />
          Download Report
        </button>
      </div>
    </div>
  );
}

/* =========================================================
   QUESTION TABLE
========================================================= */

function QuestionAnalysis({ result }) {
  const [page, setPage] = useState(1);

  const perPage = 5;

  const totalPages = Math.ceil(
    result.questionsData.length / perPage
  );

  const startIndex = (page - 1) * perPage;

  const visibleQuestions = result.questionsData.slice(
    startIndex,
    startIndex + perPage
  );

  return (
    <div className="result-question-layout">
      <section className="result-question-card">
        <div className="result-table-wrapper">
          <table className="result-question-table">
            <thead>
              <tr>
                <th>Q. No.</th>
                <th>Question</th>
                <th>Your Answer</th>
                <th>Correct Answer</th>
                <th>Status</th>
                <th>Time Taken</th>
                <th />
              </tr>
            </thead>

            <tbody>
              {visibleQuestions.map((question) => (
                <tr key={question.id}>
                  <td>{question.id}</td>

                  <td className="question-text">
                    {question.question}
                  </td>

                  <td>{question.yourAnswer}</td>

                  <td
                    className={
                      question.status === "correct"
                        ? "correct-answer"
                        : "correct-answer correct-answer--strong"
                    }
                  >
                    {question.correctAnswer}
                  </td>

                  <td>
                    {question.status === "correct" ? (
                      <span className="question-status question-status--correct">
                        <CheckCircle2 size={14} />
                        Correct
                      </span>
                    ) : (
                      <span className="question-status question-status--incorrect">
                        <XCircle size={14} />
                        Incorrect
                      </span>
                    )}
                  </td>

                  <td>{question.time}</td>

                  <td>
                    <button
                      type="button"
                      className="question-view-button"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="result-table-footer">
          <div className="result-showing">
            <span>Show</span>

            <button type="button">
              5
              <ChevronDown size={15} />
            </button>

            <span>
              of {result.questions} questions
            </span>
          </div>

          <div className="result-pagination">
            <button
              type="button"
              disabled={page === 1}
              onClick={() =>
                setPage((current) =>
                  Math.max(1, current - 1)
                )
              }
            >
              <ChevronLeft size={15} />
            </button>

            {Array.from(
              {
                length: Math.min(totalPages, 4),
              },
              (_, index) => index + 1
            ).map((number) => (
              <button
                key={number}
                type="button"
                className={
                  page === number
                    ? "result-pagination__active"
                    : ""
                }
                onClick={() => setPage(number)}
              >
                {number}
              </button>
            ))}

            <button
              type="button"
              disabled={page === totalPages}
              onClick={() =>
                setPage((current) =>
                  Math.min(totalPages, current + 1)
                )
              }
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>
      </section>

      <NextSteps />
    </div>
  );
}

/* =========================================================
   NEXT STEPS
========================================================= */

function NextSteps() {
  return (
    <aside className="result-next-sidebar">
      <section className="result-card result-next-steps">
        <div className="result-next-title">
          <div>
            <Lightbulb size={19} />
          </div>

          <h2>Next Steps</h2>
        </div>

        <ul>
          <li>
            <CheckCircle2 size={15} />
            <span>Review incorrect answers</span>
          </li>

          <li>
            <CheckCircle2 size={15} />
            <span>Focus on weak topics</span>
          </li>

          <li>
            <Circle size={15} />
            <span>Take the post assessment</span>
          </li>

          <li>
            <Circle size={15} />
            <span>Complete remaining lessons</span>
          </li>
        </ul>

        <Link
          to="/student/courses"
          className="continue-learning-button"
        >
          Continue Learning
          <ArrowRight size={17} />
        </Link>
      </section>

      <section className="result-card result-help-card">
        <div className="result-help-icon">
          <HelpCircle size={21} />
        </div>

        <div>
          <h2>Need Help?</h2>

          <p>
            If you have any doubts about your results, feel free
            to contact our support team.
          </p>

          <button type="button">
            Contact Support
          </button>
        </div>
      </section>
    </aside>
  );
}

/* =========================================================
   FOOTER
========================================================= */

function ResultFooter() {
  return (
    <footer className="assessment-result-footer">
      <span>
        © 2025 Prime Easy Learn Training Institute. All rights
        reserved.
      </span>

      <div>
        <a href="#privacy">Privacy Policy</a>
        <span>|</span>
        <a href="#terms">Terms &amp; Conditions</a>
        <span>|</span>
        <a href="#help">Help</a>
      </div>

      <div className="assessment-result-socials">
        <span>in</span>
        <span>◎</span>
        <span>▶</span>
      </div>
    </footer>
  );
}

/* =========================================================
   MAIN COMPONENT
========================================================= */

export default function StudentAssessmentResult() {
  const { assessmentId } = useParams();
  const fallbackResult = useMemo(() => getResult(Number(assessmentId)), [assessmentId]);
  const [result, setResult] = useState(fallbackResult);
  const [activeTab, setActiveTab] = useState("questions");

  useEffect(() => {
    let active = true;
    resultApi.list({ assessmentId, attemptId: assessmentId, page: 1, pageSize: 1 })
      .then((payload) => {
        const rows = normalizeList(payload);
        const first = rows[0] || payload?.result || payload?.attempt || payload;
        if (active && first && typeof first === "object") setResult(mapServerResult(first, fallbackResult));
      })
      .catch(() => {});
    return () => { active = false; };
  }, [assessmentId, fallbackResult]);

  return (
    <StudentLayout>
      <div className="student-assessment-result">
        <main className="assessment-result-content">
          <ResultHeading result={result} />

          <div className="assessment-result-top-grid">
            <ScoreCard result={result} />

            <div className="assessment-result-middle">
              <PerformanceSummary result={result} />
              <TimeAnalysis result={result} />
            </div>

            <div className="assessment-result-right">
              <RankCard result={result} />
              <DifficultyPerformance result={result} />
            </div>
          </div>

          <section className="assessment-analysis-section">
            <AnalysisTabs
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />

            {activeTab === "questions" ? (
              <QuestionAnalysis result={result} />
            ) : (
              <div className="result-placeholder">
                <BarChart3 size={30} />
                <h2>
                  {activeTab === "topics"
                    ? "Topic Wise Analysis"
                    : activeTab === "comparison"
                      ? "Comparison"
                      : "Feedback"}
                </h2>
                <p>
                  This analysis section is ready to be connected
                  to your assessment analytics API.
                </p>
              </div>
            )}
          </section>
        </main>

        <ResultFooter />
      </div>
    </StudentLayout>
  );
}
```

## `src/trainer/TrainerLayout.jsx`

```jsx
import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { Link, NavLink } from "react-router-dom";
import { Bell, BookOpen, ChartNoAxesColumnIncreasing, CircleHelp, ClipboardList, CloudUpload, LayoutDashboard, LogOut, Menu, Search, UserRound, ChevronDown, GraduationCap } from "lucide-react";
import "./TrainerLayout.css";
import logo from "../public/assets/student/logo.jpeg";
const navigation=[['Dashboard','/trainer',LayoutDashboard,true],['My Courses','/trainer/courses',BookOpen],['Upload Content','/trainer/upload',CloudUpload],['Assessments','/trainer/assessments',ClipboardList],['Results','/trainer/results',ChartNoAxesColumnIncreasing],['Profile','/trainer/profile',UserRound]];
export default function TrainerLayout({children}){const [open,setOpen]=useState(false); const { user, logout } = useAuth(); const displayName = user?.name || user?.fullName || "Trainer";return <div className="trainer-layout">{open&&<button className="trainer-layout__backdrop" onClick={()=>setOpen(false)}/>}<aside className={`trainer-layout__sidebar ${open?'is-open':''}`}><Link className="trainer-layout__brand" to="/trainer"><img src={logo} alt="Prime Easy Learn Training Institute"/></Link><nav>{navigation.map(([label,path,Icon,end])=><NavLink end={end} onClick={()=>setOpen(false)} key={path} to={path} className={({isActive})=>`trainer-layout__nav ${isActive?'is-active':''}`}><Icon size={20}/><span>{label}</span></NavLink>)}</nav><div className="trainer-layout__nav-bottom"><NavLink to="/trainer/support" className="trainer-layout__nav"><CircleHelp size={20}/><span>Help & Support</span></NavLink><button type="button" className="trainer-layout__nav" onClick={async()=>{await logout(); window.location.href="/";}}><LogOut size={20}/><span>Logout</span></button></div><div className="trainer-layout__promo"><span>Teach<br/>Share<br/>Inspire<br/>Change Lives</span><i/><GraduationCap/><b>Better Trainers<br/>Brighter Futures</b></div></aside><div className="trainer-layout__main"><header className="trainer-layout__header"><button className="trainer-layout__menu" onClick={()=>setOpen(true)}><Menu/></button><label className="trainer-layout__search"><Search size={19}/><input placeholder="Search courses, learners, assessments..."/></label><div className="trainer-layout__account"><button><Bell size={21}/><i>3</i></button><span/><img src={user?.profileImage || "/assets/student/avatar.png"} alt={displayName}/><div><b>{displayName}</b><small>Trainer</small></div><ChevronDown size={18}/></div></header><main>{children}</main></div></div>}

```

## `src/trainer/TrainerDashboard.jsx`

```jsx
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { courseApi, normalizeList } from "../services/api";
import {
  BarChart3,
  BookOpen,
  ClipboardList,
  CloudUpload,
  FileText,
  Users,
  ArrowRight,
  CalendarDays,
} from "lucide-react";
import TrainerLayout from "./TrainerLayout";
import "./TrainerDashboard.css";

const courses = [
  [
    "Full Stack Web Development",
    "120 Learners",
    "/assets/student/course-fullstack.png",
  ],
  ["UI/UX Design", "85 Learners", "/assets/student/course-uiux.png"],
  [
    "Digital Marketing Essentials",
    "60 Learners",
    "/assets/landing/course-marketing.png",
  ],
];
export default function TrainerDashboard() {
  const [assignedCourses, setAssignedCourses] = useState(courses);

  useEffect(() => {
    let active = true;
    courseApi.trainerCourses({ page: 1, pageSize: 20 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (!active || !rows.length) return;
        setAssignedCourses(rows.map((course) => [
          course.title || course.name || "Course",
          `${course.learnerCount ?? course.learnersCount ?? 0} Learners`,
          course.thumbnail || course.thumbnailUrl || "/assets/student/course-fullstack.png",
        ]));
      })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  return (
    <TrainerLayout>
      <div className="trainer-page">
        <header className="trainer-greeting">
          <div>
            <p>Good morning, Trainer!</p>
            <span>Here’s what you can do today for your courses.</span>
          </div>
          <aside>
            “Teaching is not just a profession,
            <br />
            it’s a way to change lives.” <BookOpen />
          </aside>
        </header>
        <section className="trainer-panel trainer-courses-panel">
          <header>
            <div>
              <h1>My Assigned Courses</h1>
              <p>
                You can upload content, create assessments, and view results for
                the courses assigned to you.
              </p>
            </div>
            <Link to="/trainer/courses">
              View all <ArrowRight size={16} />
            </Link>
          </header>
          <div className="trainer-course-list">
            {assignedCourses.map(([title, learners, image]) => (
              <article className="trainer-course-row" key={title}>
                <img src={image} alt="" />
                <div className="trainer-course-info">
                  <h2>{title}</h2>
                  <p>
                    <CalendarDays size={15} /> Batch 2025 <span />
                    <Users size={15} /> {learners}
                  </p>
                </div>
                <div className="trainer-course-actions">
                  <Link
                    to="/trainer/upload"
                    className="trainer-action trainer-action--upload"
                  >
                    <CloudUpload />
                    <span>
                      <b>Upload Content</b>
                      <small>Video, PDF, PPT, etc.</small>
                    </span>
                  </Link>
                  <Link
                    to="/trainer/assessments"
                    className="trainer-action trainer-action--assessment"
                  >
                    <FileText />
                    <span>
                      <b>Create Assessment</b>
                      <small>Pre / Post Test</small>
                    </span>
                  </Link>
                  <Link
                    to="/trainer/results"
                    className="trainer-action trainer-action--results"
                  >
                    <BarChart3 />
                    <span>
                      <b>View Results</b>
                      <small>See learner performance</small>
                    </span>
                  </Link>
                </div>
                <ArrowRight className="trainer-row-arrow" size={20} />
              </article>
            ))}
          </div>
        </section>
        <section className="trainer-bottom-grid">
          <article className="trainer-panel trainer-activity">
            <header>
              <h2>Recent Activity</h2>
              <Link to="/trainer/content">
                View all <ArrowRight size={15} />
              </Link>
            </header>
            <div className="trainer-timeline">
              <p>
                <i className="blue">
                  <CloudUpload />
                </i>
                <span>
                  <b>You uploaded a video</b>
                  <small>
                    Introduction to React Hooks (Full Stack Web Development)
                  </small>
                </span>
                <time>2 hours ago</time>
              </p>
              <p>
                <i className="green">
                  <ClipboardList />
                </i>
                <span>
                  <b>You created a post assessment</b>
                  <small>
                    React Basics - Post Test (Full Stack Web Development)
                  </small>
                </span>
                <time>5 hours ago</time>
              </p>
              <p>
                <i className="purple">
                  <BarChart3 />
                </i>
                <span>
                  <b>You viewed results</b>
                  <small>UI/UX Design - Pre Test</small>
                </span>
                <time>1 day ago</time>
              </p>
            </div>
          </article>
          <article className="trainer-panel trainer-guide">
            <header>
              <h2>Quick Guide</h2>
            </header>
            <div>
              {[
                [
                  CloudUpload,
                  "1. Upload Content",
                  "Add video lectures, PDFs, PPTs or other learning material.",
                ],
                [
                  ClipboardList,
                  "2. Create Assessments",
                  "Create pre and post assessments to evaluate learner understanding.",
                ],
                [
                  BarChart3,
                  "3. View Results",
                  "Check learner performance and track progress.",
                ],
              ].map(([Icon, title, copy]) => (
                <section key={title}>
                  <i>
                    <Icon />
                  </i>
                  <b>{title}</b>
                  <p>{copy}</p>
                </section>
              ))}
            </div>
          </article>
        </section>
        <footer className="trainer-footer">
          © 2026 Prime Easy Learn Training Institute. All rights reserved.
          <span>Help | Privacy Policy | Terms & Conditions</span>
        </footer>
      </div>
    </TrainerLayout>
  );
}

```

## `src/trainer/TrainerPages.jsx`

```jsx
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  BarChart3,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  CloudUpload,
  Download,
  Eye,
  FileText,
  Lock,
  Mail,
  MapPin,
  Pencil,
  Plus,
  Save,
  Search,
  Trash2,
  Trophy,
  Upload,
  Users,
} from "lucide-react";
import TrainerLayout from "./TrainerLayout";
import "./TrainerPages.css";
import { assessmentApi, contentApi, courseApi, moduleApi, normalizeList, resultApi, apiError } from "../services/api";

const courses = [
  [
    "Full Stack Web Development",
    "Batch 2025",
    "120 Learners",
    "/assets/student/course-fullstack.png",
  ],
  [
    "UI/UX Design",
    "Batch 2025",
    "85 Learners",
    "/assets/student/course-uiux.png",
  ],
  [
    "Digital Marketing Essentials",
    "Batch 2025",
    "60 Learners",
    "/assets/landing/course-marketing.png",
  ],
];
const Field = ({ label, children }) => (
  <label className="tp-field">
    <b>{label}</b>
    {children || <input />}
  </label>
);
const Select = ({ label, children }) => (
  <Field label={label}>
    <select defaultValue="">
      <option value="" disabled>
        {children || "Select an option"}
      </option>
      <option>Full Stack Web Development</option>
      <option>UI/UX Design</option>
    </select>
  </Field>
);
const Top = ({ title, copy, actions }) => (
  <header className="tp-top">
    <div>
      <Link to="/trainer">← Back to Dashboard</Link>
      <h1>{title}</h1>
      <p>{copy}</p>
    </div>
    {actions}
  </header>
);
export function Courses() {
  const [assignedCourses, setAssignedCourses] = useState(courses);
  useEffect(() => {
    let active = true;
    courseApi.trainerCourses({ page: 1, pageSize: 50 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (active && rows.length) setAssignedCourses(rows.map((course) => ({
          id: course._id || course.id,
          name: course.title || course.name || "Course",
          batch: course.batchName || course.batch || "Assigned Course",
          learners: `${course.learnerCount ?? course.learnersCount ?? 0} Learners`,
          image: course.thumbnail || course.thumbnailUrl || "/assets/student/course-fullstack.png",
          lessons: course.lessonCount ?? course.totalLessons ?? 0,
          assessments: course.assessmentCount ?? course.totalAssessments ?? 0,
          completion: course.completionRate ?? 0,
        })));
      })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="My Courses"
          copy="Manage learning content and assessment activities for your assigned courses."
          actions={
            <Link className="tp-btn primary" to="/trainer/upload">
              <Plus /> Upload Content
            </Link>
          }
        />
        <div className="tp-course-grid">
          {assignedCourses.map((course, i) => {
            const item = Array.isArray(course) ? { name: course[0], batch: course[1], learners: course[2], image: course[3], lessons: i ? 12 : 28, assessments: i ? 3 : 6, completion: i ? 85 : 92 } : course;
            return (
              <article className="tp-course-card" key={item.id || item.name}>
                <img src={item.image} alt="" />
                <div>
                  <span className="tp-status">Active Course</span>
                  <h2>{item.name}</h2>
                  <p>
                    <CalendarDays /> {item.batch} <Users /> {item.learners}
                  </p>
                  <div className="tp-course-summary">
                    <span><b>{item.lessons}</b> Lessons</span>
                    <span><b>{item.assessments}</b> Assessments</span>
                    <span><b>{item.completion}%</b> Completion</span>
                  </div>
                  <div className="tp-card-actions">
                    <Link to="/trainer/upload">Manage Content</Link>
                    <Link to="/trainer/assessments">Assessments</Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </TrainerLayout>
  );
}
export function UploadPage() {
  const [type, setType] = useState("Video");
  const [trainerCourses, setTrainerCourses] = useState(courses.map(([name], index) => ({ id: ["full-stack", "ui-ux", "digital-marketing"][index], title: name })));
  const [modules, setModules] = useState([{ id: "module-1", title: "1. Introduction to Web Development" }]);
  const [selectedCourse, setSelectedCourse] = useState("full-stack");
  const [selectedModule, setSelectedModule] = useState("module-1");
  const [selectedFile, setSelectedFile] = useState(null);
  const [title, setTitle] = useState("Introduction to React");
  const [description, setDescription] = useState("In this video, we will learn what is React, why it is popular, and its key features. This session covers the basics to help you get started with React development.");
  const [tags, setTags] = useState("react, javascript, frontend");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    courseApi.trainerCourses({ page: 1, pageSize: 50 }).then((payload) => {
      const rows = normalizeList(payload);
      if (rows.length) {
        setTrainerCourses(rows);
        setSelectedCourse(rows[0]._id || rows[0].id);
      }
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!selectedCourse) return;
    moduleApi.list(selectedCourse).then((payload) => {
      const rows = normalizeList(payload);
      setModules(rows);
      setSelectedModule(rows[0]?._id || rows[0]?.id || "");
    }).catch(() => {});
  }, [selectedCourse]);

  const saveContent = async (status) => {
    if (!selectedCourse || !selectedModule || !title.trim()) { window.alert("Course, module and title are required."); return; }
    setSaving(true);
    try {
      let media = {};
      if (selectedFile) media = await contentApi.upload(selectedFile, type.toUpperCase());
      const payload = {
        courseId: selectedCourse, moduleId: selectedModule, title, description,
        type: type === "Video" ? "VIDEO" : type === "PDF" ? "PDF" : "PPT",
        tags: tags.split(",").map((tag) => tag.trim()).filter(Boolean),
        status, ...media,
      };
      await contentApi.create(payload);
      window.alert(status === "PUBLISHED" ? "Content published successfully." : "Content saved as draft.");
    } catch (error) { window.alert(apiError(error)); }
    finally { setSaving(false); }
  };
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="Upload Content"
          copy="Share your knowledge. Empower more learners."
        />
        <div className="tp-split">
          <section className="tp-card tp-upload-main">
            <h2>1. Select Course</h2>
            <div className="tp-three">
              <Field label="Course">
                <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}><option value="">Select an assigned course</option>{trainerCourses.map((course) => <option key={course._id || course.id} value={course._id || course.id}>{course.title || course.name}</option>)}</select>
              </Field>
              <Field label="Select Module">
                <select value={selectedModule} onChange={(e) => setSelectedModule(e.target.value)}><option value="">Select module</option>{modules.map((module) => <option key={module._id || module.id} value={module._id || module.id}>{module.title || module.name}</option>)}</select>
              </Field>
              <Field label="Select Lesson / Topic">
                <input placeholder="Enter lesson/topic" />
              </Field>
            </div>
            <h2>2. Content Type</h2>
            <div className="tp-type-tabs">
              {["Video", "PDF", "PPT", "Other File"].map((x) => (
                <button
                  onClick={() => setType(x)}
                  className={type === x ? "active" : ""}
                  key={x}
                >
                  <FileText /> {x}
                </button>
              ))}
            </div>
            <h2>3. Upload {type}</h2>
            <label className="tp-drop">
              <CloudUpload />
              <b>Drag and drop your {type.toLowerCase()} here</b>
              <span>or</span>
              <em>
                Choose File
                <input type="file" onChange={(e) => setSelectedFile(e.target.files?.[0] || null)} />
              </em>
              <small>
                Supported formats: MP4, MOV, AVI, PDF, PPTX | Max file size: 2
                GB
              </small>
            </label>
            <h2>4. Content Details</h2>
            <div className="tp-details">
              <Field label="Title *">
                <input value={title} onChange={(e) => setTitle(e.target.value)} />
              </Field>
              <Field label="Tags (comma separated)">
                <input value={tags} onChange={(e) => setTags(e.target.value)} />
              </Field>
              <Field label="Description *">
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
              </Field>
              <Select label="Language">
                <option>English</option>
              </Select>
            </div>
          </section>
          <aside className="tp-side">
            <section className="tp-card">
              <h2>Additional Settings</h2>
              <Field label="Video Duration">
                <input defaultValue="00:25:30" />
              </Field>
              <p className="tp-radio">
                <CheckCircle2 /> Free for all learners
              </p>
              <p className="tp-radio muted">○ Only for enrolled learners</p>
              {[
                "Make this content downloadable",
                "Add to student notes",
                "Schedule for later",
              ].map((x, i) => (
                <label className="tp-toggle" key={x}>
                  {x}
                  <input defaultChecked={i < 2} type="checkbox" />
                  <i />
                </label>
              ))}
            </section>
            <section className="tp-card">
              <h2>Publish</h2>
              <p className="tp-radio">
                <CheckCircle2 /> Publish Now
              </p>
              <p className="tp-radio muted">○ Save as Draft</p>
              <div className="tp-button-row">
                <button type="button" className="tp-btn" disabled={saving} onClick={() => saveContent("DRAFT")}>Save as Draft</button>
                <button type="button" className="tp-btn primary" disabled={saving} onClick={() => saveContent("PUBLISHED")}>
                  <CloudUpload /> Publish Content
                </button>
              </div>
            </section>
          </aside>
        </div>
      </div>
    </TrainerLayout>
  );
}
const DEFAULT_QUESTIONS = [
  { question: "What does HTML stand for?", type: "MCQ", options: ["Hyper Text Markup Language", "High Text Machine Language", "Hyper Transfer Markup Language", "Home Tool Markup Language"], correctAnswer: 0, marks: 1, explanation: "HTML stands for Hyper Text Markup Language." },
  { question: "Which of the following is a CSS framework?", type: "MCQ", options: ["React", "Tailwind CSS", "Node.js", "MongoDB"], correctAnswer: 1, marks: 1, explanation: "Tailwind CSS is a CSS framework." },
  { question: "Explain the difference between let, const and var in JavaScript.", type: "DESCRIPTIVE", options: [], correctAnswer: null, marks: 5, explanation: "" },
];

function QuestionEditor({ questions = DEFAULT_QUESTIONS }) {
  return (
    <section className="tp-question-editor">
      <h2>
        Questions{" "}
        <button type="button" className="tp-btn primary">
          <Plus /> Add Question
        </button>
      </h2>
      {questions.map((item, i) => (
        <article key={`${item.question}-${i}`}>
          <i>{i + 1}</i>
          <span>
            <b>{item.question}</b>
            <small>
              {item.type === "DESCRIPTIVE" ? "Descriptive" : `Multiple Choice | ${item.options.length || 4} options`}
            </small>
          </span>
          <em>{item.marks} mark</em>
          <Pencil />
          <Trash2 />
        </article>
      ))}
    </section>
  );
}
export function Assessments() {
  const [tab, setTab] = useState("Basic Details");
  const [trainerCourses, setTrainerCourses] = useState(courses.map(([name], index) => ({ id: ["full-stack", "ui-ux", "digital-marketing"][index], title: name })));
  const [selectedCourse, setSelectedCourse] = useState("full-stack");
  const [modules, setModules] = useState([{ id: "module-1", title: "1. Introduction to Web Development" }]);
  const [selectedModule, setSelectedModule] = useState("module-1");
  const [assessmentTitle, setAssessmentTitle] = useState("Module 1 - Basics of Web Development");
  const [assessmentType, setAssessmentType] = useState("POST");
  const [totalMarks, setTotalMarks] = useState(20);
  const [passingMarks, setPassingMarks] = useState(10);
  const [timeLimit, setTimeLimit] = useState(30);
  const [attemptLimit, setAttemptLimit] = useState(1);
  const [questions] = useState(DEFAULT_QUESTIONS);
  useEffect(() => { courseApi.trainerCourses({ page: 1, pageSize: 50 }).then((payload) => { const rows = normalizeList(payload); setTrainerCourses(rows); if (rows[0]) setSelectedCourse(rows[0]._id || rows[0].id); }).catch(() => {}); }, []);
  useEffect(() => { if (!selectedCourse) return; moduleApi.list(selectedCourse).then((payload) => { const rows = normalizeList(payload); setModules(rows); if (rows[0]) setSelectedModule(rows[0]._id || rows[0].id); }).catch(() => {}); }, [selectedCourse]);
  const saveAssessment = async (status) => {
    if (!selectedCourse || !assessmentTitle.trim()) return window.alert("Course and assessment title are required.");
    if (Number(passingMarks) > Number(totalMarks)) return window.alert("Passing marks cannot exceed total marks.");
    if (Number(attemptLimit) < 1) return window.alert("Attempt limit must be at least 1.");
    try { await assessmentApi.create({ title: assessmentTitle, courseId: selectedCourse, moduleId: selectedModule || undefined, type: assessmentType, totalMarks: Number(totalMarks), passingMarks: Number(passingMarks), duration: Number(timeLimit), attemptLimit: Number(attemptLimit), questions, status }); window.alert(status === "PUBLISHED" ? "Assessment published successfully." : "Assessment saved as draft."); } catch (error) { window.alert(apiError(error)); }
  };
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="Create Assessment"
          copy="Build quizzes, tests or assignments to evaluate learner understanding."
          actions={
            <div className="tp-button-row">
              <button type="button" className="tp-btn" onClick={() => saveAssessment("DRAFT")}>
                <Save /> Save as Draft
              </button>
              <button type="button" className="tp-btn primary" onClick={() => saveAssessment("PUBLISHED")}>Publish Assessment</button>
            </div>
          }
        />
        <div className="tp-assessment-course">
          <img src="/assets/student/course-fullstack.png" alt="" />
          <span>
            <b>Full Stack Web Development</b>
            <small>
              <CalendarDays /> Batch 2025 <Users /> 120 Learners
            </small>
          </span>
        </div>
        <div className="tp-assessment-layout">
          <section className="tp-card">
            <nav className="tp-tabs">
              {["Basic Details", "Questions", "Settings", "Preview"].map(
                (x) => (
                  <button
                    onClick={() => setTab(x)}
                    className={tab === x ? "active" : ""}
                    key={x}
                  >
                    {x}
                  </button>
                ),
              )}
            </nav>
            {tab === "Basic Details" ? (
              <>
                <h2>Assessment Details</h2>
                <Field label="Assessment Title *">
                  <input value={assessmentTitle} onChange={(e) => setAssessmentTitle(e.target.value)} />
                </Field>
                <div className="tp-two">
                  <Field label="Course *">
                    <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}><option value="">Select course</option>{trainerCourses.map((course) => <option key={course._id || course.id} value={course._id || course.id}>{course.title || course.name}</option>)}</select>
                  </Field>
                  <Field label="Module / Topic *">
                    <select value={selectedModule} onChange={(e) => setSelectedModule(e.target.value)}><option value="">Select module</option>{modules.map((module) => <option key={module._id || module.id} value={module._id || module.id}>{module.title || module.name}</option>)}</select>
                  </Field>
                </div>
                <b className="tp-label">Assessment Type *</b>
                <div className="tp-two tp-radio-boxes">
                  <p onClick={() => setAssessmentType("PRE")}>
                    {assessmentType === "PRE" ? <CheckCircle2 /> : "○"} <b>Pre-Assessment</b>
                    <small>Evaluate learners before the module</small>
                  </p>
                  <p onClick={() => setAssessmentType("POST")}>
                    {assessmentType === "POST" ? <CheckCircle2 /> : "○"} <b>Post-Assessment</b>
                    <small>Evaluate learners after the module</small>
                  </p>
                </div>
                <Field label="Description (Optional)">
                  <textarea defaultValue="This test evaluates your understanding of the key concepts covered in this module." />
                </Field>
              </>
            ) : (
              <QuestionEditor questions={questions} />
            )}
          </section>
          <aside className="tp-side">
            <section className="tp-card">
              <h2>Assessment Settings</h2>
              <div className="tp-two">
                <Field label="Total Marks *">
                  <input type="number" value={totalMarks} onChange={(e) => setTotalMarks(e.target.value)} />
                </Field>
                <Field label="Passing Marks *">
                  <input type="number" value={passingMarks} onChange={(e) => setPassingMarks(e.target.value)} />
                </Field>
                <Field label="Time Limit">
                  <input type="number" value={timeLimit} onChange={(e) => setTimeLimit(e.target.value)} />
                </Field>
                <Field label="Attempt Limit">
                  <input type="number" value={attemptLimit} onChange={(e) => setAttemptLimit(e.target.value)} />
                </Field>
              </div>
              {[
                "Show Results to Learners",
                "Shuffle Questions",
                "Shuffle Options",
              ].map((x) => (
                <label className="tp-toggle" key={x}>
                  {x}
                  <input defaultChecked type="checkbox" />
                  <i />
                </label>
              ))}
            </section>
            <section className="tp-card">
              <h2>Question Types</h2>
              <div className="tp-question-types">
                <button className="active">◉ Multiple Choice</button>
                <button>☑ Multiple Select</button>
                <button>✓ True / False</button>
                <button>▤ Descriptive</button>
              </div>
            </section>
          </aside>
        </div>
      </div>
    </TrainerLayout>
  );
}
export function Results() {
  const [resultRows, setResultRows] = useState([]);
  useEffect(() => { resultApi.trainerList({ page: 1, pageSize: 50 }).then((payload) => { const rows = normalizeList(payload); if (rows.length) setResultRows(rows); }).catch(() => {}); }, []);
  const learners = [
    "Aarav Kumar",
    "Priya Sharma",
    "Rohan Mehta",
    "Sneha Verma",
    "Aditya Singh",
    "Kavya Patel",
  ];
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="Assessment Results"
          copy="View and analyze learner performance for your assessments."
        />
        <div className="tp-filter">
          <Select label="Course">
            <option>Full Stack Web Development</option>
          </Select>
          <Select label="Module / Topic">
            <option>1. Introduction to Web Development</option>
          </Select>
        </div>
        <div className="tp-result-stats">
          {[
            [Users, "48", "Total Attempts"],
            [CheckCircle2, "38", "Passed"],
            [Trash2, "10", "Failed"],
            [Trophy, "76%", "Average Score"],
          ].map(([Icon, num, label]) => (
            <article key={label}>
              <Icon />
              <span>
                <b>{num}</b>
                <small>{label}</small>
              </span>
            </article>
          ))}
        </div>
        <div className="tp-results-grid">
          <section className="tp-card tp-table-card">
            <header>
              <h2>
                Learner Results <small>(48)</small>
              </h2>
              <button className="tp-btn">
                <Download /> Export Results
              </button>
            </header>
            <label className="tp-table-search">
              <Search />
              <input placeholder="Search by learner name, email, or enrollment ID" />
            </label>
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Learner Name</th>
                  <th>Attempt Date</th>
                  <th>Score</th>
                  <th>Percentage</th>
                  <th>Result</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {(resultRows.length ? resultRows : learners.map((name) => ({ learner: { name }, learnerName: name }))).map((row, i) => {
                  const x = row.learner?.name || row.learnerName || row.name || learners[i] || "Learner";
                  const pass = String(row.result || "PASS").toUpperCase() === "PASS";
                  const percentage = row.percentage ?? (pass ? 90 - i * 5 : 40);
                  return (
                    <tr key={x}>
                      <td>{i + 1}</td>
                      <td>{x}</td>
                      <td>
                        {row.submittedAt ? new Date(row.submittedAt).toLocaleString() : `${25 - i} Sep 2025, 10:${15 + i} AM`}
                      </td>
                      <td>{row.score ?? (pass ? 18 - i : 8)}/20</td>
                      <td>{percentage}%</td>
                      <td>
                        <span className={`tp-pill ${pass ? "pass" : "fail"}`}>
                          {pass ? "Pass" : "Fail"}
                        </span>
                      </td>
                      <td>
                        <Eye size={17} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </section>
          <aside className="tp-result-side">
            <section className="tp-card">
              <h2>Performance Overview</h2>
              <div className="tp-chart">
                {[8, 25, 30, 67, 100].map((x, i) => (
                  <i key={i} style={{ height: `${x}%` }}>
                    <small>
                      {["0-20", "21-40", "41-60", "61-80", "81-100"][i]}%
                    </small>
                  </i>
                ))}
              </div>
            </section>
            <section className="tp-card">
              <h2>Score Distribution</h2>
              <div className="tp-donut">
                <b>
                  48<small>Attempts</small>
                </b>
              </div>
              <p className="tp-legend">
                ● 81-100% 42%
                <br />● 61-80% 29%
                <br />● 41-60% 17%
              </p>
            </section>
          </aside>
        </div>
      </div>
    </TrainerLayout>
  );
}
export function Profile() {
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="My Profile"
          copy="Manage your personal information, preferences, and account settings."
          actions={
            <button className="tp-btn">
              <Eye /> View Public Profile
            </button>
          }
        />
        <section className="tp-profile-hero">
          <img src="/assets/student/avatar.png" alt="Neha Sharma" />
          <div>
            <h2>
              Neha Sharma <span>Active</span>
            </h2>
            <p>Trainer | Subject Matter Expert</p>
            <small>
              <Mail /> neha.sharma@primeeasylearn.com <MapPin /> New Delhi,
              India
            </small>
          </div>
          <div className="tp-profile-numbers">
            <span>
              <BookOpen />
              <b>3</b>Assigned Courses
            </span>
            <span>
              <Users />
              <b>245</b>Total Learners
            </span>
            <span>
              <Trophy />
              <b>4.8</b>Trainer Rating
            </span>
          </div>
        </section>
        <div className="tp-profile-grid">
          <section className="tp-card">
            <nav className="tp-tabs">
              <button className="active">Personal Information</button>
              <button>Professional Details</button>
              <button>Preferences</button>
            </nav>
            <h2>Personal Information</h2>
            <p>Keep your personal details up to date.</p>
            <div className="tp-two">
              <Field label="Full Name *">
                <input defaultValue="Neha Sharma" />
              </Field>
              <Select label="Gender">
                <option>Female</option>
              </Select>
              <Field label="Email Address *">
                <input defaultValue="neha.sharma@primeeasylearn.com" />
              </Field>
              <Field label="Location">
                <input defaultValue="New Delhi, India" />
              </Field>
              <Field label="Phone Number *">
                <input defaultValue="+91 98765 43210" />
              </Field>
              <Field label="Address">
                <textarea defaultValue="A-123, Sector 62, Noida, Uttar Pradesh - 201309" />
              </Field>
              <Field label="Date of Birth">
                <input defaultValue="15 Mar 1992" />
              </Field>
              <Field label="Bio">
                <textarea defaultValue="Passionate about teaching and helping students build strong fundamentals in technology." />
              </Field>
            </div>
            <div className="tp-button-row end">
              <button className="tp-btn">Cancel</button>
              <button className="tp-btn primary">
                <Save /> Save Changes
              </button>
            </div>
          </section>
          <aside className="tp-side">
            <section className="tp-card tp-photo">
              <h2>Profile Photo</h2>
              <img src="/assets/student/avatar.png" alt="" />
              <p>
                Upload a new profile photo
                <br />
                <small>JPG, PNG (Max 2 MB)</small>
              </p>
              <button className="tp-btn">
                <Upload /> Change Photo
              </button>
            </section>
            <section className="tp-card">
              <h2>
                <Lock /> Change Password
              </h2>
              {["Current Password", "New Password", "Confirm New Password"].map(
                (x) => (
                  <Field key={x} label={x}>
                    <input
                      placeholder={`Enter ${x.toLowerCase()}`}
                      type="password"
                    />
                  </Field>
                ),
              )}
              <button className="tp-btn primary full">Update Password</button>
            </section>
            <section className="tp-card">
              <h2>Notification Preferences</h2>
              {["Email Notifications", "Platform Notifications"].map((x) => (
                <label className="tp-toggle" key={x}>
                  {x}
                  <input defaultChecked type="checkbox" />
                  <i />
                </label>
              ))}
            </section>
          </aside>
        </div>
      </div>
    </TrainerLayout>
  );
}
export function Support() {
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="Help & Support"
          copy="Find answers or contact the Prime Easy Learn support team."
        />
        <div className="tp-help-grid">
          {[
            [
              "Course & Content Help",
              "Guidance for uploading and organizing your course material.",
              BookOpen,
            ],
            [
              "Assessment Help",
              "Create, publish, and review learner assessments.",
              FileText,
            ],
            [
              "Reports & Results",
              "Understand performance analytics and exported reports.",
              BarChart3,
            ],
            [
              "Contact Support",
              "Our team is ready to help with your account.",
              Mail,
            ],
          ].map(([a, b, Icon]) => (
            <article className="tp-card" key={a}>
              <Icon />
              <h2>{a}</h2>
              <p>{b}</p>
              <button className="tp-btn">Get help</button>
            </article>
          ))}
        </div>
      </div>
    </TrainerLayout>
  );
}

```

## `.env.example`

```env
# Prime Easy Learn backend API
VITE_API_BASE_URL=http://localhost:5000

```

