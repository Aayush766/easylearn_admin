import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  GraduationCap,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { apiError } from "../../services/api";
import "./LoginPage.css";

function LoginPage() {
  const { portal = "student" } = useParams();

const isTrainer = portal === "trainer";
const role = isTrainer ? "trainer" : "student";
const label = isTrainer ? "Trainer" : "Student";
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  return (
    <main className="pel-auth">
      <div className="pel-auth__orb pel-auth__orb--one" />
      <div className="pel-auth__orb pel-auth__orb--two" />

      <section className="pel-auth__intro">
        <div className="pel-auth__intro-inner">
          <Link className="pel-auth-brand" to="/">
            <span className="pel-auth-brand__mark">
              <span />
            </span>
            <span className="pel-auth-brand__text">
              <strong>Prime</strong>
              <b>Easy Learn</b>
              <small>Training Institute</small>
            </span>
          </Link>

          <div className="pel-auth__hero-copy">
            <span className="pel-auth__eyebrow">
              <Sparkles size={13} /> Learn. Assess. Improve.
            </span>

            <h1>
              Your next
              <br />
              <span>achievement</span>
              <br />
              starts here.
            </h1>

            <p>
              {isTrainer
                ? "Manage your courses, guide learners, and make every training session count."
                : "Access practical courses, track your progress, and celebrate every milestone."}
            </p>

            <div className="pel-auth__benefits">
              <div>
                <CheckCircle2 />
                <span>
                  <b>Practical learning</b>
                  Real-world skills
                </span>
              </div>
              <div>
                <CheckCircle2 />
                <span>
                  <b>Expert support</b>
                  Learn with confidence
                </span>
              </div>
              <div>
                <CheckCircle2 />
                <span>
                  <b>Track progress</b>
                  See your growth
                </span>
              </div>
            </div>
          </div>

          <div className="pel-auth__floating-card">
            <span className="pel-auth__floating-icon">
              {isTrainer ? <Users size={19} /> : <GraduationCap size={19} />}
            </span>
            <div>
              <strong>{isTrainer ? "Train with impact" : "Keep learning"}</strong>
              <small>{isTrainer ? "Empower your learners" : "Build your future"}</small>
            </div>
            <span className="pel-auth__floating-check">✓</span>
          </div>

          <Link className="pel-auth__back" to="/">
            <ArrowLeft size={16} />
            Back to home
          </Link>
        </div>
      </section>

      <section className="pel-auth__form-area">
        <div className="pel-auth__card">
          <div className="pel-auth__card-top">
            <span className={`pel-auth__role-icon ${isTrainer ? "trainer" : ""}`}>
              {isTrainer ? <Users size={22} /> : <GraduationCap size={22} />}
            </span>
            <span className="pel-auth__secure">
              <ShieldCheck size={14} /> Secure Login
            </span>
          </div>

          <div className="pel-auth__heading">
            <span className="pel-auth__small-label">WELCOME BACK</span>
            <h2>Login as {label}</h2>
            <p>
              {isTrainer
                ? "Sign in to access your trainer dashboard."
                : "Enter your details to continue to your learning space."}
            </p>
          </div>

          <form
            onSubmit={async (event) => {
              event.preventDefault();
              if (submitting) return;
              setSubmitting(true);
              try {
                const loggedIn = await login({ email, password, role: isTrainer ? "TRAINER" : "LEARNER" });
                const serverRole = String(loggedIn?.role || loggedIn?.user?.role || (isTrainer ? "TRAINER" : "LEARNER")).toUpperCase();
                if (isTrainer && serverRole !== "TRAINER") throw new Error("This account is not a Trainer account.");
                if (!isTrainer && !["LEARNER", "STUDENT"].includes(serverRole)) throw new Error("This account is not a Learner account.");
                navigate(isTrainer ? "/trainer" : "/student", { replace: true });
              } catch (err) {
                window.alert(apiError(err));
              } finally {
                setSubmitting(false);
              }
            }}
            className="pel-auth__form"
          >
            <label className="pel-field">
              <span>Email address</span>
              <div className="pel-field__input">
                <Mail size={17} />
                <input
                  name="email"
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@example.com"
                  autoComplete="email"
                />
              </div>
            </label>

            <label className="pel-field">
              <span>Password</span>
              <div className="pel-field__input">
                <LockKeyhole size={17} />
                <input
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="pel-password-toggle"
                  onClick={() => setShowPassword((value) => !value)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </label>

            <div className="pel-auth__form-row">
              <label className="pel-remember">
                <input type="checkbox" />
                <span>Remember me</span>
              </label>
              <a href="#forgot">Forgot password?</a>
            </div>

            <a
              className="pel-auth__submit"
              href={`/${role}`}
              onClick={async (event) => {
                event.preventDefault();
                if (submitting) return;
                setSubmitting(true);
                try {
                  const loggedIn = await login({ email, password, role: isTrainer ? "TRAINER" : "LEARNER" });
                  const serverRole = String(loggedIn?.role || loggedIn?.user?.role || (isTrainer ? "TRAINER" : "LEARNER")).toUpperCase();
                  if (isTrainer && serverRole !== "TRAINER") throw new Error("This account is not a Trainer account.");
                  if (!isTrainer && !["LEARNER", "STUDENT"].includes(serverRole)) throw new Error("This account is not a Learner account.");
                  navigate(isTrainer ? "/trainer" : "/student", { replace: true });
                } catch (err) {
                  window.alert(apiError(err));
                } finally {
                  setSubmitting(false);
                }
              }}
            >
              <span>`Login to ${label} Portal`</span>
              <ArrowRight size={18} />
            </a>
          </form>

          <div className="pel-auth__divider">
            <span>or</span>
          </div>

          <p className="pel-auth__switch">
            Looking for a different portal?{" "}
            <Link to={`/login/${isTrainer ? "student" : "trainer"}`}>
  Login as {isTrainer ? "Student" : "Trainer"}
</Link>
          </p>

          <div className="pel-auth__privacy">
            <ShieldCheck size={13} />
            <span>Your account information is protected and securely handled.</span>
          </div>
        </div>

        <p className="pel-auth__copyright">
          © 2026 Prime Easy Learn Training Institute
        </p>
      </section>
    </main>
  );
}

export default LoginPage;
