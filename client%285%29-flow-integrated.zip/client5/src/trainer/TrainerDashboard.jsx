import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { courseApi, normalizeList } from "../services/api";
import {
  BarChart3,
  BookOpen,
  ClipboardList,
  CloudUpload,
  FileText,
  Users,
  ArrowRight,
  CalendarDays,
} from "lucide-react";
import TrainerLayout from "./TrainerLayout";
import "./TrainerDashboard.css";

const courses = [
  [
    "Full Stack Web Development",
    "120 Learners",
    "/assets/student/course-fullstack.png",
  ],
  ["UI/UX Design", "85 Learners", "/assets/student/course-uiux.png"],
  [
    "Digital Marketing Essentials",
    "60 Learners",
    "/assets/landing/course-marketing.png",
  ],
];
export default function TrainerDashboard() {
  const [assignedCourses, setAssignedCourses] = useState(courses);

  useEffect(() => {
    let active = true;
    courseApi.trainerCourses({ page: 1, pageSize: 20 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (!active || !rows.length) return;
        setAssignedCourses(rows.map((course) => [
          course.title || course.name || "Course",
          `${course.learnerCount ?? course.learnersCount ?? 0} Learners`,
          course.thumbnail || course.thumbnailUrl || "/assets/student/course-fullstack.png",
        ]));
      })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  return (
    <TrainerLayout>
      <div className="trainer-page">
        <header className="trainer-greeting">
          <div>
            <p>Good morning, Trainer!</p>
            <span>Here’s what you can do today for your courses.</span>
          </div>
          <aside>
            “Teaching is not just a profession,
            <br />
            it’s a way to change lives.” <BookOpen />
          </aside>
        </header>
        <section className="trainer-panel trainer-courses-panel">
          <header>
            <div>
              <h1>My Assigned Courses</h1>
              <p>
                You can upload content, create assessments, and view results for
                the courses assigned to you.
              </p>
            </div>
            <Link to="/trainer/courses">
              View all <ArrowRight size={16} />
            </Link>
          </header>
          <div className="trainer-course-list">
            {assignedCourses.map(([title, learners, image]) => (
              <article className="trainer-course-row" key={title}>
                <img src={image} alt="" />
                <div className="trainer-course-info">
                  <h2>{title}</h2>
                  <p>
                    <CalendarDays size={15} /> Batch 2025 <span />
                    <Users size={15} /> {learners}
                  </p>
                </div>
                <div className="trainer-course-actions">
                  <Link
                    to="/trainer/upload"
                    className="trainer-action trainer-action--upload"
                  >
                    <CloudUpload />
                    <span>
                      <b>Upload Content</b>
                      <small>Video, PDF, PPT, etc.</small>
                    </span>
                  </Link>
                  <Link
                    to="/trainer/assessments"
                    className="trainer-action trainer-action--assessment"
                  >
                    <FileText />
                    <span>
                      <b>Create Assessment</b>
                      <small>Pre / Post Test</small>
                    </span>
                  </Link>
                  <Link
                    to="/trainer/results"
                    className="trainer-action trainer-action--results"
                  >
                    <BarChart3 />
                    <span>
                      <b>View Results</b>
                      <small>See learner performance</small>
                    </span>
                  </Link>
                </div>
                <ArrowRight className="trainer-row-arrow" size={20} />
              </article>
            ))}
          </div>
        </section>
        <section className="trainer-bottom-grid">
          <article className="trainer-panel trainer-activity">
            <header>
              <h2>Recent Activity</h2>
              <Link to="/trainer/content">
                View all <ArrowRight size={15} />
              </Link>
            </header>
            <div className="trainer-timeline">
              <p>
                <i className="blue">
                  <CloudUpload />
                </i>
                <span>
                  <b>You uploaded a video</b>
                  <small>
                    Introduction to React Hooks (Full Stack Web Development)
                  </small>
                </span>
                <time>2 hours ago</time>
              </p>
              <p>
                <i className="green">
                  <ClipboardList />
                </i>
                <span>
                  <b>You created a post assessment</b>
                  <small>
                    React Basics - Post Test (Full Stack Web Development)
                  </small>
                </span>
                <time>5 hours ago</time>
              </p>
              <p>
                <i className="purple">
                  <BarChart3 />
                </i>
                <span>
                  <b>You viewed results</b>
                  <small>UI/UX Design - Pre Test</small>
                </span>
                <time>1 day ago</time>
              </p>
            </div>
          </article>
          <article className="trainer-panel trainer-guide">
            <header>
              <h2>Quick Guide</h2>
            </header>
            <div>
              {[
                [
                  CloudUpload,
                  "1. Upload Content",
                  "Add video lectures, PDFs, PPTs or other learning material.",
                ],
                [
                  ClipboardList,
                  "2. Create Assessments",
                  "Create pre and post assessments to evaluate learner understanding.",
                ],
                [
                  BarChart3,
                  "3. View Results",
                  "Check learner performance and track progress.",
                ],
              ].map(([Icon, title, copy]) => (
                <section key={title}>
                  <i>
                    <Icon />
                  </i>
                  <b>{title}</b>
                  <p>{copy}</p>
                </section>
              ))}
            </div>
          </article>
        </section>
        <footer className="trainer-footer">
          © 2026 Prime Easy Learn Training Institute. All rights reserved.
          <span>Help | Privacy Policy | Terms & Conditions</span>
        </footer>
      </div>
    </TrainerLayout>
  );
}
