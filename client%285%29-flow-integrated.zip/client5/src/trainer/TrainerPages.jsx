import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  BarChart3,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  CloudUpload,
  Download,
  Eye,
  FileText,
  Lock,
  Mail,
  MapPin,
  Pencil,
  Plus,
  Save,
  Search,
  Trash2,
  Trophy,
  Upload,
  Users,
} from "lucide-react";
import TrainerLayout from "./TrainerLayout";
import "./TrainerPages.css";
import { assessmentApi, contentApi, courseApi, moduleApi, normalizeList, resultApi, apiError } from "../services/api";

const courses = [
  [
    "Full Stack Web Development",
    "Batch 2025",
    "120 Learners",
    "/assets/student/course-fullstack.png",
  ],
  [
    "UI/UX Design",
    "Batch 2025",
    "85 Learners",
    "/assets/student/course-uiux.png",
  ],
  [
    "Digital Marketing Essentials",
    "Batch 2025",
    "60 Learners",
    "/assets/landing/course-marketing.png",
  ],
];
const Field = ({ label, children }) => (
  <label className="tp-field">
    <b>{label}</b>
    {children || <input />}
  </label>
);
const Select = ({ label, children }) => (
  <Field label={label}>
    <select defaultValue="">
      <option value="" disabled>
        {children || "Select an option"}
      </option>
      <option>Full Stack Web Development</option>
      <option>UI/UX Design</option>
    </select>
  </Field>
);
const Top = ({ title, copy, actions }) => (
  <header className="tp-top">
    <div>
      <Link to="/trainer">← Back to Dashboard</Link>
      <h1>{title}</h1>
      <p>{copy}</p>
    </div>
    {actions}
  </header>
);
export function Courses() {
  const [assignedCourses, setAssignedCourses] = useState(courses);
  useEffect(() => {
    let active = true;
    courseApi.trainerCourses({ page: 1, pageSize: 50 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (active && rows.length) setAssignedCourses(rows.map((course) => ({
          id: course._id || course.id,
          name: course.title || course.name || "Course",
          batch: course.batchName || course.batch || "Assigned Course",
          learners: `${course.learnerCount ?? course.learnersCount ?? 0} Learners`,
          image: course.thumbnail || course.thumbnailUrl || "/assets/student/course-fullstack.png",
          lessons: course.lessonCount ?? course.totalLessons ?? 0,
          assessments: course.assessmentCount ?? course.totalAssessments ?? 0,
          completion: course.completionRate ?? 0,
        })));
      })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="My Courses"
          copy="Manage learning content and assessment activities for your assigned courses."
          actions={
            <Link className="tp-btn primary" to="/trainer/upload">
              <Plus /> Upload Content
            </Link>
          }
        />
        <div className="tp-course-grid">
          {assignedCourses.map((course, i) => {
            const item = Array.isArray(course) ? { name: course[0], batch: course[1], learners: course[2], image: course[3], lessons: i ? 12 : 28, assessments: i ? 3 : 6, completion: i ? 85 : 92 } : course;
            return (
              <article className="tp-course-card" key={item.id || item.name}>
                <img src={item.image} alt="" />
                <div>
                  <span className="tp-status">Active Course</span>
                  <h2>{item.name}</h2>
                  <p>
                    <CalendarDays /> {item.batch} <Users /> {item.learners}
                  </p>
                  <div className="tp-course-summary">
                    <span><b>{item.lessons}</b> Lessons</span>
                    <span><b>{item.assessments}</b> Assessments</span>
                    <span><b>{item.completion}%</b> Completion</span>
                  </div>
                  <div className="tp-card-actions">
                    <Link to="/trainer/upload">Manage Content</Link>
                    <Link to="/trainer/assessments">Assessments</Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </TrainerLayout>
  );
}
export function UploadPage() {
  const [type, setType] = useState("Video");
  const [trainerCourses, setTrainerCourses] = useState(courses.map(([name], index) => ({ id: ["full-stack", "ui-ux", "digital-marketing"][index], title: name })));
  const [modules, setModules] = useState([{ id: "module-1", title: "1. Introduction to Web Development" }]);
  const [selectedCourse, setSelectedCourse] = useState("full-stack");
  const [selectedModule, setSelectedModule] = useState("module-1");
  const [selectedFile, setSelectedFile] = useState(null);
  const [title, setTitle] = useState("Introduction to React");
  const [description, setDescription] = useState("In this video, we will learn what is React, why it is popular, and its key features. This session covers the basics to help you get started with React development.");
  const [tags, setTags] = useState("react, javascript, frontend");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    courseApi.trainerCourses({ page: 1, pageSize: 50 }).then((payload) => {
      const rows = normalizeList(payload);
      if (rows.length) {
        setTrainerCourses(rows);
        setSelectedCourse(rows[0]._id || rows[0].id);
      }
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!selectedCourse) return;
    moduleApi.list(selectedCourse).then((payload) => {
      const rows = normalizeList(payload);
      setModules(rows);
      setSelectedModule(rows[0]?._id || rows[0]?.id || "");
    }).catch(() => {});
  }, [selectedCourse]);

  const saveContent = async (status) => {
    if (!selectedCourse || !selectedModule || !title.trim()) { window.alert("Course, module and title are required."); return; }
    setSaving(true);
    try {
      let media = {};
      if (selectedFile) media = await contentApi.upload(selectedFile, type.toUpperCase());
      const payload = {
        courseId: selectedCourse, moduleId: selectedModule, title, description,
        type: type === "Video" ? "VIDEO" : type === "PDF" ? "PDF" : "PPT",
        tags: tags.split(",").map((tag) => tag.trim()).filter(Boolean),
        status, ...media,
      };
      await contentApi.create(payload);
      window.alert(status === "PUBLISHED" ? "Content published successfully." : "Content saved as draft.");
    } catch (error) { window.alert(apiError(error)); }
    finally { setSaving(false); }
  };
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="Upload Content"
          copy="Share your knowledge. Empower more learners."
        />
        <div className="tp-split">
          <section className="tp-card tp-upload-main">
            <h2>1. Select Course</h2>
            <div className="tp-three">
              <Field label="Course">
                <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}><option value="">Select an assigned course</option>{trainerCourses.map((course) => <option key={course._id || course.id} value={course._id || course.id}>{course.title || course.name}</option>)}</select>
              </Field>
              <Field label="Select Module">
                <select value={selectedModule} onChange={(e) => setSelectedModule(e.target.value)}><option value="">Select module</option>{modules.map((module) => <option key={module._id || module.id} value={module._id || module.id}>{module.title || module.name}</option>)}</select>
              </Field>
              <Field label="Select Lesson / Topic">
                <input placeholder="Enter lesson/topic" />
              </Field>
            </div>
            <h2>2. Content Type</h2>
            <div className="tp-type-tabs">
              {["Video", "PDF", "PPT", "Other File"].map((x) => (
                <button
                  onClick={() => setType(x)}
                  className={type === x ? "active" : ""}
                  key={x}
                >
                  <FileText /> {x}
                </button>
              ))}
            </div>
            <h2>3. Upload {type}</h2>
            <label className="tp-drop">
              <CloudUpload />
              <b>Drag and drop your {type.toLowerCase()} here</b>
              <span>or</span>
              <em>
                Choose File
                <input type="file" onChange={(e) => setSelectedFile(e.target.files?.[0] || null)} />
              </em>
              <small>
                Supported formats: MP4, MOV, AVI, PDF, PPTX | Max file size: 2
                GB
              </small>
            </label>
            <h2>4. Content Details</h2>
            <div className="tp-details">
              <Field label="Title *">
                <input value={title} onChange={(e) => setTitle(e.target.value)} />
              </Field>
              <Field label="Tags (comma separated)">
                <input value={tags} onChange={(e) => setTags(e.target.value)} />
              </Field>
              <Field label="Description *">
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
              </Field>
              <Select label="Language">
                <option>English</option>
              </Select>
            </div>
          </section>
          <aside className="tp-side">
            <section className="tp-card">
              <h2>Additional Settings</h2>
              <Field label="Video Duration">
                <input defaultValue="00:25:30" />
              </Field>
              <p className="tp-radio">
                <CheckCircle2 /> Free for all learners
              </p>
              <p className="tp-radio muted">○ Only for enrolled learners</p>
              {[
                "Make this content downloadable",
                "Add to student notes",
                "Schedule for later",
              ].map((x, i) => (
                <label className="tp-toggle" key={x}>
                  {x}
                  <input defaultChecked={i < 2} type="checkbox" />
                  <i />
                </label>
              ))}
            </section>
            <section className="tp-card">
              <h2>Publish</h2>
              <p className="tp-radio">
                <CheckCircle2 /> Publish Now
              </p>
              <p className="tp-radio muted">○ Save as Draft</p>
              <div className="tp-button-row">
                <button type="button" className="tp-btn" disabled={saving} onClick={() => saveContent("DRAFT")}>Save as Draft</button>
                <button type="button" className="tp-btn primary" disabled={saving} onClick={() => saveContent("PUBLISHED")}>
                  <CloudUpload /> Publish Content
                </button>
              </div>
            </section>
          </aside>
        </div>
      </div>
    </TrainerLayout>
  );
}
const DEFAULT_QUESTIONS = [
  { question: "What does HTML stand for?", type: "MCQ", options: ["Hyper Text Markup Language", "High Text Machine Language", "Hyper Transfer Markup Language", "Home Tool Markup Language"], correctAnswer: 0, marks: 1, explanation: "HTML stands for Hyper Text Markup Language." },
  { question: "Which of the following is a CSS framework?", type: "MCQ", options: ["React", "Tailwind CSS", "Node.js", "MongoDB"], correctAnswer: 1, marks: 1, explanation: "Tailwind CSS is a CSS framework." },
  { question: "Explain the difference between let, const and var in JavaScript.", type: "DESCRIPTIVE", options: [], correctAnswer: null, marks: 5, explanation: "" },
];

function QuestionEditor({ questions = DEFAULT_QUESTIONS }) {
  return (
    <section className="tp-question-editor">
      <h2>
        Questions{" "}
        <button type="button" className="tp-btn primary">
          <Plus /> Add Question
        </button>
      </h2>
      {questions.map((item, i) => (
        <article key={`${item.question}-${i}`}>
          <i>{i + 1}</i>
          <span>
            <b>{item.question}</b>
            <small>
              {item.type === "DESCRIPTIVE" ? "Descriptive" : `Multiple Choice | ${item.options.length || 4} options`}
            </small>
          </span>
          <em>{item.marks} mark</em>
          <Pencil />
          <Trash2 />
        </article>
      ))}
    </section>
  );
}
export function Assessments() {
  const [tab, setTab] = useState("Basic Details");
  const [trainerCourses, setTrainerCourses] = useState(courses.map(([name], index) => ({ id: ["full-stack", "ui-ux", "digital-marketing"][index], title: name })));
  const [selectedCourse, setSelectedCourse] = useState("full-stack");
  const [modules, setModules] = useState([{ id: "module-1", title: "1. Introduction to Web Development" }]);
  const [selectedModule, setSelectedModule] = useState("module-1");
  const [assessmentTitle, setAssessmentTitle] = useState("Module 1 - Basics of Web Development");
  const [assessmentType, setAssessmentType] = useState("POST");
  const [totalMarks, setTotalMarks] = useState(20);
  const [passingMarks, setPassingMarks] = useState(10);
  const [timeLimit, setTimeLimit] = useState(30);
  const [attemptLimit, setAttemptLimit] = useState(1);
  const [questions] = useState(DEFAULT_QUESTIONS);
  useEffect(() => { courseApi.trainerCourses({ page: 1, pageSize: 50 }).then((payload) => { const rows = normalizeList(payload); setTrainerCourses(rows); if (rows[0]) setSelectedCourse(rows[0]._id || rows[0].id); }).catch(() => {}); }, []);
  useEffect(() => { if (!selectedCourse) return; moduleApi.list(selectedCourse).then((payload) => { const rows = normalizeList(payload); setModules(rows); if (rows[0]) setSelectedModule(rows[0]._id || rows[0].id); }).catch(() => {}); }, [selectedCourse]);
  const saveAssessment = async (status) => {
    if (!selectedCourse || !assessmentTitle.trim()) return window.alert("Course and assessment title are required.");
    if (Number(passingMarks) > Number(totalMarks)) return window.alert("Passing marks cannot exceed total marks.");
    if (Number(attemptLimit) < 1) return window.alert("Attempt limit must be at least 1.");
    try { await assessmentApi.create({ title: assessmentTitle, courseId: selectedCourse, moduleId: selectedModule || undefined, type: assessmentType, totalMarks: Number(totalMarks), passingMarks: Number(passingMarks), duration: Number(timeLimit), attemptLimit: Number(attemptLimit), questions, status }); window.alert(status === "PUBLISHED" ? "Assessment published successfully." : "Assessment saved as draft."); } catch (error) { window.alert(apiError(error)); }
  };
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="Create Assessment"
          copy="Build quizzes, tests or assignments to evaluate learner understanding."
          actions={
            <div className="tp-button-row">
              <button type="button" className="tp-btn" onClick={() => saveAssessment("DRAFT")}>
                <Save /> Save as Draft
              </button>
              <button type="button" className="tp-btn primary" onClick={() => saveAssessment("PUBLISHED")}>Publish Assessment</button>
            </div>
          }
        />
        <div className="tp-assessment-course">
          <img src="/assets/student/course-fullstack.png" alt="" />
          <span>
            <b>Full Stack Web Development</b>
            <small>
              <CalendarDays /> Batch 2025 <Users /> 120 Learners
            </small>
          </span>
        </div>
        <div className="tp-assessment-layout">
          <section className="tp-card">
            <nav className="tp-tabs">
              {["Basic Details", "Questions", "Settings", "Preview"].map(
                (x) => (
                  <button
                    onClick={() => setTab(x)}
                    className={tab === x ? "active" : ""}
                    key={x}
                  >
                    {x}
                  </button>
                ),
              )}
            </nav>
            {tab === "Basic Details" ? (
              <>
                <h2>Assessment Details</h2>
                <Field label="Assessment Title *">
                  <input value={assessmentTitle} onChange={(e) => setAssessmentTitle(e.target.value)} />
                </Field>
                <div className="tp-two">
                  <Field label="Course *">
                    <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}><option value="">Select course</option>{trainerCourses.map((course) => <option key={course._id || course.id} value={course._id || course.id}>{course.title || course.name}</option>)}</select>
                  </Field>
                  <Field label="Module / Topic *">
                    <select value={selectedModule} onChange={(e) => setSelectedModule(e.target.value)}><option value="">Select module</option>{modules.map((module) => <option key={module._id || module.id} value={module._id || module.id}>{module.title || module.name}</option>)}</select>
                  </Field>
                </div>
                <b className="tp-label">Assessment Type *</b>
                <div className="tp-two tp-radio-boxes">
                  <p onClick={() => setAssessmentType("PRE")}>
                    {assessmentType === "PRE" ? <CheckCircle2 /> : "○"} <b>Pre-Assessment</b>
                    <small>Evaluate learners before the module</small>
                  </p>
                  <p onClick={() => setAssessmentType("POST")}>
                    {assessmentType === "POST" ? <CheckCircle2 /> : "○"} <b>Post-Assessment</b>
                    <small>Evaluate learners after the module</small>
                  </p>
                </div>
                <Field label="Description (Optional)">
                  <textarea defaultValue="This test evaluates your understanding of the key concepts covered in this module." />
                </Field>
              </>
            ) : (
              <QuestionEditor questions={questions} />
            )}
          </section>
          <aside className="tp-side">
            <section className="tp-card">
              <h2>Assessment Settings</h2>
              <div className="tp-two">
                <Field label="Total Marks *">
                  <input type="number" value={totalMarks} onChange={(e) => setTotalMarks(e.target.value)} />
                </Field>
                <Field label="Passing Marks *">
                  <input type="number" value={passingMarks} onChange={(e) => setPassingMarks(e.target.value)} />
                </Field>
                <Field label="Time Limit">
                  <input type="number" value={timeLimit} onChange={(e) => setTimeLimit(e.target.value)} />
                </Field>
                <Field label="Attempt Limit">
                  <input type="number" value={attemptLimit} onChange={(e) => setAttemptLimit(e.target.value)} />
                </Field>
              </div>
              {[
                "Show Results to Learners",
                "Shuffle Questions",
                "Shuffle Options",
              ].map((x) => (
                <label className="tp-toggle" key={x}>
                  {x}
                  <input defaultChecked type="checkbox" />
                  <i />
                </label>
              ))}
            </section>
            <section className="tp-card">
              <h2>Question Types</h2>
              <div className="tp-question-types">
                <button className="active">◉ Multiple Choice</button>
                <button>☑ Multiple Select</button>
                <button>✓ True / False</button>
                <button>▤ Descriptive</button>
              </div>
            </section>
          </aside>
        </div>
      </div>
    </TrainerLayout>
  );
}
export function Results() {
  const [resultRows, setResultRows] = useState([]);
  useEffect(() => { resultApi.trainerList({ page: 1, pageSize: 50 }).then((payload) => { const rows = normalizeList(payload); if (rows.length) setResultRows(rows); }).catch(() => {}); }, []);
  const learners = [
    "Aarav Kumar",
    "Priya Sharma",
    "Rohan Mehta",
    "Sneha Verma",
    "Aditya Singh",
    "Kavya Patel",
  ];
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="Assessment Results"
          copy="View and analyze learner performance for your assessments."
        />
        <div className="tp-filter">
          <Select label="Course">
            <option>Full Stack Web Development</option>
          </Select>
          <Select label="Module / Topic">
            <option>1. Introduction to Web Development</option>
          </Select>
        </div>
        <div className="tp-result-stats">
          {[
            [Users, "48", "Total Attempts"],
            [CheckCircle2, "38", "Passed"],
            [Trash2, "10", "Failed"],
            [Trophy, "76%", "Average Score"],
          ].map(([Icon, num, label]) => (
            <article key={label}>
              <Icon />
              <span>
                <b>{num}</b>
                <small>{label}</small>
              </span>
            </article>
          ))}
        </div>
        <div className="tp-results-grid">
          <section className="tp-card tp-table-card">
            <header>
              <h2>
                Learner Results <small>(48)</small>
              </h2>
              <button className="tp-btn">
                <Download /> Export Results
              </button>
            </header>
            <label className="tp-table-search">
              <Search />
              <input placeholder="Search by learner name, email, or enrollment ID" />
            </label>
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Learner Name</th>
                  <th>Attempt Date</th>
                  <th>Score</th>
                  <th>Percentage</th>
                  <th>Result</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {(resultRows.length ? resultRows : learners.map((name) => ({ learner: { name }, learnerName: name }))).map((row, i) => {
                  const x = row.learner?.name || row.learnerName || row.name || learners[i] || "Learner";
                  const pass = String(row.result || "PASS").toUpperCase() === "PASS";
                  const percentage = row.percentage ?? (pass ? 90 - i * 5 : 40);
                  return (
                    <tr key={x}>
                      <td>{i + 1}</td>
                      <td>{x}</td>
                      <td>
                        {row.submittedAt ? new Date(row.submittedAt).toLocaleString() : `${25 - i} Sep 2025, 10:${15 + i} AM`}
                      </td>
                      <td>{row.score ?? (pass ? 18 - i : 8)}/20</td>
                      <td>{percentage}%</td>
                      <td>
                        <span className={`tp-pill ${pass ? "pass" : "fail"}`}>
                          {pass ? "Pass" : "Fail"}
                        </span>
                      </td>
                      <td>
                        <Eye size={17} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </section>
          <aside className="tp-result-side">
            <section className="tp-card">
              <h2>Performance Overview</h2>
              <div className="tp-chart">
                {[8, 25, 30, 67, 100].map((x, i) => (
                  <i key={i} style={{ height: `${x}%` }}>
                    <small>
                      {["0-20", "21-40", "41-60", "61-80", "81-100"][i]}%
                    </small>
                  </i>
                ))}
              </div>
            </section>
            <section className="tp-card">
              <h2>Score Distribution</h2>
              <div className="tp-donut">
                <b>
                  48<small>Attempts</small>
                </b>
              </div>
              <p className="tp-legend">
                ● 81-100% 42%
                <br />● 61-80% 29%
                <br />● 41-60% 17%
              </p>
            </section>
          </aside>
        </div>
      </div>
    </TrainerLayout>
  );
}
export function Profile() {
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="My Profile"
          copy="Manage your personal information, preferences, and account settings."
          actions={
            <button className="tp-btn">
              <Eye /> View Public Profile
            </button>
          }
        />
        <section className="tp-profile-hero">
          <img src="/assets/student/avatar.png" alt="Neha Sharma" />
          <div>
            <h2>
              Neha Sharma <span>Active</span>
            </h2>
            <p>Trainer | Subject Matter Expert</p>
            <small>
              <Mail /> neha.sharma@primeeasylearn.com <MapPin /> New Delhi,
              India
            </small>
          </div>
          <div className="tp-profile-numbers">
            <span>
              <BookOpen />
              <b>3</b>Assigned Courses
            </span>
            <span>
              <Users />
              <b>245</b>Total Learners
            </span>
            <span>
              <Trophy />
              <b>4.8</b>Trainer Rating
            </span>
          </div>
        </section>
        <div className="tp-profile-grid">
          <section className="tp-card">
            <nav className="tp-tabs">
              <button className="active">Personal Information</button>
              <button>Professional Details</button>
              <button>Preferences</button>
            </nav>
            <h2>Personal Information</h2>
            <p>Keep your personal details up to date.</p>
            <div className="tp-two">
              <Field label="Full Name *">
                <input defaultValue="Neha Sharma" />
              </Field>
              <Select label="Gender">
                <option>Female</option>
              </Select>
              <Field label="Email Address *">
                <input defaultValue="neha.sharma@primeeasylearn.com" />
              </Field>
              <Field label="Location">
                <input defaultValue="New Delhi, India" />
              </Field>
              <Field label="Phone Number *">
                <input defaultValue="+91 98765 43210" />
              </Field>
              <Field label="Address">
                <textarea defaultValue="A-123, Sector 62, Noida, Uttar Pradesh - 201309" />
              </Field>
              <Field label="Date of Birth">
                <input defaultValue="15 Mar 1992" />
              </Field>
              <Field label="Bio">
                <textarea defaultValue="Passionate about teaching and helping students build strong fundamentals in technology." />
              </Field>
            </div>
            <div className="tp-button-row end">
              <button className="tp-btn">Cancel</button>
              <button className="tp-btn primary">
                <Save /> Save Changes
              </button>
            </div>
          </section>
          <aside className="tp-side">
            <section className="tp-card tp-photo">
              <h2>Profile Photo</h2>
              <img src="/assets/student/avatar.png" alt="" />
              <p>
                Upload a new profile photo
                <br />
                <small>JPG, PNG (Max 2 MB)</small>
              </p>
              <button className="tp-btn">
                <Upload /> Change Photo
              </button>
            </section>
            <section className="tp-card">
              <h2>
                <Lock /> Change Password
              </h2>
              {["Current Password", "New Password", "Confirm New Password"].map(
                (x) => (
                  <Field key={x} label={x}>
                    <input
                      placeholder={`Enter ${x.toLowerCase()}`}
                      type="password"
                    />
                  </Field>
                ),
              )}
              <button className="tp-btn primary full">Update Password</button>
            </section>
            <section className="tp-card">
              <h2>Notification Preferences</h2>
              {["Email Notifications", "Platform Notifications"].map((x) => (
                <label className="tp-toggle" key={x}>
                  {x}
                  <input defaultChecked type="checkbox" />
                  <i />
                </label>
              ))}
            </section>
          </aside>
        </div>
      </div>
    </TrainerLayout>
  );
}
export function Support() {
  return (
    <TrainerLayout>
      <div className="trainer-pages">
        <Top
          title="Help & Support"
          copy="Find answers or contact the Prime Easy Learn support team."
        />
        <div className="tp-help-grid">
          {[
            [
              "Course & Content Help",
              "Guidance for uploading and organizing your course material.",
              BookOpen,
            ],
            [
              "Assessment Help",
              "Create, publish, and review learner assessments.",
              FileText,
            ],
            [
              "Reports & Results",
              "Understand performance analytics and exported reports.",
              BarChart3,
            ],
            [
              "Contact Support",
              "Our team is ready to help with your account.",
              Mail,
            ],
          ].map(([a, b, Icon]) => (
            <article className="tp-card" key={a}>
              <Icon />
              <h2>{a}</h2>
              <p>{b}</p>
              <button className="tp-btn">Get help</button>
            </article>
          ))}
        </div>
      </div>
    </TrainerLayout>
  );
}
