import axios from "axios";

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "http://localhost:5000").replace(/\/$/, "");

export const api = axios.create({
  baseURL: `${API_BASE_URL}/api`,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

let accessToken = sessionStorage.getItem("pel_access_token") || null;
let refreshing = null;

export function setAccessToken(token) {
  accessToken = token || null;
  if (accessToken) sessionStorage.setItem("pel_access_token", accessToken);
  else sessionStorage.removeItem("pel_access_token");
}

export function clearAccessToken() {
  setAccessToken(null);
}

api.interceptors.request.use((config) => {
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`;
  return config;
});

async function refreshAccessToken() {
  if (!refreshing) {
    refreshing = api.post("/auth/refresh").then((response) => {
      const token = response.data?.data?.accessToken || response.data?.accessToken;
      if (token) setAccessToken(token);
      return token || null;
    }).finally(() => {
      refreshing = null;
    });
  }
  return refreshing;
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && original && !original._retry && !original.url?.includes("/auth/")) {
      original._retry = true;
      const token = await refreshAccessToken();
      if (token) {
        original.headers.Authorization = `Bearer ${token}`;
        return api(original);
      }
    }
    return Promise.reject(error);
  },
);

export function unwrap(response) {
  return response?.data?.data ?? response?.data ?? null;
}

export function normalizeList(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.items)) return payload.items;
  if (Array.isArray(payload?.results)) return payload.results;
  return [];
}

export function apiError(error) {
  return error?.response?.data?.message || error?.response?.data?.error?.message || error?.message || "Something went wrong";
}

export const authApi = {
  async login({ email, password, role }) {
    const response = await api.post("/auth/login", { email, password, role });
    const data = unwrap(response) || {};
    const token = data.accessToken || data.token;
    if (token) setAccessToken(token);
    return data.user || data;
  },
  async me() {
    const response = await api.get("/auth/me");
    return unwrap(response);
  },
  async logout() {
    try { await api.post("/auth/logout"); } finally { clearAccessToken(); }
  },
};

export const courseApi = {
  list: (params = {}) => api.get("/courses", { params }).then(unwrap),
  trainerCourses: (params = {}) => api.get("/trainer/courses", { params }).then(unwrap),
  get: (id) => api.get(`/courses/${id}`).then(unwrap),
};

export const enrollmentApi = {
  list: (params = {}) => api.get("/enrollments", { params }).then(unwrap),
  get: (id) => api.get(`/enrollments/${id}`).then(unwrap),
};

export const moduleApi = {
  list: (courseId) => api.get("/modules", { params: { courseId } }).then(unwrap),
};

export const contentApi = {
  list: (params = {}) => api.get("/content", { params }).then(unwrap),
  create: (payload) => api.post("/content", payload, payload instanceof FormData ? { headers: { "Content-Type": "multipart/form-data" } } : undefined).then(unwrap),
  upload: (file, type) => { const form = new FormData(); form.append("file", file); form.append("type", type); return api.post("/uploads", form, { headers: { "Content-Type": "multipart/form-data" } }).then(unwrap); },
};

export const assessmentApi = {
  list: (params = {}) => api.get("/assessments", { params }).then(unwrap),
  get: (id) => api.get(`/assessments/${id}`).then(unwrap),
  create: (payload) => api.post("/assessments", payload).then(unwrap),
};

export const attemptApi = {
  start: (assessmentId) => api.post("/attempts", { assessmentId }).then(unwrap),
  submit: (attemptId, answers) => api.post(`/attempts/${attemptId}/submit`, { answers }).then(unwrap),
};

export const progressApi = {
  list: (params = {}) => api.get("/progress", { params }).then(unwrap),
  update: (payload) => api.post("/progress", payload).then(unwrap),
};

export const resultApi = {
  list: (params = {}) => api.get("/results", { params }).then(unwrap),
  trainerList: (params = {}) => api.get("/trainer/results", { params }).then(unwrap),
};

export const certificateApi = {
  list: (params = {}) => api.get("/certificates", { params }).then(unwrap),
};

export const notificationApi = {
  list: (params = {}) => api.get("/notifications", { params }).then(unwrap),
};

export const messageApi = {
  list: (params = {}) => api.get("/messages", { params }).then(unwrap),
};

export function toArray(payload) {
  return normalizeList(payload);
}
