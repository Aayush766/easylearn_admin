import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import StudentLayout from "./StudentLayout";
import {
  Award,
  BookOpen,
  Calendar,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  Compass,
  FileBadge2,
  FileText,
  Grid2X2,
  List,
  RefreshCw,
  Search,
  Sparkles,
  Zap,
} from "lucide-react";
import "./StudentCourses.css";
import herostudent from "../public/assets/student/hero-student.png";
import { enrollmentApi, normalizeList } from "../services/api";

const COURSE_DATA = [
  {
    id: "full-stack",
    title: "Full Stack Web Development",
    category: "Web Development",
    status: "In Progress",
    statusTone: "progress",
    description:
      "Master modern frontend and backend tech stacks including React, Node.js, Express, and MongoDB.",
    progress: 65,
    startDate: "01 Mar 2025",
    dateLabel: "Valid Until",
    dateValue: "31 Aug 2025",
    dateSubtext: "5 mos left",
    dateTone: "success",
    lessons: "28 / 42",
    assessments: "3 / 5",
    certificate: "In Progress",
    image: "/assets/student/course-fullstack.png",
    action: "Continue",
    actionTone: "primary",
  },
  {
    id: "ui-ux",
    title: "UI/UX Design Masterclass",
    category: "UI/UX Design",
    status: "Not Started",
    statusTone: "neutral",
    description:
      "Learn user interface and experience design with real industry projects and Figma design systems.",
    progress: 0,
    startDate: "10 Sep 2025",
    dateLabel: "Valid Until",
    dateValue: "10 Mar 2026",
    dateSubtext: "6 mos left",
    dateTone: "success",
    lessons: "0 / 28",
    assessments: "0 / 4",
    certificate: "Not Started",
    image: "/assets/student/course-uiux.png",
    action: "Start Learning",
    actionTone: "primary",
  },
  {
    id: "digital-marketing",
    title: "Digital Marketing Essentials",
    category: "Digital Marketing",
    status: "Completed",
    statusTone: "complete",
    description:
      "Master SEO algorithms, performance social campaigns, Google Ads, and content marketing strategy.",
    progress: 100,
    startDate: "15 Jan 2025",
    dateLabel: "Completed On",
    dateValue: "20 Apr 2025",
    dateTone: "default",
    lessons: "28 / 28",
    assessments: "5 / 5",
    certificate: "View Certificate",
    certificateLink: true,
    image: "/assets/student/course-marketing.png",
    action: "Revisit Course",
    actionTone: "secondary",
  },
  {
    id: "data-analytics",
    title: "Data Analytics with Python",
    category: "Data Science",
    status: "Expired",
    statusTone: "expired",
    description:
      "Perform real-world data analysis, statistical visualization, machine learning models, and automated reporting.",
    progress: 100,
    startDate: "01 Jan 2025",
    dateLabel: "Expired On",
    dateValue: "30 Jun 2025",
    dateTone: "danger",
    lessons: "42 / 42",
    assessments: "5 / 5",
    certificate: "View Certificate",
    certificateLink: true,
    finalScore: "88%",
    image: "/assets/student/course-data.png",
    action: "Renew",
    actionTone: "warning",
    expiredMessage: "Access expired on 30 Jun 2025. Renew to unlock updated modules.",
  },
];

const FILTERS = [
  { id: "all", label: "All Courses" },
  { id: "progress", label: "In Progress" },
  { id: "completed", label: "Completed" },
  { id: "expired", label: "Expired" },
];

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function daysLeft(value) {
  if (!value) return "";
  const diff = Math.ceil((new Date(value).getTime() - Date.now()) / 86400000);
  return diff > 0 ? `${diff} days left` : diff === 0 ? "Expires today" : "Expired";
}

function mapEnrollment(enrollment) {
  const course = enrollment.course || enrollment.courseId || {};
  const expiry = enrollment.expiryDate || enrollment.expiresAt;
  const status = String(enrollment.status || "ACTIVE").toUpperCase();
  const progress = Number(enrollment.progressPercent ?? enrollment.progress ?? 0);
  const completed = status === "COMPLETED" || progress >= 100;
  const expired = status === "EXPIRED" || (expiry && new Date(expiry) < new Date());
  const inProgress = !expired && !completed && progress > 0;
  const uiStatus = expired ? "Expired" : completed ? "Completed" : inProgress ? "In Progress" : "Not Started";
  return {
    id: course._id || course.id || enrollment.courseId,
    enrollmentId: enrollment._id || enrollment.id,
    title: course.title || course.name || "Course",
    category: course.category?.name || course.category || "Course",
    status: uiStatus,
    statusTone: expired ? "expired" : completed ? "complete" : inProgress ? "progress" : "neutral",
    description: course.description || "Access your enrolled course content, assessments and progress.",
    progress,
    startDate: formatDate(enrollment.startDate),
    dateLabel: expired ? "Expired On" : completed ? "Completed On" : "Valid Until",
    dateValue: formatDate(expiry),
    dateSubtext: daysLeft(expiry),
    dateTone: expired ? "danger" : "success",
    lessons: `${enrollment.completedLessons ?? 0} / ${enrollment.totalLessons ?? course.totalLessons ?? 0}`,
    assessments: `${enrollment.completedAssessments ?? 0} / ${enrollment.totalAssessments ?? course.totalAssessments ?? 0}`,
    certificate: enrollment.certificate ? "View Certificate" : completed ? "Eligible" : "In Progress",
    certificateLink: Boolean(enrollment.certificate),
    finalScore: enrollment.finalScore != null ? `${enrollment.finalScore}%` : undefined,
    image: course.thumbnail || course.thumbnailUrl || "/assets/student/course-fullstack.png",
    action: expired ? "Renew" : completed ? "Revisit Course" : progress > 0 ? "Continue" : "Start Learning",
    actionTone: expired ? "warning" : completed ? "secondary" : "primary",
    expiredMessage: expired ? `Access expired on ${formatDate(expiry)}. Renew to unlock the course.` : undefined,
  };
}

function getFilterStatus(filterId) {
  if (filterId === "progress") return "In Progress";
  if (filterId === "completed") return "Completed";
  if (filterId === "expired") return "Expired";
  return null;
}

function StatusBadge({ tone, children }) {
  return (
    <span className={`sc-badge sc-badge--${tone}`}>
      <span className="sc-badge__dot" />
      {children}
    </span>
  );
}

function CourseMetaRow({ icon: Icon, label, value, tone = "default", link, subtext }) {
  return (
    <div className={`sc-meta-item sc-meta-item--${tone}`}>
      <div className="sc-meta-item__header">
        <Icon size={12} className="sc-meta-item__icon" />
        <span className="sc-meta-item__label">{label}</span>
      </div>
      <div className="sc-meta-item__body">
        {link ? (
          <Link to={link} className="sc-meta-item__link">
            {value}
          </Link>
        ) : (
          <span className="sc-meta-item__value">{value}</span>
        )}
        {subtext && <span className="sc-meta-item__subtext">{subtext}</span>}
      </div>
    </div>
  );
}

function CourseCard({ course }) {
  const coursePath = `/student/courses/${course.id}`;

  return (
    <article className="sc-card">
      <div className="sc-card__media">
        <img src={course.image} alt={course.title} loading="lazy" />
        <div className="sc-card__overlay" />

        <div className="sc-card__badges">
          <StatusBadge tone={course.statusTone}>{course.status}</StatusBadge>
          <span className="sc-card__category">{course.category}</span>
        </div>
      </div>

      <div className="sc-card__body">
        <h3 className="sc-card__title" title={course.title}>
          {course.title}
        </h3>
        <p className="sc-card__desc">{course.description}</p>

        {/* Progress Bar */}
        <div className="sc-progress">
          <div className="sc-progress__header">
            <span className="sc-progress__label">Progress</span>
            <span className="sc-progress__val">{course.progress}%</span>
          </div>
          <div className="sc-progress__track">
            <div
              className={`sc-progress__fill sc-progress__fill--${course.statusTone}`}
              style={{ width: `${course.progress}%` }}
            />
          </div>
        </div>

        {/* Metadata Grid (2-Column Compact Layout) */}
        <div className="sc-card__meta-grid">
          <CourseMetaRow
            icon={Calendar}
            label="Enrolled"
            value={course.startDate}
          />
          <CourseMetaRow
            icon={Clock}
            label={course.dateLabel}
            value={course.dateValue}
            subtext={course.dateSubtext}
            tone={course.dateTone}
          />
          <CourseMetaRow
            icon={BookOpen}
            label="Modules"
            value={course.lessons}
          />
          <CourseMetaRow
            icon={FileText}
            label="Assessments"
            value={course.assessments}
          />
          <CourseMetaRow
            icon={Award}
            label="Certificate"
            value={course.certificate}
            link={course.certificateLink ? `${coursePath}/certificate` : undefined}
          />
          {course.finalScore && (
            <CourseMetaRow
              icon={FileBadge2}
              label="Final Score"
              value={course.finalScore}
              tone="success"
            />
          )}
        </div>

        {course.expiredMessage && (
          <div className="sc-card__expired-alert">
            <p>{course.expiredMessage}</p>
          </div>
        )}

        {/* Action Buttons (Side-by-Side) */}
        <div className="sc-card__actions">
          <Link
            to={coursePath}
            className={`sc-btn sc-btn--${course.actionTone}`}
          >
            {course.action}
            <ChevronRight size={14} />
          </Link>
          <Link to={coursePath} className="sc-btn sc-btn--ghost">
            Details
          </Link>
        </div>
      </div>
    </article>
  );
}

function CourseHero() {
  return (
    <section className="sc-hero">
      <div className="sc-hero__bg">
        <div className="sc-hero__glow-1" />
        <div className="sc-hero__glow-2" />
        <div className="sc-hero__grid-pattern" />
      </div>

      <div className="sc-hero__container">
        <div className="sc-hero__content">
          <div className="sc-hero__pill">
            <Sparkles size={13} />
            <span>Interactive Learning Dashboard</span>
          </div>
          <h1>
            My Learning <span className="sc-hero__gradient-text">Journey</span>
          </h1>
          <p>
            Track your ongoing courses, complete assessments, download certificates, and level up your skills.
          </p>

          <div className="sc-hero__stats">
            <div className="sc-hero__stat-item">
              <strong>4</strong>
              <span>Total Enrolled</span>
            </div>
            <div className="sc-hero__stat-divider" />
            <div className="sc-hero__stat-item">
              <strong>1</strong>
              <span>In Progress</span>
            </div>
            <div className="sc-hero__stat-divider" />
            <div className="sc-hero__stat-item">
              <strong>2</strong>
              <span>Completed</span>
            </div>
          </div>
        </div>

        <div className="sc-hero__banner">
          <div className="sc-hero__circle" />
          
          <div className="sc-hero__floating-chip sc-hero__floating-chip--left">
            <div className="sc-hero__chip-icon sc-hero__chip-icon--orange">
              <Zap size={14} />
            </div>
            <div>
              <small>Goal</small>
              <strong>Learn &amp; Grow</strong>
            </div>
          </div>

          <div className="sc-hero__floating-chip sc-hero__floating-chip--right">
            <div className="sc-hero__chip-icon sc-hero__chip-icon--green">
              <CheckCircle2 size={14} />
            </div>
            <div>
              <small>Status</small>
              <strong>On Track</strong>
            </div>
          </div>

          <img
            src={herostudent}
            alt="Student Learning"
            className="sc-hero__student-img"
          />
        </div>
      </div>
    </section>
  );
}

function CourseFilters({ activeFilter, onFilterChange, filters = FILTERS }) {
  return (
    <div className="sc-filters" role="tablist" aria-label="Course filters">
      {filters.map((filter) => (
        <button
          key={filter.id}
          type="button"
          role="tab"
          aria-selected={activeFilter === filter.id}
          className={`sc-filters__btn ${activeFilter === filter.id ? "is-active" : ""}`}
          onClick={() => onFilterChange(filter.id)}
        >
          <span>{filter.label}</span>
          <span className="sc-filters__count">{filter.count}</span>
        </button>
      ))}
    </div>
  );
}

function CourseToolbar({ searchQuery, onSearchChange, sort, onSortChange, view, onViewChange }) {
  return (
    <div className="sc-toolbar">
      <div className="sc-toolbar__search">
        <Search size={14} className="sc-toolbar__search-icon" />
        <input
          type="text"
          placeholder="Search courses..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>

      <div className="sc-toolbar__right">
        <div className="sc-toolbar__sort">
          <label htmlFor="course-sort">Sort by</label>
          <div className="sc-select">
            <select
              id="course-sort"
              value={sort}
              onChange={(e) => onSortChange(e.target.value)}
            >
              <option value="recent">Recently Enrolled</option>
              <option value="progress">Highest Progress</option>
              <option value="name">Course Name (A-Z)</option>
            </select>
            <ChevronDown size={12} className="sc-select__arrow" />
          </div>
        </div>

        <div className="sc-view-toggle" aria-label="View mode">
          <button
            type="button"
            className={view === "grid" ? "is-active" : ""}
            onClick={() => onViewChange("grid")}
            aria-label="Grid view"
          >
            <Grid2X2 size={14} />
          </button>
          <button
            type="button"
            className={view === "list" ? "is-active" : ""}
            onClick={() => onViewChange("list")}
            aria-label="List view"
          >
            <List size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

function ExploreCourses() {
  return (
    <section className="sc-explore">
      <div className="sc-explore__glow" />
      <div className="sc-explore__content">
        <div className="sc-explore__left">
          <div className="sc-explore__badge">
            <Compass size={13} />
            <span>Expand Your Knowledge</span>
          </div>
          <h2>Ready to learn something new?</h2>
          <p>
            Upgrade your skills with our latest industry-aligned certification programs and bootcamps.
          </p>
          <Link to="/student/courses/catalog" className="sc-btn sc-btn--primary">
            Browse All Courses
            <ChevronRight size={14} />
          </Link>
        </div>

        <div className="sc-explore__benefits">
          <div className="sc-explore__benefit-card">
            <div className="sc-explore__icon">
              <BookOpen size={16} />
            </div>
            <div>
              <strong>20+ Courses</strong>
              <small>Industry-focused curricula</small>
            </div>
          </div>

          <div className="sc-explore__benefit-card">
            <div className="sc-explore__icon">
              <RefreshCw size={16} />
            </div>
            <div>
              <strong>Self-Paced</strong>
              <small>Learn anytime, anywhere</small>
            </div>
          </div>

          <div className="sc-explore__benefit-card">
            <div className="sc-explore__icon">
              <Award size={16} />
            </div>
            <div>
              <strong>Certificates</strong>
              <small>Boost your resume</small>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="sc-footer">
      <div className="sc-footer__container">
        <span>© 2025 Prime Easy Learn Training Institute. All rights reserved.</span>

        <div className="sc-footer__links">
          <a href="#privacy">Privacy Policy</a>
          <span className="sc-footer__dot">•</span>
          <a href="#terms">Terms &amp; Conditions</a>
          <span className="sc-footer__dot">•</span>
          <a href="#help">Help Center</a>
        </div>
      </div>
    </footer>
  );
}

export default function StudentCourses() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sort, setSort] = useState("recent");
  const [view, setView] = useState("grid");
  const [courseData, setCourseData] = useState(COURSE_DATA);

  useEffect(() => {
    let active = true;
    enrollmentApi.list({ status: "ACTIVE", page: 1, pageSize: 50 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (active && rows.length) setCourseData(rows.map(mapEnrollment));
      })
      .catch(() => { /* preserve existing UI fallback when API is unavailable */ });
    return () => { active = false; };
  }, []);

  const visibleCourses = useMemo(() => {
    const status = getFilterStatus(activeFilter);
    return courseData.filter((course) => {
      const matchesFilter = status ? course.status === status : true;
      const matchesSearch =
        course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesFilter && matchesSearch;
    }).sort((a, b) => {
      if (sort === "progress") return b.progress - a.progress;
      if (sort === "name") return a.title.localeCompare(b.title);
      return 0;
    });
  }, [activeFilter, searchQuery, sort]);

  return (
    <StudentLayout>
      <div className="sc-page">
        <CourseHero />

        <div className="sc-controls">
          <CourseFilters
            activeFilter={activeFilter}
            onFilterChange={setActiveFilter}
            filters={filters.map((filter) => ({ ...filter, count: filter.id === "all" ? courseData.length : courseData.filter((c) => c.status === getFilterStatus(filter.id)).length }))}
          />

          <CourseToolbar
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            sort={sort}
            onSortChange={setSort}
            view={view}
            onViewChange={setView}
          />
        </div>

        <section
          className={`sc-grid sc-grid--${view}`}
          aria-label="Enrolled courses"
        >
          {visibleCourses.length > 0 ? (
            visibleCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))
          ) : (
            <div className="sc-empty">
              <p>No courses found matching your criteria.</p>
            </div>
          )}
        </section>

        <ExploreCourses />
      </div>

      <Footer />
    </StudentLayout>
  );
}