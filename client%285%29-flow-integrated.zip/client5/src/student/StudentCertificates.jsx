import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Award,
  ArrowRight,
  BarChart3,
  Calendar,
  CheckCircle2,
  ChevronDown,
  Code2,
  Database,
  Download,
  GraduationCap,
  Instagram,
  Linkedin,
  Printer,
  Share2,
  ShieldCheck,
  Sparkles,
  Youtube,
} from "lucide-react";

import StudentLayout from "./StudentLayout";
import "./StudentCertificates.css";

const CERTIFICATES = [
  {
    id: 1,
    title: "Full Stack Web Development",
    subtitle: "Professional Certificate",
    issued: "20 Sep 2025",
    type: "Course Certificate",
    icon: "code",
    theme: "blue",
    certificateId: "PEL-FSWD-2025-09120",
    course: "Full Stack Web Development",
  },
  {
    id: 2,
    title: "Digital Marketing Essentials",
    subtitle: "Professional Certificate",
    issued: "12 Aug 2025",
    type: "Course Certificate",
    icon: "marketing",
    theme: "red",
    certificateId: "PEL-DME-2025-08120",
    course: "Digital Marketing Essentials",
  },
  {
    id: 3,
    title: "Data Analytics with Python",
    subtitle: "Professional Certificate",
    issued: "25 Jun 2025",
    type: "Course Certificate",
    icon: "database",
    theme: "purple",
    certificateId: "PEL-DAP-2025-06250",
    course: "Data Analytics with Python",
  },
];

function CertificateIcon({ type }) {
  if (type === "marketing") return <BarChart3 size={24} strokeWidth={2} />;
  if (type === "database") return <Database size={24} strokeWidth={2} />;
  return <Code2 size={24} strokeWidth={2} />;
}

/* Premium Dynamic SVG Certificate Template */
function CertificateSVG({ certificate }) {
  return (
    <svg
      className="cert-svg"
      viewBox="0 0 800 565"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="800" height="565" fill="#FFFFFF" />

      {/* Decorative Outer Border */}
      <rect
        x="24"
        y="24"
        width="752"
        height="517"
        rx="4"
        stroke="#E2E8F0"
        strokeWidth="2"
      />
      <rect
        x="32"
        y="32"
        width="736"
        height="501"
        rx="2"
        stroke="#CBD5E1"
        strokeWidth="1"
        strokeDasharray="4 4"
      />

      {/* Top Left Accent Geometry */}
      <path d="M24 24H140L24 140V24Z" fill="#2563EB" opacity="0.08" />
      <path d="M776 541H660L776 425V541Z" fill="#2563EB" opacity="0.08" />

      {/* Header / Institution Brand */}
      <g transform="translate(320, 70)">
        <path
          d="M 0 -10 L 20 0 L 0 10 L -20 0 Z M -12 4 V 12 C -12 12 0 16 12 12 V 4"
          stroke="#2563EB"
          strokeWidth="2"
          fill="none"
        />
        <text x="32" y="0" className="brand-title">
          PRIME EASY LEARN
        </text>
        <text x="32" y="14" className="brand-subtitle">
          INSTITUTE OF TECHNOLOGY
        </text>
      </g>

      {/* Certificate Identifier */}
      <text x="740" y="65" textAnchor="end" className="footer-label">
        ID: {certificate.certificateId}
      </text>

      {/* Title Header */}
      <text x="400" y="175" textAnchor="middle" className="cert-header">
        CERTIFICATE OF COMPLETION
      </text>
      <text x="400" y="198" textAnchor="middle" className="cert-subheader">
        THIS IS PROUDLY PRESENTED TO
      </text>

      {/* Recipient Name */}
      <text x="400" y="260" textAnchor="middle" className="recipient-name">
        Aayush Kumar
      </text>
      <line x1="220" y1="275" x2="580" y2="275" stroke="#CBD5E1" strokeWidth="1" />

      {/* Body Content */}
      <text x="400" y="315" textAnchor="middle" className="body-text">
        for successfully mastering and completing the accredited program in
      </text>
      <text x="400" y="350" textAnchor="middle" className="course-title">
        {certificate.course}
      </text>

      {/* Seals and Signatures */}
      <g transform="translate(400, 440)">
        {/* Gold Badge */}
        <circle cx="0" cy="0" r="28" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="2" />
        <path
          d="M-10 -4 L0 -14 L10 -4 L5 12 L-5 12 Z"
          fill="#F59E0B"
          opacity="0.8"
        />
      </g>

      {/* Date */}
      <g transform="translate(120, 435)">
        <text x="0" y="0" className="footer-value">
          {certificate.issued}
        </text>
        <line x1="0" y1="8" x2="140" y2="8" stroke="#94A3B8" strokeWidth="1" />
        <text x="0" y="24" className="footer-label">
          DATE OF ISSUANCE
        </text>
      </g>

      {/* Signature */}
      <g transform="translate(680, 435)">
        <path
          d="M -100 -5 C -80 -25 -60 5 -40 -15 C -20 -5 0 -20 10 -10"
          stroke="#0F172A"
          strokeWidth="2"
          fill="none"
        />
        <line x1="-120" y1="8" x2="0" y2="8" stroke="#94A3B8" strokeWidth="1" />
        <text x="-60" y="24" textAnchor="middle" className="footer-label">
          AUTHORIZED SIGNATURE
        </text>
      </g>
    </svg>
  );
}

export default function StudentCertificates() {
  const [activeTab, setActiveTab] = useState("all");
  const [selectedId, setSelectedId] = useState(1);
  const [sort, setSort] = useState("recent");

  const selectedCertificate =
    CERTIFICATES.find((cert) => cert.id === selectedId) || CERTIFICATES[0];

  const certificates =
    sort === "recent" ? CERTIFICATES : [...CERTIFICATES].reverse();

  const handleDownload = () => window.print();

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "My Certificate",
          text: `Check out my certificate for ${selectedCertificate.course}!`,
          url: window.location.href,
        });
      } catch {
        // Ignored
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <StudentLayout>
      <div className="student-certificates">
        <main className="certificates-main">
          {/* Header */}
          <section className="certificates-page-header">
            <div className="certificates-heading">
              <h1>Certificates &amp; Credentials</h1>
              <p>
                Manage, share, and verify your official course certifications.
              </p>
            </div>

            <div className="certificates-hero">
              <div className="certificates-hero__content">
                <div className="certificates-hero__icon">
                  <Award size={28} />
                </div>
                <div className="certificates-hero__copy">
                  <strong>Verified Qualifications</strong>
                  <p>Share your credentials directly to LinkedIn or employers.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Toolbar */}
          <div className="certificates-toolbar">
            <div className="certificate-tabs">
              <button
                className={`certificate-tab ${activeTab === "all" ? "certificate-tab--active" : ""}`}
                onClick={() => setActiveTab("all")}
              >
                All Certificates ({CERTIFICATES.length})
              </button>
              <button
                className={`certificate-tab ${activeTab === "course" ? "certificate-tab--active" : ""}`}
                onClick={() => setActiveTab("course")}
              >
                Courses ({CERTIFICATES.length})
              </button>
            </div>

            <button
              className="certificate-sort-button"
              onClick={() =>
                setSort((curr) => (curr === "recent" ? "oldest" : "recent"))
              }
            >
              <span>{sort === "recent" ? "Most Recent" : "Oldest First"}</span>
              <ChevronDown size={14} />
            </button>
          </div>

          {/* Workspace */}
          <div className="certificates-workspace">
            {/* List */}
            <div className="certificate-list">
              {certificates.map((cert) => (
                <button
                  key={cert.id}
                  className={`certificate-list-card ${selectedId === cert.id ? "certificate-list-card--active" : ""}`}
                  onClick={() => setSelectedId(cert.id)}
                >
                  <div
                    className={`certificate-list-icon certificate-list-icon--${cert.theme}`}
                  >
                    <CertificateIcon type={cert.icon} />
                  </div>

                  <div className="certificate-list-content">
                    <h3>{cert.title}</h3>
                    <p>{cert.subtitle}</p>

                    <div className="certificate-meta-row">
                      <div className="certificate-issued">
                        <Calendar size={12} />
                        <span>{cert.issued}</span>
                      </div>
                      <span className="certificate-valid">
                        <CheckCircle2 size={10} /> Valid
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Preview Canvas */}
            <div className="certificate-preview-container">
              <div className="certificate-preview-wrapper">
                <div className="certificate-preview-frame">
                  <CertificateSVG certificate={selectedCertificate} />
                </div>
              </div>

              {/* Actions */}
              <div className="certificate-actions">
                <button
                  className="certificate-action certificate-action--primary"
                  onClick={handleDownload}
                >
                  <Download size={16} />
                  <span>Download PDF</span>
                </button>

                <button className="certificate-action" onClick={handleShare}>
                  <Share2 size={16} />
                  <span>Share</span>
                </button>

                <button className="certificate-action" onClick={handleDownload}>
                  <Printer size={16} />
                  <span>Print</span>
                </button>

                <button className="certificate-action">
                  <ShieldCheck size={16} />
                  <span>Verify</span>
                </button>
              </div>
            </div>
          </div>

          {/* Bottom Banner */}
          <section className="certificates-bottom-cta">
            <div className="certificates-bottom-cta__content">
              <h2>Ready to build your portfolio further?</h2>
              <p>Explore specialized tracks and earn industry-recognized badges.</p>
            </div>
            <Link to="/student/courses" className="certificates-bottom-cta__button">
              <span>Browse Catalog</span>
              <ArrowRight size={14} />
            </Link>
          </section>
        </main>

        {/* Footer */}
        <footer className="certificates-footer">
          <span>© 2026 Prime Easy Learn Training Institute.</span>

          <div className="certificates-footer-links">
            <a href="#privacy">Privacy</a>
            <a href="#terms">Terms</a>
            <a href="#help">Support</a>
          </div>

          <div className="certificates-social">
            <a href="#linkedin" className="certificates-social-icon">
              <Linkedin size={14} />
            </a>
            <a href="#instagram" className="certificates-social-icon">
              <Instagram size={14} />
            </a>
            <a href="#youtube" className="certificates-social-icon">
              <Youtube size={14} />
            </a>
          </div>
        </footer>
      </div>
    </StudentLayout>
  );
}