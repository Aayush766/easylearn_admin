import React from "react";
import { Link } from "react-router-dom";
import StudentLayout from "./StudentLayout";
import herostudent from "../public/assets/student/hero-student.png";
import bottombanner from "../public/assets/student/bottom-banner.png";
import {
  Bookmark,
  BarChart3,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Clock3,
  FileBadge,
  FileText,
  Flame,
  LayoutDashboard,
  MessageSquare,
  Play,
  Trophy,
  ArrowUpRight,
  Sparkles,
  Zap,
  Target
} from "lucide-react";
import "./StudentDashboard.css";

const courses = [
  {
    title: "Full Stack Web Development",
    subtitle: "Master HTML, CSS, JavaScript, React, Node.js and deploy production apps.",
    progress: 65,
    lessons: "42 Lessons",
    valid: "Valid till 30 Dec 2025",
    image: "/assets/student/course-fullstack.png",
    tag: "High Demand",
    color: "#2563eb"
  },
  {
    title: "UI/UX Design Masterclass",
    subtitle: "Learn Figma, design systems, modern layouts, and UX research.",
    progress: 38,
    lessons: "28 Lessons",
    valid: "Valid till 15 Nov 2025",
    image: "/assets/student/course-uiux.png",
    tag: "In Progress",
    color: "#7c3aed"
  },
];

function Donut({ value, size = 90 }) {
  return (
    <div className="vibe-donut" style={{ "--value": `${value * 3.6}deg`, "--size": `${size}px` }}>
      <div className="vibe-donut__inner">
        <strong>{value}%</strong>
        <span>Overall</span>
      </div>
    </div>
  );
}

function DashboardHero() {
  return (
    <section className="vibe-hero">
      <div className="vibe-hero__bg-glow" />
      <div className="vibe-hero__copy">
        <div className="vibe-badge">
          <Sparkles size={13} />
          <span>Pro Learner Mode</span>
        </div>
        <h1>Good Evening, <b>Aayush</b> <span className="wave">👋</span></h1>
        <h2>Keep pushing boundaries. Code. Design. Conquer.</h2>
        <p>“Discipline today creates opportunities tomorrow.”</p>
      </div>

      <div className="vibe-hero__person">
        <img src={herostudent} alt="Student Hero" />
        <div className="vibe-hero__scribble">
          Same<br />Skills<br />
          <b>Brighter<br />Future ✨</b>
        </div>
      </div>

      <div className="vibe-hero__progress-card">
        <Donut value={75} size={84} />
        <div className="vibe-hero__progress-info">
          <div className="vibe-status-pill">
            <span className="pulse-dot" /> On Track
          </div>
          <strong>Overall Progress</strong>
          <span>You're doing amazing!</span>
        </div>
      </div>
    </section>
  );
}

function Stat({ icon: Icon, value, title, subtitle, tone = "blue" }) {
  return (
    <article className={`vibe-stat vibe-stat--${tone}`}>
      <div className="vibe-stat__icon">
        <Icon size={22} />
      </div>
      <div className="vibe-stat__content">
        <strong>{value}</strong>
        <b>{title}</b>
        <small>{subtitle}</small>
      </div>
    </article>
  );
}

function CourseCard({ course }) {
  return (
    <article className="vibe-course">
      <div className="vibe-course__image-wrap">
        <img src={course.image} alt={course.title} />
        <div className="vibe-course__overlay" />
        <span className="vibe-course__tag" style={{ borderColor: course.color, color: course.color }}>
          {course.tag}
        </span>
      </div>
      <div className="vibe-course__body">
        <h3>{course.title}</h3>
        <p>{course.subtitle}</p>

        <div className="vibe-course__progress-bar">
          <div className="vibe-course__track">
            <div className="vibe-course__fill" style={{ width: `${course.progress}%`, background: course.color }} />
          </div>
          <b>{course.progress}%</b>
        </div>

        <div className="vibe-course__meta">
          <span><FileText size={14} /> {course.lessons}</span>
          <span><CalendarDays size={14} /> {course.valid}</span>
        </div>

        <Link to="/student/courses" className="vibe-course__button">
          <span>Continue Learning</span>
          <ArrowUpRight size={16} />
        </Link>
      </div>
    </article>
  );
}

function TodayPlan() {
  return (
    <aside className="vibe-card">
      <header className="vibe-card__head">
        <div>
          <h3>Today's Schedule</h3>
          <span>20 Sep 2025</span>
        </div>
        <a href="#calendar" className="vibe-link">Calendar <ArrowUpRight size={12} /></a>
      </header>
      <div className="vibe-plan">
        <div className="vibe-plan__item">
          <span className="plan-icon blue"><CalendarDays size={16} /></span>
          <p>
            <b>UI/UX Design - Live Class</b>
            <small><span className="live-badge">LIVE</span> 10:00 AM – 11:00 AM</small>
          </p>
        </div>
        <div className="vibe-plan__item">
          <span className="plan-icon emerald"><Check size={16} /></span>
          <p>
            <b>Complete Lesson 3</b>
            <small>UI Components & Systems</small>
          </p>
        </div>
        <div className="vibe-plan__item">
          <span className="plan-icon rose"><FileText size={16} /></span>
          <p>
            <b>Attempt Pre-Assessment</b>
            <small className="danger">Due Today</small>
          </p>
        </div>
      </div>
    </aside>
  );
}

function Streak() {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  return (
    <aside className="vibe-card streak-card">
      <h3>Learning Streak</h3>
      <div className="streak-main">
        <div className="flame-glow">
          <Flame size={28} />
        </div>
        <div>
          <strong>7 Days Streak!</strong>
          <span>Consistency builds mastery.</span>
        </div>
      </div>
      <div className="streak-days">
        {days.map((day, i) => (
          <div key={day} className="streak-day-item">
            <span className={i < 5 ? "done" : ""}>
              {i < 5 ? <Check size={12} /> : ""}
            </span>
            <small>{day}</small>
          </div>
        ))}
      </div>
    </aside>
  );
}

function ProgressPanel() {
  return (
    <section className="vibe-card progress-panel">
      <header className="vibe-card__head">
        <h3>My Analytics</h3>
        <a href="#details" className="vibe-link">Details <ArrowUpRight size={12} /></a>
      </header>
      <div className="progress-content">
        <Donut value={75} size={110} />
        <div className="progress-list">
          <div className="progress-row">
            <span className="mini emerald"><FileText /></span>
            <b>Lessons Completed</b>
            <strong>12 / 28</strong>
          </div>
          <div className="progress-row">
            <span className="mini amber"><FileText /></span>
            <b>Assessments Passed</b>
            <strong>4 / 6</strong>
          </div>
          <div className="progress-row">
            <span className="mini blue"><Trophy /></span>
            <b>Average Score</b>
            <strong>82%</strong>
          </div>
          <div className="progress-row">
            <span className="mini purple"><Clock3 /></span>
            <b>Time Spent</b>
            <strong>8h 45m</strong>
          </div>
        </div>
      </div>
    </section>
  );
}

function Achievement() {
  return (
    <section className="vibe-card achievement">
      <h3>Latest Achievement</h3>
      <div className="achievement-box">
        <div className="trophy-glow">
          <Trophy size={28} />
        </div>
        <b>Certificate Earned</b>
        <span>Full Stack Web Development</span>
        <small>Completed on 15 Aug 2025</small>
      </div>
      <a href="#certificate" className="vibe-btn-ghost">View Certificate</a>
    </section>
  );
}

function QuickLinks() {
  return (
    <section className="vibe-card quick-links">
      <h3>Quick Actions</h3>
      <div className="quick-links__grid">
        <a href="#notes"><span><FileText /></span>Notes</a>
        <a href="#bookmarks"><span><Bookmark /></span>Saved</a>
        <a href="#certificates"><span><FileBadge /></span>Badges</a>
        <a href="#support"><span><CircleHelp /></span>Support</a>
      </div>
    </section>
  );
}

export default function StudentDashboard() {
  return (
    <StudentLayout>
      <div className="student-page">
        <DashboardHero />

        <section className="student-stats">
          <Stat icon={Play} value="2" title="Enrolled Courses" subtitle="Active programs" tone="blue" />
          <Stat icon={BarChart3} value="12" title="Lessons Done" subtitle="Out of 28 total" tone="emerald" />
          <Stat icon={Clock3} value="8h 45m" title="Time Invested" subtitle="This month" tone="purple" />
          <Stat icon={Trophy} value="1" title="Certificates" subtitle="Verified badges" tone="amber" />
        </section>

        <section className="student-content">
          <div className="student-main-column">
            <section className="student-section">
              <header className="student-section__head">
                <h2>My Courses</h2>
                <div className="student-course-tabs">
                  <a className="active" href="#all">All Courses</a>
                  <a href="#progress">In Progress (2)</a>
                  <a href="#completed">Completed</a>
                  <div className="tab-arrows">
                    <button aria-label="Previous"><ChevronLeft size={16} /></button>
                    <button aria-label="Next"><ChevronRight size={16} /></button>
                  </div>
                </div>
              </header>

              <div className="student-course-grid">
                {courses.map(course => <CourseCard key={course.title} course={course} />)}
              </div>
            </section>

            <section className="student-lower-grid">
              <ProgressPanel />
              <Achievement />
              <QuickLinks />
            </section>

            <section className="student-bottom-banner">
              <img src={bottombanner} alt="Inspirational Banner" />
              <div className="banner-overlay">
                <h4>Small daily wins build massive results.</h4>
                <p>Keep grinding, your future self will thank you.</p>
              </div>
            </section>
          </div>

          <div className="student-right-column">
            <TodayPlan />
            <Streak />
          </div>
        </section>

        <footer className="student-footer">
          <span>© 2026 Prime Easy Learn Training Institute. All rights reserved.</span>
          <div className="footer-links">
            <a href="#privacy">Privacy</a>
            <i>•</i>
            <a href="#terms">Terms</a>
            <i>•</i>
            <a href="#help">Help</a>
          </div>
        </footer>
      </div>
    </StudentLayout>
  );
}