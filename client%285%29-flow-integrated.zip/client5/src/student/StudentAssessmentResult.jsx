import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Circle,
  Clock3,
  Download,
  FileCheck2,
  HelpCircle,
  Lightbulb,
  Trophy,
  XCircle,
} from "lucide-react";

import StudentLayout from "./StudentLayout";
import "./StudentAssessmentResult.css";
import { resultApi, normalizeList } from "../services/api";

const RESULT_DATA = {
  1: {
    title: "Pre Assessment",
    course: "Full Stack Web Development",
    attemptedAt: "20 Sep 2025 at 10:30 AM",
    duration: "30 Minutes",
    questions: 20,

    score: 75,
    correct: 15,
    incorrect: 3,
    notAttempted: 2,

    timeTaken: "30 Mins",
    average: "82%",
    rank: "#5 / 42",
    percentile: "You are in the top 12%",

    difficulty: {
      easy: 90,
      medium: 70,
      hard: 50,
    },

    questionsData: [
      {
        id: 1,
        question:
          "Which of the following is used to style a web page?",
        yourAnswer: "CSS",
        correctAnswer: "CSS",
        status: "correct",
        time: "32 sec",
      },
      {
        id: 2,
        question:
          "Which tag is used to create a hyperlink?",
        yourAnswer: "<a>",
        correctAnswer: "<a>",
        status: "correct",
        time: "18 sec",
      },
      {
        id: 3,
        question:
          "Which of the following is a JavaScript framework?",
        yourAnswer: "React",
        correctAnswer: "React",
        status: "correct",
        time: "45 sec",
      },
      {
        id: 4,
        question:
          "Which method is used to add an element to an array?",
        yourAnswer: "push()",
        correctAnswer: "push()",
        status: "correct",
        time: "28 sec",
      },
      {
        id: 5,
        question:
          "Which of the following is a backend framework?",
        yourAnswer: "Django",
        correctAnswer: "Express.js",
        status: "incorrect",
        time: "56 sec",
      },
      {
        id: 6,
        question:
          "Which language is primarily used for styling web pages?",
        yourAnswer: "CSS",
        correctAnswer: "CSS",
        status: "correct",
        time: "22 sec",
      },
      {
        id: 7,
        question:
          "Which HTML element is used for the largest heading?",
        yourAnswer: "h1",
        correctAnswer: "h1",
        status: "correct",
        time: "16 sec",
      },
      {
        id: 8,
        question:
          "Which JavaScript keyword declares a constant?",
        yourAnswer: "const",
        correctAnswer: "const",
        status: "correct",
        time: "24 sec",
      },
      {
        id: 9,
        question:
          "Which protocol is commonly used for secure web traffic?",
        yourAnswer: "HTTPS",
        correctAnswer: "HTTPS",
        status: "correct",
        time: "31 sec",
      },
      {
        id: 10,
        question:
          "Which database is commonly used with MongoDB applications?",
        yourAnswer: "MongoDB",
        correctAnswer: "MongoDB",
        status: "correct",
        time: "39 sec",
      },
    ],
  },
};


function mapServerResult(item, fallback) {
  if (!item) return fallback;
  const score = Number(item.percentage ?? item.score ?? 0);
  const totalMarks = Number(item.totalMarks ?? item.total ?? 0);
  const correct = Number(item.correct ?? item.correctAnswers ?? 0);
  const answered = Number(item.answered ?? correct + Number(item.incorrect ?? 0));
  const questions = Number(item.questionCount ?? totalMarks ?? answered ?? fallback.questions);
  const incorrect = Number(item.incorrect ?? Math.max(0, answered - correct));
  const notAttempted = Number(item.notAttempted ?? Math.max(0, questions - answered));
  return {
    ...fallback,
    title: item.assessment?.title || item.title || fallback.title,
    course: item.course?.title || item.course?.name || fallback.course,
    attemptedAt: item.submittedAt || item.createdAt || fallback.attemptedAt,
    duration: item.duration ? `${item.duration} Minutes` : fallback.duration,
    questions,
    score,
    correct,
    incorrect,
    notAttempted,
    timeTaken: item.timeTaken ? `${item.timeTaken} Mins` : fallback.timeTaken,
    result: item.result || (score >= 40 ? "PASS" : "FAIL"),
    questionsData: Array.isArray(item.questionsData) ? item.questionsData : fallback.questionsData,
  };
}

function getResult(id) {
  return RESULT_DATA[id] || RESULT_DATA[1];
}

/* =========================================================
   RESULT HEADER
========================================================= */

function ResultHeading({ result }) {
  return (
    <div className="assessment-result-heading">
      <Link
        to="/student/assessments"
        className="assessment-result-back"
      >
        <ArrowLeft size={18} />
        Back to Assessments
      </Link>

      <div className="assessment-result-heading__row">
        <div>
          <h1>
            {result.title} - {result.course}
          </h1>

          <div className="assessment-result-meta">
            <span>
              Attempted {result.attemptedAt}
            </span>

            <i />

            <span>
              Duration: {result.duration}
            </span>

            <i />

            <span>
              {result.questions} Questions
            </span>
          </div>
        </div>

        <div className="assessment-completed-banner">
          <div className="assessment-completed-banner__icon">
            <Trophy size={25} />
          </div>

          <div>
            <strong>Assessment Completed!</strong>
            <span>
              Great effort! Keep learning and improving.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   SCORE CARD
========================================================= */

function ScoreCard({ result }) {
  const radius = 69;
  const circumference = 2 * Math.PI * radius;
  const progress =
    circumference - (result.score / 100) * circumference;

  return (
    <section className="result-card result-score-card">
      <div className="result-score-main">
        <div className="result-score-ring">
          <svg viewBox="0 0 160 160">
            <circle
              cx="80"
              cy="80"
              r={radius}
              className="result-score-ring__track"
            />

            <circle
              cx="80"
              cy="80"
              r={radius}
              className="result-score-ring__progress"
              style={{
                strokeDasharray: circumference,
                strokeDashoffset: progress,
              }}
            />
          </svg>

          <div className="result-score-ring__content">
            <strong>{result.score}%</strong>
            <span>Your Score</span>
          </div>
        </div>

        <div className="result-score-stats">
          <ResultMetric
            variant="green"
            icon={<BarChart3 size={21} />}
            value={`${result.correct} / ${result.questions}`}
            label="Correct Answers"
          />

          <ResultMetric
            variant="blue"
            icon={<Clock3 size={21} />}
            value={result.timeTaken}
            label="Time Taken"
          />

          <ResultMetric
            variant="orange"
            icon={<BarChart3 size={21} />}
            value={result.average}
            label="Class Average"
          />
        </div>
      </div>

      <div className="result-score-message">
        <div className="result-score-message__icon">
          <Trophy size={20} />
        </div>

        <div>
          <strong>Well Done!</strong>
          <span>
            You scored higher than the class average. Keep up the
            great work!
          </span>
        </div>
      </div>
    </section>
  );
}

function ResultMetric({
  variant,
  icon,
  value,
  label,
}) {
  return (
    <div className={`result-metric result-metric--${variant}`}>
      <div className="result-metric__icon">
        {icon}
      </div>

      <div>
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}

/* =========================================================
   PERFORMANCE SUMMARY
========================================================= */

function PerformanceSummary({ result }) {
  return (
    <section className="result-card result-performance-summary">
      <div className="result-card-title">
        <h2>Performance Summary</h2>
      </div>

      <div className="result-performance-grid">
        <PerformanceMetric
          variant="green"
          icon={<BarChart3 size={20} />}
          value={result.correct}
          label="Correct"
        />

        <PerformanceMetric
          variant="red"
          icon={<BarChart3 size={20} />}
          value={result.incorrect}
          label="Incorrect"
        />

        <PerformanceMetric
          variant="slate"
          icon={<BarChart3 size={20} />}
          value={result.notAttempted}
          label="Not Attempted"
        />
      </div>
    </section>
  );
}

function PerformanceMetric({
  variant,
  icon,
  value,
  label,
}) {
  return (
    <div className={`performance-metric performance-metric--${variant}`}>
      <div className="performance-metric__icon">
        {icon}
      </div>

      <div>
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}

/* =========================================================
   RANK
========================================================= */

function RankCard({ result }) {
  return (
    <section className="result-card result-rank-card">
      <div className="result-card-title">
        <h2>Your Rank</h2>
      </div>

      <div className="result-rank-content">
        <div className="result-rank-medal">
          <Trophy size={28} />
        </div>

        <div>
          <strong>{result.rank}</strong>
          <span>{result.percentile}</span>

          <em>Great Performance!</em>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   TIME ANALYSIS
========================================================= */

function TimeAnalysis({ result }) {
  return (
    <section className="result-card result-time-card">
      <div className="result-card-title result-card-title--icon">
        <div>
          <Clock3 size={18} />
        </div>

        <h2>Time Analysis</h2>
      </div>

      <div className="result-time-grid">
        <div>
          <strong>{result.timeTaken}</strong>
          <span>Total Time</span>
        </div>

        <div>
          <strong>1.5 Mins</strong>
          <span>Avg. per Question</span>
        </div>

        <div>
          <strong>0.8 Mins</strong>
          <span>Avg. for Correct</span>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   DIFFICULTY
========================================================= */

function DifficultyPerformance({ result }) {
  const rows = [
    {
      label: "Easy",
      value: result.difficulty.easy,
      className: "easy",
    },
    {
      label: "Medium",
      value: result.difficulty.medium,
      className: "medium",
    },
    {
      label: "Hard",
      value: result.difficulty.hard,
      className: "hard",
    },
  ];

  return (
    <section className="result-card result-difficulty-card">
      <div className="result-card-title">
        <h2>Difficulty Wise Performance</h2>
      </div>

      <div className="difficulty-list">
        {rows.map((row) => (
          <div className="difficulty-row" key={row.label}>
            <span>{row.label}</span>

            <div className="difficulty-track">
              <span
                className={`difficulty-fill difficulty-fill--${row.className}`}
                style={{ width: `${row.value}%` }}
              />
            </div>

            <strong>{row.value}%</strong>
          </div>
        ))}
      </div>
    </section>
  );
}

/* =========================================================
   ANALYSIS TABS
========================================================= */

function AnalysisTabs({ activeTab, setActiveTab }) {
  const tabs = [
    {
      id: "questions",
      label: "Question Analysis",
    },
    {
      id: "topics",
      label: "Topic Wise Analysis",
    },
    {
      id: "comparison",
      label: "Comparison",
    },
    {
      id: "feedback",
      label: "Feedback",
    },
  ];

  return (
    <div className="result-analysis-tabs">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          type="button"
          className={
            activeTab === tab.id
              ? "result-analysis-tab result-analysis-tab--active"
              : "result-analysis-tab"
          }
          onClick={() => setActiveTab(tab.id)}
        >
          {tab.label}
        </button>
      ))}

      <div className="result-analysis-actions">
        <button
          type="button"
          className="result-view-answers"
        >
          <FileCheck2 size={16} />
          View Answers
        </button>

        <button
          type="button"
          className="result-download-report"
          onClick={() => window.print()}
        >
          <Download size={17} />
          Download Report
        </button>
      </div>
    </div>
  );
}

/* =========================================================
   QUESTION TABLE
========================================================= */

function QuestionAnalysis({ result }) {
  const [page, setPage] = useState(1);

  const perPage = 5;

  const totalPages = Math.ceil(
    result.questionsData.length / perPage
  );

  const startIndex = (page - 1) * perPage;

  const visibleQuestions = result.questionsData.slice(
    startIndex,
    startIndex + perPage
  );

  return (
    <div className="result-question-layout">
      <section className="result-question-card">
        <div className="result-table-wrapper">
          <table className="result-question-table">
            <thead>
              <tr>
                <th>Q. No.</th>
                <th>Question</th>
                <th>Your Answer</th>
                <th>Correct Answer</th>
                <th>Status</th>
                <th>Time Taken</th>
                <th />
              </tr>
            </thead>

            <tbody>
              {visibleQuestions.map((question) => (
                <tr key={question.id}>
                  <td>{question.id}</td>

                  <td className="question-text">
                    {question.question}
                  </td>

                  <td>{question.yourAnswer}</td>

                  <td
                    className={
                      question.status === "correct"
                        ? "correct-answer"
                        : "correct-answer correct-answer--strong"
                    }
                  >
                    {question.correctAnswer}
                  </td>

                  <td>
                    {question.status === "correct" ? (
                      <span className="question-status question-status--correct">
                        <CheckCircle2 size={14} />
                        Correct
                      </span>
                    ) : (
                      <span className="question-status question-status--incorrect">
                        <XCircle size={14} />
                        Incorrect
                      </span>
                    )}
                  </td>

                  <td>{question.time}</td>

                  <td>
                    <button
                      type="button"
                      className="question-view-button"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="result-table-footer">
          <div className="result-showing">
            <span>Show</span>

            <button type="button">
              5
              <ChevronDown size={15} />
            </button>

            <span>
              of {result.questions} questions
            </span>
          </div>

          <div className="result-pagination">
            <button
              type="button"
              disabled={page === 1}
              onClick={() =>
                setPage((current) =>
                  Math.max(1, current - 1)
                )
              }
            >
              <ChevronLeft size={15} />
            </button>

            {Array.from(
              {
                length: Math.min(totalPages, 4),
              },
              (_, index) => index + 1
            ).map((number) => (
              <button
                key={number}
                type="button"
                className={
                  page === number
                    ? "result-pagination__active"
                    : ""
                }
                onClick={() => setPage(number)}
              >
                {number}
              </button>
            ))}

            <button
              type="button"
              disabled={page === totalPages}
              onClick={() =>
                setPage((current) =>
                  Math.min(totalPages, current + 1)
                )
              }
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>
      </section>

      <NextSteps />
    </div>
  );
}

/* =========================================================
   NEXT STEPS
========================================================= */

function NextSteps() {
  return (
    <aside className="result-next-sidebar">
      <section className="result-card result-next-steps">
        <div className="result-next-title">
          <div>
            <Lightbulb size={19} />
          </div>

          <h2>Next Steps</h2>
        </div>

        <ul>
          <li>
            <CheckCircle2 size={15} />
            <span>Review incorrect answers</span>
          </li>

          <li>
            <CheckCircle2 size={15} />
            <span>Focus on weak topics</span>
          </li>

          <li>
            <Circle size={15} />
            <span>Take the post assessment</span>
          </li>

          <li>
            <Circle size={15} />
            <span>Complete remaining lessons</span>
          </li>
        </ul>

        <Link
          to="/student/courses"
          className="continue-learning-button"
        >
          Continue Learning
          <ArrowRight size={17} />
        </Link>
      </section>

      <section className="result-card result-help-card">
        <div className="result-help-icon">
          <HelpCircle size={21} />
        </div>

        <div>
          <h2>Need Help?</h2>

          <p>
            If you have any doubts about your results, feel free
            to contact our support team.
          </p>

          <button type="button">
            Contact Support
          </button>
        </div>
      </section>
    </aside>
  );
}

/* =========================================================
   FOOTER
========================================================= */

function ResultFooter() {
  return (
    <footer className="assessment-result-footer">
      <span>
        © 2025 Prime Easy Learn Training Institute. All rights
        reserved.
      </span>

      <div>
        <a href="#privacy">Privacy Policy</a>
        <span>|</span>
        <a href="#terms">Terms &amp; Conditions</a>
        <span>|</span>
        <a href="#help">Help</a>
      </div>

      <div className="assessment-result-socials">
        <span>in</span>
        <span>◎</span>
        <span>▶</span>
      </div>
    </footer>
  );
}

/* =========================================================
   MAIN COMPONENT
========================================================= */

export default function StudentAssessmentResult() {
  const { assessmentId } = useParams();
  const fallbackResult = useMemo(() => getResult(Number(assessmentId)), [assessmentId]);
  const [result, setResult] = useState(fallbackResult);
  const [activeTab, setActiveTab] = useState("questions");

  useEffect(() => {
    let active = true;
    resultApi.list({ assessmentId, attemptId: assessmentId, page: 1, pageSize: 1 })
      .then((payload) => {
        const rows = normalizeList(payload);
        const first = rows[0] || payload?.result || payload?.attempt || payload;
        if (active && first && typeof first === "object") setResult(mapServerResult(first, fallbackResult));
      })
      .catch(() => {});
    return () => { active = false; };
  }, [assessmentId, fallbackResult]);

  return (
    <StudentLayout>
      <div className="student-assessment-result">
        <main className="assessment-result-content">
          <ResultHeading result={result} />

          <div className="assessment-result-top-grid">
            <ScoreCard result={result} />

            <div className="assessment-result-middle">
              <PerformanceSummary result={result} />
              <TimeAnalysis result={result} />
            </div>

            <div className="assessment-result-right">
              <RankCard result={result} />
              <DifficultyPerformance result={result} />
            </div>
          </div>

          <section className="assessment-analysis-section">
            <AnalysisTabs
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />

            {activeTab === "questions" ? (
              <QuestionAnalysis result={result} />
            ) : (
              <div className="result-placeholder">
                <BarChart3 size={30} />
                <h2>
                  {activeTab === "topics"
                    ? "Topic Wise Analysis"
                    : activeTab === "comparison"
                      ? "Comparison"
                      : "Feedback"}
                </h2>
                <p>
                  This analysis section is ready to be connected
                  to your assessment analytics API.
                </p>
              </div>
            )}
          </section>
        </main>

        <ResultFooter />
      </div>
    </StudentLayout>
  );
}