import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  BarChart3,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Flame,
  PlayCircle,
  Star,
  Trophy,
  TrendingUp,
} from "lucide-react";
import herostudent from "../public/assets/student/hero-student.png";
import StudentLayout from "./StudentLayout";
import "./StudentProgress.css";

/* =========================================================
   MOCK DATA
========================================================= */

const COURSES = [
  {
    id: 1,
    title: "Full Stack Web Development",
    image: "/assets/student/course-fullstack.png",
    completedLessons: 28,
    totalLessons: 42,
    progress: 67,
    status: "In Progress",
    statusType: "progress",
  },
  {
    id: 2,
    title: "UI/UX Design Masterclass",
    image: "/assets/student/course-uiux.png",
    completedLessons: 24,
    totalLessons: 32,
    progress: 75,
    status: "In Progress",
    statusType: "progress",
  },
  {
    id: 3,
    title: "Digital Marketing Essentials",
    image: "/assets/student/course-marketing.png",
    completedLessons: 18,
    totalLessons: 18,
    progress: 100,
    status: "Completed",
    statusType: "completed",
  },
  {
    id: 4,
    title: "Data Analytics with Python",
    image: "/assets/student/course-data.png",
    completedLessons: 16,
    totalLessons: 16,
    progress: 100,
    status: "Completed",
    statusType: "completed",
  },
];

/* =========================================================
   PAGE HEADER
========================================================= */

function ProgressHeader() {
  return (
    <section className="progress-page-header">
      <div className="progress-heading">
        <h1>My Progress</h1>
        <p>
          Track your learning journey, inspect performance assessments, and hit your milestones.
        </p>
      </div>

      <div className="progress-hero">
        <div className="progress-hero__copy">
          <strong>
            Learn<br />
            Practice<br />
            Improve<br />
            Succeed
          </strong>
        </div>

        <div className="progress-hero__person">
          <img src={herostudent} alt="Student learning" />
        </div>

        <div className="progress-hero__quote">
          “Progress<br />
          today<br />
          a brighter<br />
          tomorrow.”
        </div>

        <span className="progress-hero__line progress-hero__line--left" />
        <span className="progress-hero__line progress-hero__line--right" />
      </div>
    </section>
  );
}

/* =========================================================
   STATISTICS CARDS
========================================================= */

function ProgressStats() {
  const stats = [
    {
      icon: <BookOpen size={24} strokeWidth={2.2} />,
      value: "4",
      label: "Enrolled Courses",
      theme: "purple",
    },
    {
      icon: <CheckCircle2 size={24} strokeWidth={2.2} />,
      value: "2",
      label: "Courses Completed",
      theme: "green",
    },
    {
      icon: <TrendingUp size={24} strokeWidth={2.2} />,
      value: "62%",
      label: "Overall Progress",
      theme: "blue",
    },
    {
      icon: <BarChart3 size={24} strokeWidth={2.2} />,
      value: "+37%",
      label: "Average Improvement",
      sublabel: "(Pre vs Post Assessment)",
      theme: "orange",
    },
  ];

  return (
    <section className="progress-stats">
      {stats.map((stat) => (
        <div className="progress-stat-card" key={stat.label}>
          <div className={`progress-stat-icon progress-stat-icon--${stat.theme}`}>
            {stat.icon}
          </div>
          <div className="progress-stat-content">
            <strong>{stat.value}</strong>
            <span>{stat.label}</span>
            {stat.sublabel && <small>{stat.sublabel}</small>}
          </div>
        </div>
      ))}
    </section>
  );
}

/* =========================================================
   OVERALL PROGRESS
========================================================= */

function OverallProgress() {
  return (
    <section className="progress-card overall-progress-card">
      <div className="progress-card-heading">
        <h2>Overall Completion</h2>
        <p>You have completed 62% of your enrolled curriculum across all subjects.</p>
      </div>

      <div className="overall-progress-bar-row">
        <div className="overall-progress-track">
          <div className="overall-progress-fill" style={{ width: "62%" }} />
        </div>
        <strong>62%</strong>
      </div>

      <div className="overall-metrics">
        <ProgressMetric
          icon={<PlayCircle size={18} strokeWidth={2} />}
          value="48 / 78"
          label="Lessons Completed"
          theme="blue"
        />
        <ProgressMetric
          icon={<CheckCircle2 size={18} strokeWidth={2} />}
          value="12 / 16"
          label="Assessments Attempted"
          theme="green"
        />
        <ProgressMetric
          icon={<Clock3 size={18} strokeWidth={2} />}
          value="36h 20m"
          label="Total Learning Time"
          theme="blue"
        />
        <ProgressMetric
          icon={<Trophy size={18} strokeWidth={2} />}
          value="2"
          label="Certificates Earned"
          theme="orange"
        />
      </div>
    </section>
  );
}

function ProgressMetric({ icon, value, label, theme }) {
  return (
    <div className="overall-metric">
      <div className={`overall-metric-icon overall-metric-icon--${theme}`}>
        {icon}
      </div>
      <div>
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}

/* =========================================================
   PERFORMANCE IMPROVEMENT (WITH HOVER CALLOUTS)
========================================================= */

function PerformanceImprovement() {
  const bars = [
    { label: "Web Dev", pre: 40, post: 78 },
    { label: "UI/UX", pre: 35, post: 75 },
    { label: "Marketing", pre: 50, post: 82 },
    { label: "Data Anal.", pre: 45, post: 80 },
  ];

  return (
    <section className="progress-card performance-card">
      <div className="performance-header-row">
        <div className="progress-card-heading">
          <h2>Assessment Growth</h2>
          <p>Pre vs Post Assessment Scores</p>
        </div>

        <div className="performance-legend">
          <span><i className="performance-legend__pre" /> Pre</span>
          <span><i className="performance-legend__post" /> Post</span>
        </div>
      </div>

      <div className="performance-chart">
        <div className="chart-y-axis">
          <span>100</span>
          <span>75</span>
          <span>50</span>
          <span>25</span>
          <span>0</span>
        </div>

        <div className="chart-area">
          <div className="chart-grid">
            <span />
            <span />
            <span />
            <span />
            <span />
          </div>

          <div className="chart-bars">
            {bars.map((bar) => (
              <div className="chart-group" key={bar.label}>
                <div className="chart-columns">
                  <div className="chart-column">
                    <strong>{bar.pre}%</strong>
                    <div
                      className="chart-bar chart-bar--pre"
                      style={{ "--bar-height": `${bar.pre}%` }}
                    />
                  </div>
                  <div className="chart-column">
                    <strong>{bar.post}%</strong>
                    <div
                      className="chart-bar chart-bar--post"
                      style={{ "--bar-height": `${bar.post}%` }}
                    />
                  </div>
                </div>
                <span className="chart-label">{bar.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   COURSE PROGRESS TABLE
========================================================= */

function CourseProgress() {
  const [activeTab, setActiveTab] = useState("all");

  const filteredCourses = useMemo(() => {
    if (activeTab === "progress") {
      return COURSES.filter((c) => c.statusType === "progress");
    }
    if (activeTab === "completed") {
      return COURSES.filter((c) => c.statusType === "completed");
    }
    return COURSES;
  }, [activeTab]);

  return (
    <section className="progress-card course-progress-card">
      <div className="course-progress-heading">
        <div className="progress-card-heading">
          <h2>Course Breakdown</h2>
        </div>

        <div className="course-progress-tabs">
          <button
            type="button"
            className={`course-progress-tab ${activeTab === "all" ? "course-progress-tab--active" : ""}`}
            onClick={() => setActiveTab("all")}
          >
            All Courses
          </button>
          <button
            type="button"
            className={`course-progress-tab ${activeTab === "progress" ? "course-progress-tab--active" : ""}`}
            onClick={() => setActiveTab("progress")}
          >
            In Progress
          </button>
          <button
            type="button"
            className={`course-progress-tab ${activeTab === "completed" ? "course-progress-tab--active" : ""}`}
            onClick={() => setActiveTab("completed")}
          >
            Completed
          </button>
        </div>
      </div>

      <div className="course-progress-list">
        {filteredCourses.map((course) => (
          <CourseProgressRow key={course.id} course={course} />
        ))}
      </div>
    </section>
  );
}

function CourseProgressRow({ course }) {
  return (
    <div className="course-progress-row">
      <img src={course.image} alt="" className="course-progress-image" />

      <div className="course-progress-info">
        <h3>{course.title}</h3>
        <span>{course.completedLessons} / {course.totalLessons} lessons</span>
      </div>

      <div className="course-progress-meter">
        <div className="course-progress-track">
          <div
            className={`course-progress-fill ${course.progress === 100 ? "course-progress-fill--completed" : ""}`}
            style={{ width: `${course.progress}%` }}
          />
        </div>
        <strong>{course.progress}%</strong>
      </div>

      <span className={`course-status course-status--${course.statusType}`}>
        {course.status}
      </span>

      <Link
        to={`/student/courses/${course.id}`}
        className="course-progress-arrow"
        aria-label={`Open ${course.title}`}
      >
        <ChevronRight size={18} strokeWidth={2.2} />
      </Link>
    </div>
  );
}

/* =========================================================
   LEARNING STREAK
========================================================= */

function LearningStreak() {
  const days = [
    { name: "Mon", active: true },
    { name: "Tue", active: true },
    { name: "Wed", active: true },
    { name: "Thu", active: true },
    { name: "Fri", active: false },
    { name: "Sat", active: false },
    { name: "Sun", active: true },
  ];

  return (
    <section className="progress-card learning-streak-card">
      <div className="streak-content">
        <div className="streak-heading">
          <div className="streak-icon">
            <Flame size={26} strokeWidth={2.2} />
          </div>
          <div>
            <h2>Learning Streak</h2>
            <strong>12 Days Active</strong>
            <p>Keep your daily momentum going!</p>
          </div>
        </div>

        <div className="streak-days">
          {days.map((day) => (
            <div className="streak-day" key={day.name}>
              <span className={`streak-day-circle ${day.active ? "streak-day-circle--active" : ""}`}>
                {day.active && <Check size={14} strokeWidth={3} />}
              </span>
              <small>{day.name}</small>
            </div>
          ))}
        </div>
      </div>

      <div className="streak-message">
        <strong>Consistency<br />Creates<br />Success</strong>
        <span className="streak-message-line" />
      </div>
    </section>
  );
}

/* =========================================================
   ACHIEVEMENTS
========================================================= */

function Achievements() {
  const achievements = [
    {
      icon: <BookOpen size={22} strokeWidth={2.2} />,
      title: "First Step",
      description: "Completed 1st course",
      theme: "green",
    },
    {
      icon: <Star size={22} strokeWidth={2.2} />,
      title: "High Achiever",
      description: "Scored 80%+",
      theme: "blue",
    },
    {
      icon: <Clock3 size={22} strokeWidth={2.2} />,
      title: "Weekly Streak",
      description: "7+ days streak",
      theme: "purple",
    },
  ];

  return (
    <section className="progress-card achievements-card">
      <div className="achievements-heading">
        <h2>Your Badges</h2>
        <Link to="/student/achievements">
          View All <ChevronRight size={14} strokeWidth={2.2} />
        </Link>
      </div>

      <div className="achievement-list">
        {achievements.map((item) => (
          <div className="achievement" key={item.title}>
            <div className={`achievement-icon achievement-icon--${item.theme}`}>
              {item.icon}
            </div>
            <strong>{item.title}</strong>
            <span>{item.description}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

/* =========================================================
   FOOTER
========================================================= */

function ProgressFooter() {
  return (
    <footer className="progress-footer">
      <span>© 2025 Prime Easy Learn Training Institute. All rights reserved.</span>

      <div className="progress-footer-links">
        <a href="#privacy">Privacy Policy</a>
        <span>|</span>
        <a href="#terms">Terms &amp; Conditions</a>
        <span>|</span>
        <a href="#help">Help</a>
      </div>

      <div className="progress-social">
        <span>in</span>
        <span>◎</span>
        <span>▶</span>
      </div>
    </footer>
  );
}

/* =========================================================
   MAIN EXPORT
========================================================= */

export default function StudentProgress() {
  return (
    <StudentLayout>
      <div className="student-progress">
        <main className="progress-main">
          <ProgressHeader />
          <ProgressStats />

          <div className="progress-primary-grid">
            <div className="progress-left-column">
              <OverallProgress />
              <CourseProgress />
            </div>

            <div className="progress-right-column">
              <PerformanceImprovement />
              <LearningStreak />
              <Achievements />
            </div>
          </div>
        </main>

        <ProgressFooter />
      </div>
    </StudentLayout>
  );
}