import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  Bookmark,
  Check,
  CheckCircle2,
  ChevronLeft,
  Clock3,
  Database,
  FileText,
  HelpCircle,
  Menu,
  Timer,
  X,
} from "lucide-react";

import "./StudentAssessmentTest.css";
import { assessmentApi, attemptApi, } from "../services/api";

const QUESTIONS = [
  {
    id: 1,
    question: "Which of the following is used to style a web page?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "HTML" },
      { id: "B", text: "CSS" },
      { id: "C", text: "JavaScript" },
      { id: "D", text: "Python" },
    ],
    correctAnswer: "B",
    explanation:
      "CSS (Cascading Style Sheets) is used to style and design web pages, including layout, colors, fonts, and spacing.",
  },
  {
    id: 2,
    question: "Which HTML element is used to create a hyperlink?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "<link>" },
      { id: "B", text: "<a>" },
      { id: "C", text: "<href>" },
      { id: "D", text: "<url>" },
    ],
    correctAnswer: "B",
    explanation:
      "The <a> element is used to create hyperlinks in HTML.",
  },
  {
    id: 3,
    question: "Which language is primarily used to add interactivity to web pages?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "CSS" },
      { id: "B", text: "HTML" },
      { id: "C", text: "JavaScript" },
      { id: "D", text: "SQL" },
    ],
    correctAnswer: "C",
    explanation:
      "JavaScript is commonly used to add dynamic behavior and interactivity to web pages.",
  },
  {
    id: 4,
    question: "Which CSS property changes the text color?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "font-color" },
      { id: "B", text: "text-color" },
      { id: "C", text: "color" },
      { id: "D", text: "foreground" },
    ],
    correctAnswer: "C",
    explanation:
      "The CSS color property is used to define the foreground text color.",
  },
  {
    id: 5,
    question: "Which keyword declares a constant in modern JavaScript?",
    type: "Multiple Choice",
    options: [
      { id: "A", text: "constant" },
      { id: "B", text: "const" },
      { id: "C", text: "static" },
      { id: "D", text: "fixed" },
    ],
    correctAnswer: "B",
    explanation:
      "The const keyword declares a block-scoped variable whose binding cannot be reassigned.",
  },
  ...Array.from({ length: 15 }, (_, index) => ({
    id: index + 6,
    question: `Sample assessment question ${index + 6}: Which concept is important in modern web development?`,
    type: "Multiple Choice",
    options: [
      { id: "A", text: "Responsive Design" },
      { id: "B", text: "Accessibility" },
      { id: "C", text: "Performance" },
      { id: "D", text: "All of the above" },
    ],
    correctAnswer: "D",
    explanation:
      "Responsive design, accessibility, and performance are all important aspects of modern web development.",
  })),
];

const INITIAL_TIME = 30 * 60;

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;

  return `${String(minutes).padStart(2, "0")}:${String(
    remainingSeconds
  ).padStart(2, "0")}`;
}

function AssessmentLogo() {
  return (
    <div className="test-logo">
      <img
        src="/assets/student/logo.jpeg"
        alt="Prime Easy Learn Training Institute"
      />
    </div>
  );
}

function TestHeader({
  courseName,
  timeRemaining,
  onEndTest,
  onMobileMenu,
}) {
  return (
    <header className="test-header">
      <AssessmentLogo />

      <div className="test-header__course">
        <button
          type="button"
          className="test-header__back"
          onClick={onMobileMenu}
          aria-label="Back"
        >
          <ArrowLeft size={21} />
        </button>

        <div className="test-header__course-icon">
          <Database size={23} />
        </div>

        <div className="test-header__course-info">
          <strong>{courseName}</strong>
          <span>Assessment Test</span>
        </div>
      </div>

      <div className="test-header__actions">
        <div className="test-header__timer">
          <Clock3 size={19} />
          <span>{formatTime(timeRemaining)}</span>
        </div>

        <button
          type="button"
          className="test-header__end"
          onClick={onEndTest}
        >
          End Test
        </button>

        <button
          type="button"
          className="test-header__notification"
          aria-label="Notifications"
        >
          <Bell size={20} />
          <span />
        </button>

        <div className="test-header__profile">
          <img
            src="/assets/student/avatar.png"
            alt="Aayush Kumar"
          />

          <div>
            <strong>Aayush Kumar</strong>
            <span>Student</span>
          </div>

          <ChevronLeft size={18} className="test-header__profile-chevron" />
        </div>
      </div>
    </header>
  );
}

function TestInformation({ questionCount, timeMinutes }) {
  return (
    <div className="test-information">
      <div className="test-information__back">
        <ArrowLeft size={16} />
        <span>Back to Course</span>
      </div>

      <h1>Pre Assessment</h1>

      <p>
        Test your current knowledge before starting the course.
      </p>

      <div className="test-information__stats">
        <div>
          <FileText size={18} />
          <span>{questionCount} Questions</span>
        </div>

        <div>
          <Clock3 size={18} />
          <span>{timeMinutes} Minutes</span>
        </div>

        <div>
          <FileText size={18} />
          <span>Multiple Choice</span>
        </div>

        <div>
          <CheckCircle2 size={18} />
          <span>Auto Saved</span>
        </div>
      </div>
    </div>
  );
}

function QuestionPalette({
  questions,
  currentQuestion,
  answers,
  markedQuestions,
  onSelect,
}) {
  return (
    <section className="question-palette">
      <h2>Question Palette</h2>

      <div className="palette-legend">
        <div>
          <span className="legend-dot legend-dot--answered" />
          Answered
        </div>

        <div>
          <span className="legend-dot legend-dot--unanswered" />
          Not Answered
        </div>

        <div>
          <span className="legend-dot legend-dot--current" />
          Current
        </div>

        <div>
          <Bookmark size={16} />
          Marked
        </div>
      </div>

      <div className="question-grid">
        {questions.map((question) => {
          const isCurrent = question.id === currentQuestion;
          const isAnswered = Boolean(answers[question.id]);
          const isMarked = markedQuestions.includes(question.id);

          let stateClass = "";

          if (isCurrent) {
            stateClass = "question-number--current";
          } else if (isAnswered) {
            stateClass = "question-number--answered";
          } else {
            stateClass = "question-number--unanswered";
          }

          return (
            <button
              type="button"
              key={question.id}
              className={`question-number ${stateClass}`}
              onClick={() => onSelect(question.id)}
              aria-label={`Question ${question.id}`}
            >
              {question.id}

              {isMarked && (
                <Bookmark
                  size={9}
                  className="question-number__bookmark"
                  fill="currentColor"
                />
              )}
            </button>
          );
        })}
      </div>
    </section>
  );
}

function TimerCard({ timeRemaining }) {
  const progress = Math.max(
    0,
    Math.min(100, (timeRemaining / INITIAL_TIME) * 100)
  );

  return (
    <section className="timer-card">
      <div className="timer-card__header">
        <Timer size={29} />
        <h2>Time Remaining</h2>
      </div>

      <div className="timer-card__body">
        <div>
          <strong>{formatTime(timeRemaining)}</strong>

          <div className="timer-card__labels">
            <span>Minutes</span>
            <span>Seconds</span>
          </div>
        </div>

        <div
          className="timer-ring"
          style={{
            background: `conic-gradient(
              #0878ef ${progress}%,
              #d9e1ec ${progress}% 100%
            )`,
          }}
        >
          <div className="timer-ring__inner" />
        </div>
      </div>
    </section>
  );
}

function QuestionCard({
  question,
  selectedAnswer,
  marked,
  onAnswer,
  onToggleMark,
}) {
  const answered = Boolean(selectedAnswer);

  return (
    <section className="question-card">
      <div className="question-card__top">
        <span className="question-type">{question.type}</span>

        <button
          type="button"
          className={`mark-button ${
            marked ? "mark-button--active" : ""
          }`}
          onClick={onToggleMark}
        >
          <Bookmark
            size={18}
            fill={marked ? "currentColor" : "none"}
          />
          {marked ? "Marked" : "Mark for Review"}
        </button>
      </div>

      <h2>{question.question}</h2>

      <div className="answer-options">
        {question.options.map((option) => {
          const selected = selectedAnswer === option.id;

          return (
            <button
              type="button"
              key={option.id}
              className={`answer-option ${
                selected ? "answer-option--selected" : ""
              }`}
              onClick={() => onAnswer(option.id)}
            >
              <span className="answer-option__radio">
                {selected && <span />}
              </span>

              <span className="answer-option__letter">
                {option.id}
              </span>

              <span className="answer-option__text">
                {option.text}
              </span>
            </button>
          );
        })}
      </div>

      {answered && (
        <div className="answer-feedback">
          <div className="answer-feedback__icon">
            <Check size={20} />
          </div>

          <div>
            <strong>Answer Saved</strong>
            <p>
              Your answer has been automatically saved. You can change
              your answer before submitting the assessment.
            </p>
          </div>
        </div>
      )}
    </section>
  );
}

function HelpCard() {
  return (
    <section className="test-help">
      <div className="test-help__icon">
        <HelpCircle size={27} />
      </div>

      <div>
        <h2>Need Help?</h2>

        <p>
          If you face any issues during the test, contact our support
          team.
        </p>

        <button type="button">Contact Support</button>
      </div>
    </section>
  );
}

function TestFooter() {
  return (
    <footer className="test-footer">
      <span>
        © 2025 Prime Easy Learn Training Institute. All rights reserved.
      </span>

      <div>
        <a href="#privacy">Privacy Policy</a>
        <span>|</span>
        <a href="#terms">Terms &amp; Conditions</a>
        <span>|</span>
        <a href="#help">Help</a>
      </div>

      <div className="test-footer__quote">
        Learn Today
        <br />
        Lead Tomorrow
      </div>
    </footer>
  );
}

function EndTestModal({ onCancel, onConfirm }) {
  return (
    <div className="test-modal-backdrop">
      <div className="test-modal">
        <button
          type="button"
          className="test-modal__close"
          onClick={onCancel}
        >
          <X size={19} />
        </button>

        <div className="test-modal__icon">
          <Clock3 size={25} />
        </div>

        <h2>End Assessment?</h2>

        <p>
          Are you sure you want to end this assessment? Your current
          progress will be submitted.
        </p>

        <div className="test-modal__actions">
          <button type="button" onClick={onCancel}>
            Continue Test
          </button>

          <button
            type="button"
            className="test-modal__confirm"
            onClick={onConfirm}
          >
            End Test
          </button>
        </div>
      </div>
    </div>
  );
}

export default function StudentAssessmentTest() {
  const navigate = useNavigate();
  const { assessmentId } = useParams();

  const [currentQuestion, setCurrentQuestion] = useState(1);
  const [answers, setAnswers] = useState({});
  const [markedQuestions, setMarkedQuestions] = useState([]);
  const [timeRemaining, setTimeRemaining] = useState(INITIAL_TIME);
  const [showEndModal, setShowEndModal] = useState(false);
  const [questions, setQuestions] = useState(QUESTIONS);
  const [courseName, setCourseName] = useState("Full Stack Web Development");
  const [attemptId, setAttemptId] = useState(null);

  const question = useMemo(
    () =>
      questions.find((item) => item.id === currentQuestion) ||
      questions[0],
    [currentQuestion, questions]
  );

  useEffect(() => {
    let active = true;
    if (!assessmentId) return undefined;
    assessmentApi.get(assessmentId)
      .then(async (payload) => {
        const data = payload?.assessment || payload || {};
        const remoteQuestions = Array.isArray(data.questions) ? data.questions : [];
        if (!active) return;
        if (data.course?.title || data.course?.name) setCourseName(data.course.title || data.course.name);
        if (data.duration) setTimeRemaining(Number(data.duration) * 60);
        if (remoteQuestions.length) {
          setQuestions(remoteQuestions.map((item, index) => ({
            id: index + 1,
            question: item.question || item.text || "Question",
            type: item.type || "Multiple Choice",
            options: (item.options || []).map((option, optionIndex) => ({
              id: option.id || String.fromCharCode(65 + optionIndex),
              text: option.text || option.value || String(option),
            })),
            explanation: item.explanation || "",
          })));
        }
        try {
          const attempt = await attemptApi.start(assessmentId);
          if (active) setAttemptId(attempt?._id || attempt?.id || attempt?.attemptId || attempt?.data?._id || null);
        } catch (_) { /* fallback UI remains usable when attempt API is unavailable */ }
      })
      .catch(() => {});
    return () => { active = false; };
  }, [assessmentId]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setTimeRemaining((current) => {
        if (current <= 1) {
          window.clearInterval(timer);
          return 0;
        }

        return current - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!assessmentId) return;

    localStorage.setItem(
      `assessment-${assessmentId}-progress`,
      JSON.stringify({
        currentQuestion,
        answers,
        markedQuestions,
        timeRemaining,
      })
    );
  }, [
    assessmentId,
    currentQuestion,
    answers,
    markedQuestions,
    timeRemaining,
  ]);

  const answeredCount = Object.keys(answers).length;

  const selectAnswer = (answer) => {
    setAnswers((previous) => ({
      ...previous,
      [currentQuestion]: answer,
    }));
  };

  const toggleMark = () => {
    setMarkedQuestions((previous) =>
      previous.includes(currentQuestion)
        ? previous.filter((id) => id !== currentQuestion)
        : [...previous, currentQuestion]
    );
  };

  const goToQuestion = (id) => {
    setCurrentQuestion(id);
  };

  const nextQuestion = () => {
    setCurrentQuestion((current) =>
      Math.min(questions.length, current + 1)
    );
  };

  const previousQuestion = () => {
    setCurrentQuestion((current) => Math.max(1, current - 1));
  };

  const endTest = async () => {
    setShowEndModal(false);
    if (attemptId) {
      try {
        const submitted = await attemptApi.submit(attemptId, Object.entries(answers).map(([questionId, selectedOption]) => ({ questionId, selectedOption })));
        const resultId = submitted?._id || submitted?.id || submitted?.attemptId || attemptId;
        navigate(`/student/assessments/${resultId}/result`);
        return;
      } catch (_) {
        // Keep the existing navigation if the API is temporarily unavailable.
      }
    }
    navigate(`/student/assessments/${assessmentId}/result`);
  };

  const progressPercentage =
    (currentQuestion / questions.length) * 100;

  return (
    <div className="assessment-test-page">
      <TestHeader
        courseName={courseName}
        timeRemaining={timeRemaining}
        onEndTest={() => setShowEndModal(true)}
        onMobileMenu={() => navigate("/student/assessments")}
      />

      <div className="test-workspace">
        <aside className="test-left-sidebar">
          <TestInformation
            questionCount={questions.length}
            timeMinutes={30}
          />

          <QuestionPalette
            questions={questions}
            currentQuestion={currentQuestion}
            answers={answers}
            markedQuestions={markedQuestions}
            onSelect={goToQuestion}
          />

          <div className="test-status-legend">
            <div>
              <span className="status-dot status-dot--current" />
              Current Question
            </div>

            <div>
              <span className="status-dot status-dot--unanswered" />
              Not Answered
            </div>

            <div>
              <span className="status-dot status-dot--answered" />
              Answered
            </div>

            <div>
              <Bookmark size={18} />
              Marked for Review
            </div>
          </div>
        </aside>

        <main className="test-main">
          <div className="test-progress-header">
            <div>
              Question {currentQuestion} of {questions.length}
            </div>

            <div className="test-progress-value">
              {Math.round(progressPercentage)}% Completed
            </div>

            <div className="test-progress-track">
              <span
                style={{
                  width: `${progressPercentage}%`,
                }}
              />
            </div>
          </div>

          <QuestionCard
            question={question}
            selectedAnswer={answers[currentQuestion]}
            marked={markedQuestions.includes(currentQuestion)}
            onAnswer={selectAnswer}
            onToggleMark={toggleMark}
          />

          <div className="test-navigation">
            <button
              type="button"
              className="test-navigation__previous"
              disabled={currentQuestion === 1}
              onClick={previousQuestion}
            >
              <ChevronLeft size={19} />
              Previous
            </button>

            <div className="test-navigation__saved">
              <CheckCircle2 size={15} />
              {answeredCount} of {questions.length} Answered
            </div>

            <button
              type="button"
              className="test-navigation__next"
              disabled={currentQuestion === questions.length}
              onClick={nextQuestion}
            >
              Next Question
              <ArrowRight size={18} />
            </button>
          </div>
        </main>

        <aside className="test-right-sidebar">
          <TimerCard timeRemaining={timeRemaining} />

          <QuestionPalette
            questions={questions}
            currentQuestion={currentQuestion}
            answers={answers}
            markedQuestions={markedQuestions}
            onSelect={goToQuestion}
          />

          <HelpCard />
        </aside>
      </div>

      <TestFooter />

      {showEndModal && (
        <EndTestModal
          onCancel={() => setShowEndModal(false)}
          onConfirm={endTest}
        />
      )}
    </div>
  );
}