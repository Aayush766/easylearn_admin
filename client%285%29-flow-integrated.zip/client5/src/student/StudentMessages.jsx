import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  Archive,
  ArrowLeft,
  Bell,
  BookOpen,
  CalendarDays,
  Check,
  CheckCheck,
  ChevronRight,
  Download,
  FileText,
  Headphones,
  HelpCircle,
  Image as ImageIcon,
  MoreVertical,
  Paperclip,
  Phone,
  Plus,
  Search,
  Send,
  Smile,
  Video,
  X,
} from "lucide-react";
import herostudent from "../public/assets/student/hero-student.png"
import StudentLayout from "./StudentLayout";
import "./StudentMessages.css";

/* =========================================================
   DATA
========================================================= */

const CONVERSATIONS = [
  {
    id: "neha",
    name: "Neha Sharma",
    role: "Course Instructor",
    subtitle: "Course Instructor",
    course: "Full Stack Web Development",
    preview: "Thank you! That clears my doubt...",
    time: "10:24 AM",
    unread: 2,
    avatar: "/assets/student/avatar-neha.png",
    online: true,
    type: "instructor",
  },
  {
    id: "support",
    name: "Support Team",
    role: "Help & Support",
    subtitle: "Help & Support",
    preview: "Your issue has been resolved...",
    time: "Yesterday",
    unread: 0,
    avatar: null,
    icon: "support",
    online: true,
    type: "support",
  },
  {
    id: "announcements",
    name: "Announcements",
    role: "Institute Updates",
    subtitle: "Institute Updates",
    preview: "New batch for Data Analytics...",
    time: "18 Sep",
    unread: 0,
    avatar: null,
    icon: "announcement",
    type: "announcement",
  },
  {
    id: "rahul",
    name: "Rahul Mehta",
    role: "Career Guidance",
    subtitle: "Career Guidance",
    preview: "Sure, I'll help you with that.",
    time: "16 Sep",
    unread: 0,
    avatar: "/assets/student/avatar-rahul.png",
    online: false,
    type: "career",
  },
  {
    id: "priya",
    name: "Priya Verma",
    role: "Course Instructor",
    subtitle: "Course Instructor",
    preview: "Please find the attached notes.",
    time: "14 Sep",
    unread: 0,
    avatar: "/assets/student/avatar-priya.png",
    online: true,
    type: "instructor",
  },
  {
    id: "notifications",
    name: "System Notifications",
    role: "Updates & Alerts",
    subtitle: "Updates & Alerts",
    preview: "Your certificate is ready!",
    time: "10 Sep",
    unread: 0,
    avatar: null,
    icon: "notification",
    type: "system",
  },
];

const INITIAL_MESSAGES = [
  {
    id: 1,
    sender: "student",
    text: "Hi Ma'am, I had a doubt in the React Hooks lesson. Can you please explain the useEffect() dependency array again?",
    time: "10:18 AM",
    status: "read",
  },
  {
    id: 2,
    sender: "trainer",
    text: "Hi Aayush!",
    time: "10:19 AM",
  },
  {
    id: 3,
    sender: "trainer",
    text:
      "Of course. The dependency array in useEffect() controls when the effect runs.\n\n• On every render (if no dependency array is provided)\n• Only once (if empty array [])\n• Only when specified values change (e.g. [count])",
    time: "10:19 AM",
  },
  {
    id: 4,
    sender: "trainer",
    attachment: {
      name: "useEffect Explained.pdf",
      type: "PDF",
      size: "1.2 MB",
    },
    time: "10:20 AM",
  },
  {
    id: 5,
    sender: "student",
    text: "Thank you! That clears my doubt. 🙏",
    time: "10:24 AM",
    status: "read",
  },
];

/* =========================================================
   HELPERS
========================================================= */

function ConversationIcon({ conversation }) {
  if (conversation.avatar) {
    return (
      <div className="messages-conversation-avatar">
        <img src={conversation.avatar} alt="" />

        {conversation.online && (
          <span className="messages-online-dot" />
        )}
      </div>
    );
  }

  const icons = {
    support: <Headphones size={24} strokeWidth={1.8} />,
    announcement: <Bell size={24} strokeWidth={1.8} />,
    notification: <Bell size={23} strokeWidth={1.8} />,
  };

  return (
    <div
      className={`messages-conversation-icon messages-conversation-icon--${conversation.icon}`}
    >
      {icons[conversation.icon]}
    </div>
  );
}

/* =========================================================
   PAGE HEADER
========================================================= */

function MessagesHeader() {
  return (
    <section className="messages-page-header">
      <div className="messages-page-heading">
        <h1>Messages</h1>

        <p>
          Connect with your trainers, support team, and get
          quick help.
        </p>
      </div>

      <div className="messages-banner">
        <div className="messages-banner-copy">
          Questions
          <br />
          today
          <br />
          Better learning
          <br />
          tomorrow.
        </div>

        <div className="messages-banner-person">
          <img
            src={herostudent}
            alt=""
          />
        </div>

        <div className="messages-banner-right">
          We're
          <br />
          always here
          <br />
          for you!
        </div>

        <span className="messages-banner-line messages-banner-line--left" />
        <span className="messages-banner-line messages-banner-line--right" />
      </div>
    </section>
  );
}

/* =========================================================
   CONVERSATION PANEL
========================================================= */

function ConversationPanel({
  conversations,
  selectedId,
  onSelect,
}) {
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  const filteredConversations = useMemo(() => {
    return conversations.filter((conversation) => {
      const matchesSearch =
        !search ||
        conversation.name
          .toLowerCase()
          .includes(search.toLowerCase()) ||
        conversation.preview
          .toLowerCase()
          .includes(search.toLowerCase());

      if (filter === "unread") {
        return matchesSearch && conversation.unread > 0;
      }

      if (filter === "starred") {
        return (
          matchesSearch &&
          ["neha", "rahul"].includes(conversation.id)
        );
      }

      return matchesSearch;
    });
  }, [conversations, filter, search]);

  return (
    <aside className="messages-conversations">
      <button
        type="button"
        className="messages-new-button"
        onClick={() => alert("New message")}
      >
        <Plus size={21} strokeWidth={1.8} />
        <span>New Message</span>
      </button>

      <div className="messages-tabs">
        <button
          type="button"
          className={
            filter === "all"
              ? "messages-tab messages-tab--active"
              : "messages-tab"
          }
          onClick={() => setFilter("all")}
        >
          All
        </button>

        <button
          type="button"
          className={
            filter === "unread"
              ? "messages-tab messages-tab--active"
              : "messages-tab"
          }
          onClick={() => setFilter("unread")}
        >
          Unread
        </button>

        <button
          type="button"
          className={
            filter === "starred"
              ? "messages-tab messages-tab--active"
              : "messages-tab"
          }
          onClick={() => setFilter("starred")}
        >
          Starred
        </button>
      </div>

      <div className="messages-search">
        <Search size={17} strokeWidth={1.8} />

        <input
          value={search}
          onChange={(event) =>
            setSearch(event.target.value)
          }
          placeholder="Search conversations..."
        />

        {search && (
          <button
            type="button"
            onClick={() => setSearch("")}
            aria-label="Clear search"
          >
            <X size={14} />
          </button>
        )}
      </div>

      <div className="messages-conversation-list">
        {filteredConversations.length === 0 ? (
          <div className="messages-empty">
            <Search size={25} />
            <p>No conversations found</p>
          </div>
        ) : (
          filteredConversations.map((conversation) => (
            <button
              type="button"
              key={conversation.id}
              className={
                selectedId === conversation.id
                  ? "conversation-item conversation-item--active"
                  : "conversation-item"
              }
              onClick={() => onSelect(conversation.id)}
            >
              <ConversationIcon
                conversation={conversation}
              />

              <div className="conversation-content">
                <div className="conversation-top">
                  <strong>{conversation.name}</strong>

                  <span>{conversation.time}</span>
                </div>

                <small>{conversation.subtitle}</small>

                <div className="conversation-bottom">
                  <p>{conversation.preview}</p>

                  {conversation.unread > 0 && (
                    <span className="conversation-unread">
                      {conversation.unread}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))
        )}
      </div>
    </aside>
  );
}

/* =========================================================
   CHAT HEADER
========================================================= */

function ChatHeader() {
  return (
    <header className="messages-chat-header">
      <div className="chat-person">
        <div className="chat-person-avatar">
          <img
            src="/assets/student/avatar-neha.png"
            alt=""
          />

          <span />
        </div>

        <div>
          <h2>
            <i />
            Neha Sharma
          </h2>

          <p>
            <span />
            Course Instructor • Full Stack Web Development
          </p>
        </div>
      </div>

      <div className="chat-header-actions">
        <button
          type="button"
          aria-label="Call"
          title="Call"
        >
          <Phone size={19} />
        </button>

        <button
          type="button"
          aria-label="Video call"
          title="Video call"
        >
          <Video size={19} />
        </button>

        <button
          type="button"
          aria-label="More"
          title="More"
        >
          <MoreVertical size={19} />
        </button>
      </div>
    </header>
  );
}

/* =========================================================
   MESSAGE
========================================================= */

function ChatMessage({ message }) {
  const isStudent = message.sender === "student";

  if (message.attachment) {
    return (
      <div className="message-row message-row--trainer">
        <div className="message-avatar-small">
          <img
            src="/assets/student/avatar-neha.png"
            alt=""
          />
        </div>

        <div className="message-attachment-wrapper">
          <div className="message-attachment">
            <div className="attachment-file-icon">
              <FileText size={22} />
            </div>

            <div className="attachment-details">
              <strong>{message.attachment.name}</strong>

              <span>
                {message.attachment.type} ·{" "}
                {message.attachment.size}
              </span>
            </div>

            <button
              type="button"
              aria-label="Download attachment"
              className="attachment-download"
            >
              <Download size={18} />
            </button>
          </div>

          <span className="message-time">
            {message.time}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div
      className={
        isStudent
          ? "message-row message-row--student"
          : "message-row message-row--trainer"
      }
    >
      {!isStudent && (
        <div className="message-avatar-small">
          <img
            src="/assets/student/avatar-neha.png"
            alt=""
          />
        </div>
      )}

      <div className="message-body">
        <div
          className={
            isStudent
              ? "message-bubble message-bubble--student"
              : "message-bubble message-bubble--trainer"
          }
        >
          {message.text.split("\n").map((line, index) => (
            <span key={index}>
              {line}

              {index <
                message.text.split("\n").length - 1 && (
                <br />
              )}
            </span>
          ))}
        </div>

        <div className="message-meta">
          <span>{message.time}</span>

          {isStudent && (
            <CheckCheck
              size={15}
              strokeWidth={2}
              className="message-read"
            />
          )}
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   CHAT AREA
========================================================= */

function ChatPanel() {
  const [messages, setMessages] =
    useState(INITIAL_MESSAGES);

  const [message, setMessage] = useState("");

  const sendMessage = () => {
    const trimmed = message.trim();

    if (!trimmed) return;

    setMessages((current) => [
      ...current,
      {
        id: Date.now(),
        sender: "student",
        text: trimmed,
        time: "10:25 AM",
        status: "sent",
      },
    ]);

    setMessage("");
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendMessage();
    }
  };

  return (
    <section className="messages-chat">
      <ChatHeader />

      <div className="messages-chat-body">
        <div className="chat-date">Today</div>

        <div className="messages-list">
          {messages.map((item) => (
            <ChatMessage
              key={item.id}
              message={item}
            />
          ))}
        </div>
      </div>

      <div className="message-composer">
        <button
          type="button"
          className="composer-icon-button"
          aria-label="Attach file"
          title="Attach file"
        >
          <Paperclip size={21} />
        </button>

        <input
          value={message}
          onChange={(event) =>
            setMessage(event.target.value)
          }
          onKeyDown={handleKeyDown}
          placeholder="Type your message..."
        />

        <button
          type="button"
          className="composer-icon-button"
          aria-label="Emoji"
          title="Emoji"
        >
          <Smile size={21} />
        </button>

        <button
          type="button"
          className="composer-send"
          aria-label="Send message"
          onClick={sendMessage}
        >
          <Send size={20} />
        </button>
      </div>
    </section>
  );
}

/* =========================================================
   PROFILE PANEL
========================================================= */

function ProfilePanel() {
  return (
    <aside className="messages-profile">
      <div className="profile-person">
        <div className="profile-avatar">
          <img
            src="/assets/student/avatar-neha.png"
            alt=""
          />

          <span />
        </div>

        <div>
          <h2>Neha Sharma</h2>

          <p>Course Instructor</p>

          <small>
            <i />
            Online
          </small>
        </div>
      </div>

      <div className="profile-section">
        <h3>About</h3>

        <p>
          Neha Sharma is a full stack developer and
          instructor with 5+ years of experience in
          teaching web technologies.
        </p>
      </div>

      <div className="profile-divider" />

      <div className="profile-section">
        <h3>Quick Actions</h3>

        <div className="quick-actions">
          <button type="button">
            <CalendarDays size={21} />
            <span>Schedule a Call</span>
          </button>

          <Link to="/student/courses">
            <BookOpen size={21} />
            <span>View Course</span>
          </Link>

          <button type="button">
            <Paperclip size={21} />
            <span>Share a File</span>
          </button>

          <button
            type="button"
            className="quick-action-danger"
          >
            <FlagIcon />
            <span>Report an Issue</span>
          </button>
        </div>
      </div>

      <div className="profile-quote">
        <strong>“</strong>

        <p>
          “A doubt cleared today
          <br />
          is a step closer to success!”
        </p>

        <span />
      </div>
    </aside>
  );
}

function FlagIcon() {
  return (
    <svg
      width="21"
      height="21"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path
        d="M5 21V4"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path
        d="M5 5C8.5 2.5 12 7.5 19 4.5V14.5C12 17.5 8.5 12.5 5 15"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/* =========================================================
   MAIN
========================================================= */

export default function StudentMessages() {
  const [selectedConversation, setSelectedConversation] =
    useState("neha");

  return (
    <StudentLayout>
      <div className="student-messages">
        <main className="messages-main">
          <MessagesHeader />

          <div className="messages-workspace">
            <ConversationPanel
              conversations={CONVERSATIONS}
              selectedId={selectedConversation}
              onSelect={setSelectedConversation}
            />

            <ChatPanel />

            <ProfilePanel />
          </div>
        </main>
      </div>
    </StudentLayout>
  );
}