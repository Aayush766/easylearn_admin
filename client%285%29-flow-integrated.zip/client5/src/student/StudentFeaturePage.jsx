import { useParams } from "react-router-dom";
import StudentLayout from "./StudentLayout";
import FeaturePage from "../pages/FeaturePage";

export default function StudentFeaturePage() {
  const { page, id } = useParams();

  return (
    <StudentLayout>
      <FeaturePage id={id} page={page} role="student" />
    </StudentLayout>
  );
}
