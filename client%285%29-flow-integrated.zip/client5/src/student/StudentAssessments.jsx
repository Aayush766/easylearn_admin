import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  Clock3,
  FileCheck2,
  FileText,
  HelpCircle,
  LayoutGrid,
  List,
  Play,
  RotateCcw,
  Sparkles,
  Target,
  Trophy,
  XCircle,
} from "lucide-react";
import herostudent from "../public/assets/student/hero-student.png";

import StudentLayout from "./StudentLayout";
import "./StudentAssessments.css";
import { assessmentApi, enrollmentApi, normalizeList } from "../services/api";

const COURSES = [
  { id: "full-stack", name: "Full Stack Web Development", shortName: "Full Stack" },
  { id: "ui-ux", name: "UI/UX Design", shortName: "UI/UX" },
  { id: "digital-marketing", name: "Digital Marketing", shortName: "Marketing" },
];

const ASSESSMENTS = [
  {
    id: 1,
    title: "Pre Assessment",
    description: "Test your current knowledge before starting the course.",
    type: "Pre Assessment",
    typeClass: "pre",
    questions: 20,
    duration: "30 Mins",
    score: 45,
    status: "completed",
    icon: FileText,
    iconClass: "purple",
    action: "View Result",
  },
  {
    id: 2,
    title: "HTML & CSS Quiz",
    description: "Based on Modules 1–3",
    type: "Module Assessment",
    typeClass: "module",
    questions: 15,
    duration: "20 Mins",
    score: 80,
    status: "completed",
    icon: FileCheck2,
    iconClass: "green",
    action: "View Result",
  },
  {
    id: 3,
    title: "JavaScript Basics Quiz",
    description: "Based on Modules 4–6",
    type: "Module Assessment",
    typeClass: "module",
    questions: 20,
    duration: "30 Mins",
    score: 75,
    status: "completed",
    icon: FileCheck2,
    iconClass: "green",
    action: "View Result",
  },
  {
    id: 4,
    title: "React Fundamentals Quiz",
    description: "Based on Modules 7–9",
    type: "Module Assessment",
    typeClass: "module",
    questions: 20,
    duration: "30 Mins",
    score: null,
    status: "not-attempted",
    icon: FileCheck2,
    iconClass: "red",
    action: "Start Now",
  },
  {
    id: 5,
    title: "Post Assessment",
    description: "Test your knowledge after completing the course.",
    type: "Post Assessment",
    typeClass: "post",
    questions: 30,
    duration: "45 Mins",
    score: null,
    status: "pending",
    icon: Clock3,
    iconClass: "blue",
    action: "Attempt Later",
  },
];


function mapAssessment(item) {
  const type = String(item.type || "MODULE").toUpperCase();
  const latest = item.latestAttempt || item.lastAttempt || item.attempt;
  const score = latest?.percentage ?? item.score ?? null;
  const attempted = Boolean(latest || item.attempted || item.attemptCount > 0);
  const status = attempted ? "completed" : type === "POST" ? "pending" : "not-attempted";
  const typeClass = type === "PRE" ? "pre" : type === "POST" ? "post" : "module";
  return {
    id: item._id || item.id,
    title: item.title || "Assessment",
    description: item.description || item.instructions || "Complete this assessment to measure your understanding.",
    type: type === "PRE" ? "Pre Assessment" : type === "POST" ? "Post Assessment" : "Module Assessment",
    typeClass,
    questions: item.questionCount ?? item.questions?.length ?? 0,
    duration: item.duration ? `${item.duration} Mins` : "—",
    score,
    status,
    icon: type === "POST" ? Clock3 : type === "PRE" ? FileText : FileCheck2,
    iconClass: type === "POST" ? "blue" : type === "PRE" ? "purple" : "green",
    action: attempted ? "View Result" : type === "POST" ? "Attempt Later" : "Start Now",
  };
}

const TABS = [
  { id: "all", label: "All Assessments" },
  { id: "pre", label: "Pre Assessments" },
  { id: "post", label: "Post Assessments" },
  { id: "attempted", label: "Attempted" },
];

function getVisibleAssessments(tab, assessments) {
  switch (tab) {
    case "pre":
      return assessments.filter((item) => item.typeClass === "pre");
    case "post":
      return assessments.filter((item) => item.typeClass === "post");
    case "attempted":
      return assessments.filter((item) => item.status === "completed");
    default:
      return assessments;
  }
}

function AssessmentHero() {
  return (
    <section className="assessment-hero">
      <div className="assessment-hero__badge">
        <Sparkles size={14} />
        <span>Evaluate • Improve • Grow</span>
      </div>
      <div className="assessment-hero__content">
        <h1>Assessments</h1>
        <p>Test your knowledge, track progress, and continuously elevate your skill sets.</p>
      </div>
      <div className="assessment-hero__visual" aria-hidden="true">
        <img src={herostudent} alt="" className="assessment-hero__img" />
      </div>
    </section>
  );
}

function AssessmentTabs({ activeTab, onChange }) {
  return (
    <div className="assessment-tabs" role="tablist" aria-label="Assessment filters">
      {TABS.map((tab) => (
        <button
          key={tab.id}
          type="button"
          role="tab"
          aria-selected={activeTab === tab.id}
          className={`assessment-tab ${activeTab === tab.id ? "assessment-tab--active" : ""}`}
          onClick={() => onChange(tab.id)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}

function CourseSelector({ value, onChange }) {
  return (
    <div className="assessment-course-selector">
      <label htmlFor="assessment-course">Course Scope</label>
      <div className="assessment-select">
        <BookOpen size={16} className="assessment-select__icon" />
        <select
          id="assessment-course"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        >
          {courseOptions.map((course) => (
            <option key={course.id} value={course.id}>
              {course.name}
            </option>
          ))}
        </select>
        <ChevronDown size={16} className="assessment-select__chevron" />
      </div>
    </div>
  );
}

function SummaryCard({ icon: Icon, value, label, variant }) {
  return (
    <div className={`assessment-summary-card assessment-summary-card--${variant}`}>
      <div className="assessment-summary-card__icon">
        <Icon size={20} />
      </div>
      <div className="assessment-summary-card__content">
        <strong>{value}</strong>
        <span>{label}</span>
      </div>
    </div>
  );
}

function AssessmentItem({ assessment, viewMode }) {
  const Icon = assessment.icon;

  const renderStatus = () => {
    if (assessment.status === "completed") {
      return (
        <div className="assessment-status-badge assessment-status-badge--completed">
          <span>Score</span>
          <strong>{assessment.score}%</strong>
        </div>
      );
    }
    return (
      <div className="assessment-status-badge assessment-status-badge--neutral">
        <span>Status</span>
        <strong>{assessment.status === "pending" ? "Pending" : "Not Started"}</strong>
      </div>
    );
  };

  const renderAction = () => {
    if (assessment.status === "completed") {
      return (
        <Link
          to={`/student/assessments/${assessment.id}/result`}
          className="assessment-button assessment-button--outline"
        >
          {assessment.action}
        </Link>
      );
    }
    if (assessment.status === "not-attempted") {
      return (
        <Link
          to={`/student/assessments/${assessment.id}`}
          className="assessment-button assessment-button--primary"
        >
          <Play size={13} />
          {assessment.action}
        </Link>
      );
    }
    return (
      <button type="button" className="assessment-button assessment-button--outline">
        {assessment.action}
      </button>
    );
  };

  return (
    <article className={`assessment-card assessment-card--${viewMode}`}>
      <div className={`assessment-card__icon assessment-card__icon--${assessment.iconClass}`}>
        <Icon size={20} />
      </div>

      <div className="assessment-card__body">
        <div className="assessment-card__header">
          <h3>
            {assessment.id}. {assessment.title}
          </h3>
          <span className={`assessment-type assessment-type--${assessment.typeClass}`}>
            {assessment.type}
          </span>
        </div>
        <p className="assessment-card__description">{assessment.description}</p>
      </div>

      <div className="assessment-card__meta">
        <span>
          <FileText size={14} />
          {assessment.questions} Questions
        </span>
        <span>
          <Clock3 size={14} />
          {assessment.duration}
        </span>
      </div>

      <div className="assessment-card__result">{renderStatus()}</div>

      <div className="assessment-card__action">{renderAction()}</div>
    </article>
  );
}

function PerformanceCard() {
  return (
    <section className="performance-card">
      <div className="panel-heading">
        <h2>Performance Snapshot</h2>
        <button type="button" className="report-link">
          Detailed Report <ArrowRight size={14} />
        </button>
      </div>

      <div className="performance-chart">
        <div className="performance-bars">
          <div className="performance-bar">
            <span className="performance-bar__value">45%</span>
            <div className="performance-bar__track">
              <div
                className="performance-bar__fill performance-bar__fill--pre"
                style={{ height: "45%" }}
              />
            </div>
            <span className="performance-bar__label">Pre-Test</span>
          </div>

          <div className="performance-bar">
            <span className="performance-bar__value">82%</span>
            <div className="performance-bar__track">
              <div
                className="performance-bar__fill performance-bar__fill--post"
                style={{ height: "82%" }}
              />
            </div>
            <span className="performance-bar__label">Post-Test</span>
          </div>
        </div>

        <div className="performance-donut-wrapper">
          <div className="performance-donut">
            <div className="performance-donut__inner">
              <strong>75%</strong>
            </div>
          </div>
          <span className="performance-donut__label">Overall Progress</span>
        </div>
      </div>

      <div className="performance-success">
        <div className="performance-success__icon">
          <Trophy size={18} />
        </div>
        <div>
          <strong>Great Progress!</strong>
          <p>You&apos;ve demonstrated a 37% improvement across assessments.</p>
        </div>
      </div>
    </section>
  );
}

function AssessmentInstructions() {
  const instructions = [
    "Read each question carefully before submitting.",
    "Each assessment features an active countdown timer.",
    "Single submit attempt per assessment module.",
    "Scores are indexed automatically upon completion.",
  ];

  return (
    <section className="info-panel">
      <div className="info-panel__heading">
        <div className="info-panel__icon">
          <FileText size={18} />
        </div>
        <h2>Instructions</h2>
      </div>
      <ul>
        {instructions.map((inst, index) => (
          <li key={index}>
            <CheckCircle2 size={14} />
            <span>{inst}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function NeedHelp() {
  return (
    <section className="help-panel">
      <div className="help-panel__icon">
        <HelpCircle size={20} />
      </div>
      <div className="help-panel__content">
        <h2>Need Assistance?</h2>
        <p>Encountering issues with an assessment? Contact academic support.</p>
        <button type="button" className="help-panel__button">
          Get Support
        </button>
      </div>
    </section>
  );
}

function AssessmentBottomCTA() {
  return (
    <section className="assessment-bottom-cta">
      <div className="assessment-bottom-cta__target">
        <Target size={24} />
      </div>
      <div className="assessment-bottom-cta__copy">
        <h2>Consistent Practice Drives Excellence</h2>
        <p>Complete assessments on schedule to generate complete competency reports.</p>
      </div>
      <Link to="/student/courses" className="assessment-bottom-cta__button">
        Go to Courses <ArrowRight size={15} />
      </Link>
    </section>
  );
}

function AssessmentFooter() {
  return (
    <footer className="assessment-footer">
      <span>© 2026 Prime Easy Learn Training Institute. All rights reserved.</span>
      <div className="assessment-footer__links">
        <a href="#privacy">Privacy Policy</a>
        <span>•</span>
        <a href="#terms">Terms of Service</a>
        <span>•</span>
        <a href="#help">Support</a>
      </div>
    </footer>
  );
}

export default function StudentAssessments() {
  const [selectedCourse, setSelectedCourse] = useState("full-stack");
  const [activeTab, setActiveTab] = useState("all");
  const [viewMode, setViewMode] = useState("list");
  const [courseOptions, setCourseOptions] = useState(COURSES);
  const [assessmentData, setAssessmentData] = useState(ASSESSMENTS);

  useEffect(() => {
    let active = true;
    enrollmentApi.list({ status: "ACTIVE", page: 1, pageSize: 50 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (!active || !rows.length) return;
        const mapped = rows.map((row) => {
          const course = row.course || row.courseId || {};
          return { id: course._id || course.id || row.courseId, name: course.title || course.name || "Course", shortName: course.shortName || course.title || "Course" };
        });
        setCourseOptions(mapped);
        if (!mapped.some((course) => course.id === selectedCourse)) setSelectedCourse(mapped[0].id);
      })
      .catch(() => {});
    return () => { active = false; };
  }, [selectedCourse]);

  useEffect(() => {
    let active = true;
    assessmentApi.list({ courseId: selectedCourse, page: 1, pageSize: 50 })
      .then((payload) => {
        const rows = normalizeList(payload);
        if (active && rows.length) setAssessmentData(rows.map(mapAssessment));
      })
      .catch(() => {});
    return () => { active = false; };
  }, [selectedCourse]);

  const visibleAssessments = useMemo(
    () => getVisibleAssessments(activeTab, assessmentData),
    [activeTab, assessmentData]
  );

  const selectedCourseData = courseOptions.find((c) => c.id === selectedCourse);

  return (
    <StudentLayout>
      <div className="student-assessments">
        <AssessmentHero />

        <div className="assessment-container">
          <AssessmentTabs activeTab={activeTab} onChange={setActiveTab} />

          <div className="assessment-layout">
            <main className="assessment-main">
              <CourseSelector value={selectedCourse} onChange={setSelectedCourse} />

              <div className="assessment-summary">
                <SummaryCard icon={FileText} value={assessmentData.length} label="Total" variant="purple" />
                <SummaryCard icon={CheckCircle2} value={assessmentData.filter((item) => item.status === "completed").length} label="Completed" variant="green" />
                <SummaryCard icon={Clock3} value={assessmentData.filter((item) => item.status === "pending").length} label="Pending" variant="orange" />
                <SummaryCard icon={XCircle} value={assessmentData.filter((item) => item.status === "not-attempted").length} label="Unattempted" variant="red" />
              </div>

              <section className="assessment-list-section">
                <div className="assessment-list-heading">
                  <div>
                    <span className="assessment-subtitle">Module Evaluations</span>
                    <h2>{selectedCourseData?.name}</h2>
                  </div>

                  <div className="assessment-list-controls">
                    <span className="assessment-count">
                      {visibleAssessments.length} Available
                    </span>

                    <div className="view-mode-toggle" role="group" aria-label="View Mode">
                      <button
                        type="button"
                        className={`view-mode-btn ${viewMode === "list" ? "active" : ""}`}
                        onClick={() => setViewMode("list")}
                        title="List View"
                      >
                        <List size={16} />
                      </button>
                      <button
                        type="button"
                        className={`view-mode-btn ${viewMode === "block" ? "active" : ""}`}
                        onClick={() => setViewMode("block")}
                        title="Block Grid View"
                      >
                        <LayoutGrid size={16} />
                      </button>
                    </div>
                  </div>
                </div>

                <div className={`assessment-grid assessment-grid--${viewMode}`}>
                  {visibleAssessments.length > 0 ? (
                    visibleAssessments.map((assessment) => (
                      <AssessmentItem
                        key={assessment.id}
                        assessment={assessment}
                        viewMode={viewMode}
                      />
                    ))
                  ) : (
                    <div className="assessment-empty">
                      <div className="assessment-empty__icon">
                        <RotateCcw size={20} />
                      </div>
                      <h3>No Assessments Found</h3>
                      <p>There are no assessments matching the selected filters.</p>
                    </div>
                  )}
                </div>
              </section>
            </main>

            <aside className="assessment-sidebar">
              <PerformanceCard />
              <AssessmentInstructions />
              <NeedHelp />
            </aside>
          </div>

          <AssessmentBottomCTA />
        </div>

        <AssessmentFooter />
      </div>
    </StudentLayout>
  );
}