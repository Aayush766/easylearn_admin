import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { Link, NavLink } from "react-router-dom";
import {
  Bell,
  BookOpen,
  Bookmark,
  CircleHelp,
  FileBadge2,
  FileText,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Search,
  ChevronDown,
  GraduationCap,
  Sparkles,
} from "lucide-react";
import "./StudentLayout.css";
import logo from "../public/assets/student/logo.jpeg";

const STUDENT_NAVIGATION = [
  { label: "Dashboard", path: "/student", icon: LayoutDashboard, end: true },
  { label: "My Courses", path: "/student/courses", icon: BookOpen },
  { label: "Assessments", path: "/student/assessments", icon: FileText },
  { label: "Certificates", path: "/student/certificates", icon: FileBadge2 },
  { label: "My Progress", path: "/student/progress", icon: LayoutDashboard },
  { label: "Bookmarks", path: "/student/bookmarks", icon: Bookmark },
  { label: "Messages", path: "/student/messages", icon: MessageSquare },
  { label: "Help & Support", path: "/student/support", icon: CircleHelp },
];

function StudentBrand() {
  return (
    <Link className="student-layout__brand" to="/student">
      <div className="student-layout__logo-wrapper">
        <img src={logo} alt="Prime Easy Learn Training Institute" />
      </div>
    </Link>
  );
}

function StudentSidebar({ open, onClose }) {
  return (
    <aside className={`student-layout__sidebar${open ? " is-open" : ""}`}>
      <StudentBrand />

      <nav className="student-layout__navigation" aria-label="Student navigation">
        {STUDENT_NAVIGATION.map(({ label, path, icon: Icon, end }) => (
          <NavLink
            key={path}
            to={path}
            end={end}
            onClick={onClose}
            className={({ isActive }) =>
              `student-layout__nav-link${isActive ? " is-active" : ""}`
            }
          >
            <Icon size={19} strokeWidth={1.85} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="student-layout__sidebar-promo" aria-hidden="true">
        <div className="student-layout__promo-badge">
          <Sparkles size={13} />
          <span>Learning Hub</span>
        </div>
        <GraduationCap size={44} strokeWidth={1.5} className="student-layout__promo-icon" />
        <strong>
          Keep Learning
          <br />
          Keep Growing
        </strong>
        <i className="student-layout__promo-accent" />
        <span>
          “Better Skills
          <br />
          A Brighter You”
        </span>
      </div>
    </aside>
  );
}

function StudentHeader({ onMenu }) {
  const { user } = useAuth();
  const displayName = user?.name || user?.fullName || "Student";
  const displayRole = user?.role === "LEARNER" ? "Learner" : user?.role || "Student";
  return (
    <header className="student-layout__header">
      <button
        type="button"
        className="student-layout__mobile-menu"
        onClick={onMenu}
        aria-label="Open student navigation"
      >
        <Menu size={21} />
      </button>

      <label className="student-layout__search">
        <Search size={18} aria-hidden="true" />
        <input
          type="search"
          placeholder="Search for your courses, lessons, or topics..."
          aria-label="Search"
        />
        <kbd className="student-layout__search-shortcut">⌘K</kbd>
      </label>

      <div className="student-layout__account">
        <button
          type="button"
          className="student-layout__notification"
          aria-label="Notifications"
        >
          <Bell size={20} />
          <span className="student-layout__notification-badge" aria-hidden="true" />
        </button>

        <span className="student-layout__divider" aria-hidden="true" />

        <div className="student-layout__profile-trigger">
          <div className="student-layout__avatar-wrapper">
            <img
              src="/assets/student/avatar.png"
              alt={displayName}
              className="student-layout__avatar"
            />
            <span className="student-layout__status-dot" />
          </div>

          <div className="student-layout__identity">
            <strong>{displayName}</strong>
            <small>{displayRole}</small>
          </div>

          <ChevronDown size={16} className="student-layout__chevron" />
        </div>
      </div>
    </header>
  );
}

export default function StudentLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const closeSidebar = () => setSidebarOpen(false);

  return (
    <div className="student-layout">
      {sidebarOpen && (
        <button
          type="button"
          className="student-layout__backdrop"
          onClick={closeSidebar}
          aria-label="Close student navigation"
        />
      )}

      <StudentSidebar open={sidebarOpen} onClose={closeSidebar} />

      <div className="student-layout__content">
        <StudentHeader onMenu={() => setSidebarOpen(true)} />
        <main className="student-layout__page">{children}</main>
      </div>
    </div>
  );
}