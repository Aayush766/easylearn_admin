import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import { LandingPage, LoginPage, NotFoundPage } from "./pages";
import ProtectedRoute from "./routes/ProtectedRoute";
import StudentDashboard from "./student/StudentDashboard";
import StudentCourses from "./student/StudentCourses";
import StudentFeaturePage from "./student/StudentFeaturePage";
import StudentAssessments from "./student/StudentAssessments";
import StudentAssessmentTest from "./student/StudentAssessmentTest";
import StudentAssessmentResult from "./student/StudentAssessmentResult";
import StudentCertificates from "./student/StudentCertificates";
import StudentProgress from "./student/StudentProgress";
import StudentMessages from "./student/StudentMessages";
import StudentSupport from "./student/StudentSupport";
import TrainerDashboard from "./trainer/TrainerDashboard";
import { Assessments, Courses, Profile, Results, Support, UploadPage } from "./trainer/TrainerPages";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login/:portal" element={<LoginPage />} />

        <Route path="/student" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentDashboard /></ProtectedRoute>} />
        <Route path="/student/assessments" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentAssessments /></ProtectedRoute>} />
        <Route path="/student/assessments/:assessmentId/result" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentAssessmentResult /></ProtectedRoute>} />
        <Route path="/student/assessments/:assessmentId" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentAssessmentTest /></ProtectedRoute>} />
        <Route path="/student/courses" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentCourses /></ProtectedRoute>} />
        <Route path="/student/certificates" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentCertificates /></ProtectedRoute>} />
        <Route path="/student/progress" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentProgress /></ProtectedRoute>} />
        <Route path="/student/messages" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentMessages /></ProtectedRoute>} />
        <Route path="/student/support" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentSupport /></ProtectedRoute>} />
        <Route path="/student/courses/:id" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentFeaturePage /></ProtectedRoute>} />
        <Route path="/student/:page" element={<ProtectedRoute roles={["LEARNER", "STUDENT"]}><StudentFeaturePage /></ProtectedRoute>} />

        <Route path="/trainer" element={<ProtectedRoute roles={["TRAINER"]}><TrainerDashboard /></ProtectedRoute>} />
        <Route path="/trainer/courses" element={<ProtectedRoute roles={["TRAINER"]}><Courses /></ProtectedRoute>} />
        <Route path="/trainer/content" element={<ProtectedRoute roles={["TRAINER"]}><Courses /></ProtectedRoute>} />
        <Route path="/trainer/upload" element={<ProtectedRoute roles={["TRAINER"]}><UploadPage /></ProtectedRoute>} />
        <Route path="/trainer/assessments" element={<ProtectedRoute roles={["TRAINER"]}><Assessments /></ProtectedRoute>} />
        <Route path="/trainer/results" element={<ProtectedRoute roles={["TRAINER"]}><Results /></ProtectedRoute>} />
        <Route path="/trainer/profile" element={<ProtectedRoute roles={["TRAINER"]}><Profile /></ProtectedRoute>} />
        <Route path="/trainer/support" element={<ProtectedRoute roles={["TRAINER"]}><Support /></ProtectedRoute>} />

        <Route path="/login" element={<Navigate replace to="/" />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
}
