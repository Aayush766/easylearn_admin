import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { authApi, apiError } from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadUser = useCallback(async () => {
    setLoading(true);
    try {
      const current = await authApi.me();
      setUser(current?.user || current || null);
    } catch (err) {
      setUser(null);
      if (err?.response?.status !== 401) setError(apiError(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadUser(); }, [loadUser]);

  const login = useCallback(async (credentials) => {
    setError("");
    const loggedIn = await authApi.login(credentials);
    setUser(loggedIn?.user || loggedIn || null);
    return loggedIn;
  }, []);

  const logout = useCallback(async () => {
    await authApi.logout();
    setUser(null);
  }, []);

  const value = useMemo(() => ({ user, loading, error, login, logout, refreshUser: loadUser }), [user, loading, error, login, logout, loadUser]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
