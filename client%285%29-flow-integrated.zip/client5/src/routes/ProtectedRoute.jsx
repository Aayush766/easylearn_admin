import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ roles, children }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return null;
  if (!user) return <Navigate replace to={`/login/${roles?.[0] === "TRAINER" ? "trainer" : "student"}`} state={{ from: location.pathname }} />;

  const role = String(user.role || "").toUpperCase();
  if (roles?.length && !roles.includes(role)) {
    return <Navigate replace to={role === "TRAINER" ? "/trainer" : "/student"} />;
  }

  return children;
}
