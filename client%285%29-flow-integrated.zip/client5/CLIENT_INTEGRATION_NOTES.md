# Prime Easy Learn Client Integration

The existing UI has been preserved. The client now connects the Student/Trainer portals to the Super Admin -> Admin -> Trainer -> Learner flow.

## Backend

Set:

```env
VITE_API_BASE_URL=http://localhost:5000
```

The Axios client uses `/api` automatically.

## Expected endpoints

### Authentication
- POST /api/auth/login
- POST /api/auth/logout
- POST /api/auth/refresh
- GET /api/auth/me

### Trainer
- GET /api/trainer/courses
- GET /api/modules?courseId=...
- POST /api/uploads
- POST /api/content
- GET /api/assessments?courseId=...
- POST /api/assessments
- GET /api/trainer/results

### Learner
- GET /api/enrollments?status=ACTIVE
- GET /api/assessments?courseId=...
- GET /api/assessments/:id
- POST /api/attempts
- POST /api/attempts/:id/submit
- GET /api/results
- GET /api/progress
- POST /api/progress
- GET /api/certificates

## Security

- Role is verified from the authenticated server response.
- Protected routes are guarded on the client, but the backend remains the actual authorization boundary.
- Trainer pages consume `/api/trainer/courses`, so assigned-course filtering must also be enforced server-side.
- Learner course listing requests active enrollments.
- Assessment grading is submitted to the server; the client never sends `isCorrect` or a final score as authoritative data.
- Refresh tokens are expected to be HTTP-only cookies. The access token is kept in sessionStorage only for the current browser session.

## Important media note

The supplied architecture requires Cloudflare Stream for videos and authorized playback. The client calls `/api/uploads` for the upload handoff and `/api/content` for metadata. The backend should return the provider media identifiers/authorized playback information and enforce trainer-course authorization.

## UI rule

No existing CSS, layout structure, colors, spacing, cards, sidebar designs, or responsive styles were intentionally redesigned. The changes are data/auth/API wiring only.
